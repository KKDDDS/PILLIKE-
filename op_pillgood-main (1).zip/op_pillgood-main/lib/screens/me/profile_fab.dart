import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/constants/pg_sizes.dart';
import 'package:pillgood_client/widgets/pg_button.dart';

class ProfileFab extends StatelessWidget {
  final bool isEditing;
  final void Function()? onTap;
  final void Function()? onEdit;
  final String text;
  const ProfileFab(
      {super.key,
      this.isEditing = false,
      this.onTap,
      this.text = '수정하기',
      this.onEdit});

  @override
  Widget build(BuildContext context) {
    return Container(
        width: double.infinity,
        alignment: Alignment.bottomCenter,
        padding: const EdgeInsets.all(PgSizes.size4),
        child: !isEditing
            ? SizedBox(
                height: PgSizes.size16,
                child: PgButton(
                    color: PgColors.white,
                    border: true,
                    onTap: () {
                      if (onTap != null) {
                        onTap!();
                      }
                    },
                    child: Text(
                      text,
                      style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: PgSizes.size5,
                          color: PgColors.violet_500),
                    )))
            : SizedBox(
                height: PgSizes.size16,
                child: Row(
                  children: [
                    PgButton(
                        color: PgColors.white,
                        width: 90,
                        border: true,
                        onTap: () {
                          if (onTap != null) {
                            onTap!();
                          }
                        },
                        child: const Text(
                          '취소',
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: PgSizes.size5,
                              color: PgColors.violet_500),
                        )),
                    PgGaps.w2,
                    Expanded(
                      child: PgButton(
                          onTap: () {
                            if (onEdit != null) {
                              onEdit!();
                            }
                          },
                          child: const Text(
                            '확인',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: PgSizes.size5,
                                color: PgColors.white),
                          )),
                    ),
                  ],
                )));
  }
}
