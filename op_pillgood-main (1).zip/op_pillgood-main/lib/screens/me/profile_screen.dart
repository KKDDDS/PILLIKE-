import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/models/profile_model.dart';
import 'package:pillgood_client/providers/profile_provider.dart';
import 'package:pillgood_client/screens/me/profile_fab.dart';
import 'package:pillgood_client/widgets/pg_input.dart';
import 'package:pillgood_client/widgets/pg_mini_button.dart';
import 'package:pillgood_client/widgets/pg_radio.dart';
import 'package:pillgood_client/widgets/pg_selector.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final supabase = Supabase.instance.client;

  bool _isMale = true;
  String _birthYear = '2000';
  List<String> birthYearOptions = [];
  String _drinking = '거의 하지 않음';
  List<String> drinkingOptions = [
    '거의 하지 않음',
    '한 달에 한 번',
    '한 달에 두 번 이상',
  ];
  String _smoking = '비흡연';
  List<String> smokingOptions = [
    '비흡연',
    '흡연',
    '금연중',
  ];
  String _pregnant = '임신 가능성 없음';
  List<String> pregnantOptions = [
    '임신 가능성 없음',
    '임신 가능성 있음',
    '임신중',
  ];
  String _disease = '';
  String _cautions = '';
  String _name = '';

  String _profileImageUrl = '';

  bool isEditing = false;

  @override
  void initState() {
    final profile = context.read<ProfileProvider>().profileModel;
    _isMale = profile!.sex == 'male';
    _birthYear = profile.birthyear.toString();
    _drinking = profile.drink;
    _smoking = profile.smoke;
    _pregnant = profile.pregnant;
    _disease = profile.disease;
    _cautions = profile.cautions;
    _profileImageUrl = profile.profileImageUrl;
    _name = profile.name;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final profile = context.watch<ProfileProvider>().profileModel;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        title: Text(isEditing ? '수정하기' : '내 정보',
            style: TextStyle(
                fontWeight: PgFontWeight.medium,
                fontSize: PgFontSize.base.fontSize,
                height: PgFontSize.base.height)),
      ),
      body: SingleChildScrollView(
          child: Column(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('프로필',
                      style: TextStyle(
                          fontWeight: PgFontWeight.bold,
                          fontSize: PgFontSize.xl.fontSize,
                          height: PgFontSize.xl.height)),
                  PgGaps.h6,
                  Text('프로필 이미지',
                      style: TextStyle(
                          fontWeight: PgFontWeight.medium,
                          fontSize: PgFontSize.base.fontSize,
                          height: PgFontSize.base.height)),
                  PgGaps.h2,
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: _profileImageUrl == ''
                              ? Image.asset(
                                  'assets/images/user.png',
                                  width: 128,
                                  height: 128,
                                  fit: BoxFit.cover,
                                )
                              : Image.network(
                                  _profileImageUrl,
                                  width: 128,
                                  height: 128,
                                  fit: BoxFit.cover,
                                )),
                      PgGaps.w2,
                      isEditing
                          ? PgMiniButton(
                              onTap: () async {
                                final pickedImage = await ImagePicker()
                                    .pickImage(source: ImageSource.gallery);
                                final file = pickedImage == null
                                    ? null
                                    : File(pickedImage.path);
                                String path = await supabase.storage
                                    .from('pillgood_bucket')
                                    .upload(
                                        'profile/${file!.path.split('/').last}',
                                        file);
                                path =
                                    'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/$path';
                                setState(() {
                                  _profileImageUrl = path;
                                });
                              },
                            )
                          : const SizedBox.shrink()
                    ],
                  ),
                  PgGaps.h6,
                  Text('이름',
                      style: TextStyle(
                          fontWeight: PgFontWeight.medium,
                          fontSize: PgFontSize.base.fontSize,
                          height: PgFontSize.base.height)),
                  PgGaps.h2,
                  PgInput(
                    labelText: '이름',
                    initialValue: _name,
                    enabled: isEditing,
                  )
                ]),
          ),
          Container(
            height: 16,
            color: PgColors.gray_50,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 24),
            child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('세부정보',
                      style: TextStyle(
                          fontWeight: PgFontWeight.bold,
                          fontSize: PgFontSize.xl.fontSize,
                          height: PgFontSize.xl.height)),
                  PgGaps.h6,
                  const Text(
                    '성별',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                        color:
                            isEditing ? PgColors.violet_50 : PgColors.gray_50,
                        border: Border.all(
                            color: isEditing
                                ? PgColors.violet_100
                                : PgColors.gray_100),
                        borderRadius: BorderRadius.circular(16.0)),
                    child: Row(
                      children: [
                        PgRadio(
                          checked: _isMale,
                          disabled: !isEditing,
                          onChanged: (value) {
                            setState(() {
                              _isMale = !_isMale;
                            });
                          },
                        ),
                        PgGaps.w4,
                        Text(
                          '남성',
                          style: TextStyle(
                              fontWeight: PgFontWeight.medium,
                              color: isEditing
                                  ? PgColors.gray_900
                                  : PgColors.gray_400),
                        ),
                        PgGaps.w4,
                        PgRadio(
                          checked: !_isMale,
                          disabled: !isEditing,
                          onChanged: (value) {
                            setState(() {
                              _isMale = !_isMale;
                            });
                          },
                        ),
                        PgGaps.w4,
                        Text(
                          '여성',
                          style: TextStyle(
                              fontWeight: PgFontWeight.medium,
                              color: isEditing
                                  ? PgColors.gray_900
                                  : PgColors.gray_400),
                        ),
                      ],
                    ),
                  ),
                  PgGaps.h6,
                  Text(
                    '출생년도',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  PgSelector(
                    disabled: !isEditing,
                    labelText: _birthYear,
                    options: birthYearOptions,
                    onChanged: (value) {
                      setState(() {
                        _birthYear = value;
                      });
                    },
                  ),
                  PgGaps.h6,
                  Text(
                    '음주 여부',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  PgSelector(
                    disabled: !isEditing,
                    labelText: _drinking,
                    options: drinkingOptions,
                    onChanged: (value) {
                      setState(() {
                        _drinking = value;
                      });
                    },
                  ),
                  PgGaps.h6,
                  Text(
                    '흡연 여부',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  PgSelector(
                    disabled: !isEditing,
                    labelText: _smoking,
                    options: smokingOptions,
                    onChanged: (value) {
                      setState(() {
                        _smoking = value;
                      });
                    },
                  ),
                  PgGaps.h6,
                  Text(
                    '임신 가능성',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  PgSelector(
                    disabled: !isEditing,
                    labelText: _pregnant,
                    options: pregnantOptions,
                    onChanged: (value) {
                      setState(() {
                        _pregnant = value;
                      });
                    },
                  ),
                  PgGaps.h6,
                  Text(
                    '지병 (선택)',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  PgInput(
                    labelText: '앓고 계신 지병이 있다면 적어주세요',
                    onChanged: (value) {
                      setState(() {
                        _disease = value;
                      });
                    },
                    initialValue: _disease,
                    enabled: isEditing,
                  ),
                  PgGaps.h6,
                  Text(
                    '주의해야 할 의약품 (선택)',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  PgInput(
                    labelText: '주의해야 할 의약품이 있다면 적어주세요',
                    onChanged: (value) {
                      setState(() {
                        _cautions = value;
                      });
                    },
                    enabled: isEditing,
                    initialValue: _cautions,
                  ),
                  PgGaps.h6,
                  SizedBox(
                    height: 100,
                  )
                ]),
          ),
        ],
      )),
      floatingActionButton: ProfileFab(
        isEditing: isEditing,
        onTap: () {
          setState(() {
            isEditing = !isEditing;
          });
        },
        onEdit: () async {
          final response = await supabase
              .from('profile')
              .update({
                'profile_image_url': _profileImageUrl,
                'name': _name,
                'sex': _isMale ? 'male' : 'female',
                'birthyear': int.parse(_birthYear),
                'drink': _drinking,
                'smoke': _smoking,
                'pregnant': _pregnant,
                'disease': _disease,
                'cautions': _cautions,
              })
              .eq('user_id', profile!.id)
              .select()
              .single();
          context
              .read<ProfileProvider>()
              .setProfile(ProfileModel.fromJson(response));
          Navigator.pop(context);
        },
        text: isEditing ? '저장하기' : '수정하기',
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}
