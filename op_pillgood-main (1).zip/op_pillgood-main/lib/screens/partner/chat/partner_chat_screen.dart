import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/models/chat_info_model.dart';
import 'package:pillgood_client/models/pharmacist_model.dart';
import 'package:pillgood_client/models/pharmacy_model.dart';
import 'package:pillgood_client/models/profile_model.dart';
import 'package:pillgood_client/providers/pharmacist_provider.dart';
import 'package:pillgood_client/screens/chats/%5BroomId%5D/chat_info_section.dart';
import 'package:pillgood_client/screens/chats/%5BroomId%5D/chat_item.dart';
import 'package:pillgood_client/widgets/pg_input.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PartnerChatScreen extends StatefulWidget {
  final int roomId;
  const PartnerChatScreen({super.key, required this.roomId});

  @override
  State<PartnerChatScreen> createState() => _PartnerChatScreenState();
}

class _PartnerChatScreenState extends State<PartnerChatScreen> {
  late Future<dynamic> chatRoomFuture;
  late Stream<dynamic> chatMessageStream;
  final supabase = Supabase.instance.client;
  TextEditingController controller = TextEditingController();
  ScrollController scrollController = ScrollController();

  String currentMessage = '';

  late Future<dynamic> _future;

  getPharmacy(int pharmacyId) async {
    final pharmacy = await supabase
        .from('pharmacy')
        .select('*')
        .eq('id', pharmacyId)
        .limit(1)
        .single();
    return PharmacyModel.fromJson(pharmacy);
  }

  getProfile(String userId) async {
    try {
      final profile = await supabase
          .from('profile')
          .select('*')
          .eq('user_id', userId)
          .limit(1)
          .single();
      return ProfileModel.fromJson(profile);
    } catch (e) {
      return null;
    }
  }

  getPharmacist(String pharmacistId) async {
    final pharmacist = await supabase
        .from('pharmacist')
        .select('*')
        .eq('user_id', pharmacistId)
        .limit(1)
        .single();
    return PharmacistModel.fromJson(pharmacist);
  }

  getAllInfo() async {
    final chat = await supabase
        .from('chat')
        .select('*, chat_message(*), chat_info(*, chat_info_image(*))')
        .eq('id', widget.roomId)
        .limit(1)
        .single();
    final pharmacy = await getPharmacy(chat['pharmacy_id']);
    final profile = await getProfile(chat['user_id']);
    PharmacistModel? pharmacist;
    if (chat['pharmacist_id'] != null) {
      pharmacist = await getPharmacist(chat['pharmacist_id']);
    }
    return {
      'pharmacy': pharmacy,
      'chat': chat,
      'profile': profile,
      'pharmacist': pharmacist
    };
  }

  getChatMessageStream() {
    return supabase
        .from('chat_message')
        .stream(primaryKey: ['id']).eq('chat_id', widget.roomId);
  }

  @override
  void initState() {
    _future = getAllInfo();
    chatMessageStream = getChatMessageStream();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final localPharmacist = context.read<PharmacistProvider>().pharmacistModel;
    return FutureBuilder(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data['profile'] == null) {
              Navigator.pop(context);
              return const SizedBox();
            }
            final List<ChatInfoModel> chatInfos =
                snapshot.data['chat']['chat_info'] != null
                    ? (snapshot.data['chat']['chat_info'] as List<dynamic>)
                        .map((e) => ChatInfoModel.fromJson(e))
                        .toList()
                    : [];
            PharmacistModel? pharmacist = snapshot.data['pharmacist'];
            final ProfileModel profile = snapshot.data['profile'];

            return Scaffold(
              appBar: AppBar(
                  backgroundColor: Colors.white,
                  surfaceTintColor: Colors.white,
                  title: Text(profile.name,
                      style: TextStyle(
                          fontWeight: PgFontWeight.medium,
                          fontSize: PgFontSize.base.fontSize,
                          height: PgFontSize.base.height))),
              body: Column(
                children: [
                  pharmacist != null &&
                          pharmacist.userId !=
                              context
                                  .read<PharmacistProvider>()
                                  .pharmacistModel!
                                  .userId
                      ? Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(16),
                          decoration: const BoxDecoration(
                            color: PgColors.violet_100,
                          ),
                          child: Text('담당약사 : ${pharmacist.name}',
                              style: TextStyle(
                                  fontWeight: PgFontWeight.medium,
                                  fontSize: PgFontSize.base.fontSize,
                                  height: PgFontSize.base.height,
                                  color: PgColors.violet_500)),
                        )
                      : const SizedBox(),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(children: [
                        StreamBuilder(
                            stream: chatMessageStream,
                            builder: (context, stream) {
                              if (stream.hasData) {
                                final List<dynamic> chatMessages =
                                    stream.data as List<dynamic>;
                                List<Widget> items = [];
                                items.add(const UserMessageSentBanner());
                                items.add(PgGaps.h6);
                                items.add(ChatInfoSection(
                                  chatInfos: chatInfos,
                                  profileModel: snapshot.data['profile'],
                                ));
                                items.add(PgGaps.h6);
                                items.addAll(chatMessages.map((e) {
                                  return ChatItem(
                                      profileImageUrl: profile.profileImageUrl,
                                      content: e['content'],
                                      isMine: e['user_id'] != null &&
                                          localPharmacist!.userId ==
                                              e['user_id'],
                                      createdAt:
                                          DateTime.parse(e['created_at']));
                                }).toList());
                                items = items.reversed.toList();
                                return Expanded(
                                    child: ListView.builder(
                                  itemBuilder: (context, index) {
                                    return items[index];
                                  },
                                  itemCount: items.length,
                                  reverse: true,
                                  controller: scrollController,
                                ));
                              } else {
                                return const Center(
                                    child: CircularProgressIndicator());
                              }
                            })
                      ]),
                    ),
                  ),
                  Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Expanded(
                              child: PgInput(
                            labelText: '메시지 보내기',
                            disabledText: '담당 채팅방이 아니에요',
                            enabled: pharmacist != null &&
                                    pharmacist.userId != localPharmacist!.userId
                                ? false
                                : true,
                            controller: controller,
                            onChanged: (value) {
                              setState(() {
                                currentMessage = value;
                              });
                            },
                          )),
                          PgGaps.w4,
                          SizedBox(
                            width: 32,
                            height: 32,
                            child: GestureDetector(
                              onTap: () async {
                                final currentMessage = this.currentMessage;
                                controller.clear();
                                setState(() {
                                  this.currentMessage = '';
                                });
                                if (pharmacist != null &&
                                    pharmacist!.userId !=
                                        context
                                            .read<PharmacistProvider>()
                                            .pharmacistModel!
                                            .userId) return;
                                if (currentMessage.isEmpty) return;
                                if (pharmacist == null) {
                                  await supabase
                                      .from('chat')
                                      .update({
                                        'pharmacist_id': context
                                            .read<PharmacistProvider>()
                                            .pharmacistModel!
                                            .userId,
                                      })
                                      .eq('id', widget.roomId)
                                      .select();
                                  pharmacist = localPharmacist;
                                }
                                await supabase.from('chat_message').insert([
                                  {
                                    'chat_id': widget.roomId,
                                    'content': currentMessage,
                                    'user_id': pharmacist!.userId,
                                  }
                                ]);
                                await supabase.from('chat').update({
                                  'updated_at':
                                      DateTime.now().toUtc().toString()
                                }).eq('id', widget.roomId);
                                if (snapshot.data['profile'] != null) {
                                  try {
                                    await supabase.functions
                                        .invoke('push-notifications', body: {
                                      'token':
                                          snapshot.data['profile'].fcmToken,
                                      'content':
                                          '${snapshot.data['pharmacy'].name} : $currentMessage',
                                      'roomId': widget.roomId.toString(),
                                    });
                                  } catch (e) {
                                    print(e);
                                  }
                                }

                                scrollController.animateTo(
                                  0.0,
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.easeOut,
                                );
                              },
                              child: Image.asset(
                                'assets/images/send.png',
                                color: pharmacist != null &&
                                        pharmacist.userId !=
                                            context
                                                .read<PharmacistProvider>()
                                                .pharmacistModel!
                                                .userId
                                    ? PgColors.gray_300
                                    : null,
                              ),
                            ),
                          )
                        ],
                      )),
                  SizedBox(height: MediaQuery.of(context).padding.bottom),
                ],
              ),
            );
          } else {
            return const Center(child: CircularProgressIndicator());
          }
        });
  }
}

class UserMessageSentBanner extends StatelessWidget {
  final String type;
  const UserMessageSentBanner({
    super.key,
    this.type = '기타',
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            'assets/images/check.png',
            width: 160,
            height: 160,
          ),
          const SizedBox(
            height: 18,
          ),
          Text('\'${type}\'',
              style: TextStyle(
                  fontWeight: PgFontWeight.bold,
                  fontSize: PgFontSize.xl_2.fontSize,
                  height: PgFontSize.xl_2.height)),
          Text('문의가 도착했어요',
              style: TextStyle(
                  fontWeight: PgFontWeight.bold,
                  fontSize: PgFontSize.xl_2.fontSize,
                  height: PgFontSize.xl_2.height)),
          PgGaps.h2,
          Text('사전 질문 및 사용자 정보를 확인하고',
              style: TextStyle(
                  fontWeight: PgFontWeight.medium,
                  fontSize: PgFontSize.base.fontSize,
                  height: PgFontSize.base.height,
                  color: PgColors.gray_500)),
          Text('답변해주세요',
              style: TextStyle(
                  fontWeight: PgFontWeight.medium,
                  fontSize: PgFontSize.base.fontSize,
                  height: PgFontSize.base.height,
                  color: PgColors.gray_500))
        ],
      ),
    );
  }
}
