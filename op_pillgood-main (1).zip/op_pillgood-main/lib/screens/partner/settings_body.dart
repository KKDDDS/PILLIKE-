import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/constants/pg_icons.dart';
import 'package:pillgood_client/screens/map/me_body.dart';
import 'package:pillgood_client/widgets/pg_divider.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SettingsBody extends StatefulWidget {
  const SettingsBody({super.key});

  @override
  State<SettingsBody> createState() => _SettingsBodyState();
}

class _SettingsBodyState extends State<SettingsBody> {
  final supabase = Supabase.instance.client;

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Navigator.pushNamed(context, '/partner/members');
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Row(children: [
                PgIcon(PgIcons.userGroup),
                PgGaps.w4,
                Text(
                  '멤버 관리',
                  style: TextStyle(
                      fontWeight: PgFontWeight.medium,
                      fontSize: PgFontSize.base.fontSize,
                      height: PgFontSize.base.height,
                      color: PgColors.gray_900),
                ),
              ]),
            ),
          ),
          const PgDivider(),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Navigator.pushNamed(context, '/partner/info');
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Row(children: [
                PgIcon(PgIcons.pencilSquare),
                PgGaps.w4,
                Text(
                  '약국 정보 관리',
                  style: TextStyle(
                      fontWeight: PgFontWeight.medium,
                      fontSize: PgFontSize.base.fontSize,
                      height: PgFontSize.base.height,
                      color: PgColors.gray_900),
                ),
              ]),
            ),
          ),
          const PgDivider(),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () {
              Navigator.pushNamed(context, '/browser', arguments: {
                'url':
                    'https://aromatic-star-e53.notion.site/bc02b00ebd1949e69752c711449d1d93',
                'title': '공지사항',
              });
            },
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Row(children: [
                PgIcon(PgIcons.megaphone),
                PgGaps.w4,
                Text(
                  '공지사항',
                  style: TextStyle(
                      fontWeight: PgFontWeight.medium,
                      fontSize: PgFontSize.base.fontSize,
                      height: PgFontSize.base.height,
                      color: PgColors.gray_900),
                ),
              ]),
            ),
          ),
          const PgDivider(),
          PgGaps.h6,
          const FaqBanner(),
          PgGaps.h6,
          GestureDetector(
            onTap: () {
              supabase.auth.signOut();
              Navigator.pushNamedAndRemoveUntil(
                  context, '/login', (route) => false);
            },
            child: const Text('로그아웃',
                style: TextStyle(
                    color: PgColors.gray_500,
                    decoration: TextDecoration.underline,
                    decorationColor: PgColors.gray_500)),
          )
        ]));
  }
}
