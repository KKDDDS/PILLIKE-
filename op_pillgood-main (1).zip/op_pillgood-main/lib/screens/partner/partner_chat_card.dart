import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/utils/pg_formatter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PartnerChatCard extends StatefulWidget {
  final int chatId;
  final int pharmacyId;
  final String? pharmacistId;
  final DateTime updatedAt;

  const PartnerChatCard(
      {super.key,
      required this.chatId,
      required this.updatedAt,
      required this.pharmacyId,
      this.pharmacistId});

  @override
  State<PartnerChatCard> createState() => _PartnerChatCardState();
}

class _PartnerChatCardState extends State<PartnerChatCard> {
  final supabase = Supabase.instance.client;

  late Future<dynamic> _future;

  getPharmacy() async {
    final pharmacy = await supabase
        .from('pharmacy')
        .select('name, profile_image_url')
        .eq('id', widget.pharmacyId)
        .limit(1)
        .single();
    return pharmacy;
  }

  getProfile(String userId) async {
    try {
      final profile = await supabase
          .from('profile')
          .select('*')
          .eq('user_id', userId)
          .limit(1)
          .single();
      return profile;
    } catch (e) {
      return null;
    }
  }

  getAllInfo() async {
    final pharmacy = await getPharmacy();
    final chat = await supabase
        .from('chat')
        .select('*, chat_message(*)')
        .eq('id', widget.chatId)
        .order('created_at', foreignTable: 'chat_message', ascending: false)
        .limit(1, foreignTable: 'chat_message')
        .single();
    final profile = await getProfile(chat['user_id']);

    return {'pharmacy': pharmacy, 'chat': chat, 'profile': profile};
  }

  @override
  void initState() {
    _future = getAllInfo();
    super.initState();
  }

  @override
  void didUpdateWidget(covariant PartnerChatCard oldWidget) {
    _future = getAllInfo();
    // TODO: implement didUpdateWidget
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, '/partner/chat',
            arguments: {'roomId': widget.chatId});
      },
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 24, 16, 0),
        child: Container(
          padding: const EdgeInsets.only(bottom: 24),
          decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: PgColors.gray_100))),
          child: FutureBuilder(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                if (snapshot.data!['profile'] == null) {
                  return const SizedBox();
                }
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: Image.network(
                        snapshot.data!['profile']['profile_image_url'],
                        width: 48,
                        height: 48,
                        fit: BoxFit.cover,
                      ),
                    ),
                    PgGaps.w4,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            snapshot.data!['chat']['pharmacist_id'] != null
                                ? const SizedBox()
                                : const ChatCardChip(),
                            snapshot.data!['chat']['pharmacist_id'] != null
                                ? const SizedBox()
                                : PgGaps.w2,
                            Text(
                              snapshot.data!['profile']['name'],
                              style: TextStyle(
                                  fontSize: PgFontSize.sm.fontSize,
                                  height: PgFontSize.sm.height,
                                  fontWeight: FontWeight.bold),
                            ),
                            PgGaps.w2,
                            Text(
                              PgFormatter.formatDate(widget.updatedAt),
                              style: TextStyle(
                                  fontSize: PgFontSize.sm.fontSize,
                                  height: PgFontSize.sm.height,
                                  color: PgColors.gray_500),
                            ),
                          ],
                        ),
                        PgGaps.h2,
                        Text(
                          snapshot.data['chat']['chat_message'].isNotEmpty
                              ? snapshot.data['chat']['chat_message'][0]
                                  ['content']
                              : '채팅 내용이 없습니다.',
                          style: TextStyle(
                              fontSize: PgFontSize.base.fontSize,
                              height: PgFontSize.base.height,
                              fontWeight: PgFontWeight.medium),
                        ),
                      ],
                    )
                  ],
                );
              } else {
                return const SizedBox();
              }
            },
          ),
        ),
      ),
    );
  }
}

class ChatCardChip extends StatelessWidget {
  const ChatCardChip({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: PgColors.violet_100,
        borderRadius: BorderRadius.circular(4),
      ),
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: Text(
        '신규',
        style: TextStyle(
            color: PgColors.violet_500,
            height: PgFontSize.sm.height,
            fontSize: PgFontSize.sm.fontSize,
            fontWeight: PgFontWeight.bold),
      ),
    );
  }
}
