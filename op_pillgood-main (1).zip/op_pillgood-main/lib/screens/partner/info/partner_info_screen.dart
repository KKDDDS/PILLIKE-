import 'dart:io';

import 'package:daum_postcode_search/data_model.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/providers/pharmacist_provider.dart';
import 'package:pillgood_client/screens/partner/info/partner_info_fab.dart';
import 'package:pillgood_client/screens/signup/partner/search_address_screen.dart';
import 'package:pillgood_client/services/kakao_api_service.dart';
import 'package:pillgood_client/widgets/pg_button.dart';
import 'package:pillgood_client/widgets/pg_input.dart';
import 'package:pillgood_client/widgets/pg_mini_button.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PartnerInfoScreen extends StatefulWidget {
  const PartnerInfoScreen({super.key});

  @override
  State<PartnerInfoScreen> createState() => _PartnerInfoScreenState();
}

class _PartnerInfoScreenState extends State<PartnerInfoScreen> {
  final supabase = Supabase.instance.client;

  String profileImageUrl = '';
  String name = '';
  String worktime = '';
  String postcode = '';
  String address = '';
  String addressDetail = '';
  bool isEditing = false;
  double lat = 0;
  double lon = 0;

  @override
  void initState() {
    final pharmacist = context.read<PharmacistProvider>().pharmacistModel!;
    supabase
        .from('pharmacy')
        .select('*')
        .eq('id', pharmacist.pharmacyId)
        .single()
        .then((value) {
      setState(() {
        profileImageUrl = value['profile_image_url'];
        name = value['name'];
        worktime = value['worktime'];
        postcode = value['postcode'];
        address = value['address'];
        addressDetail = value['address_detail'];
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final pharmacist = context.read<PharmacistProvider>().pharmacistModel!;

    return FutureBuilder(
        future: supabase
            .from('pharmacy')
            .select('*')
            .eq('id', pharmacist.pharmacyId)
            .single(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          profileImageUrl = snapshot.data['profile_image_url'];
          name = snapshot.data['name'];
          worktime = snapshot.data['worktime'];
          postcode = snapshot.data['postcode'];
          address = snapshot.data['address'];
          addressDetail = snapshot.data['address_detail'];
          lat = snapshot.data['latitude'];
          lon = snapshot.data['longitude'];
          return Scaffold(
            resizeToAvoidBottomInset: false,
            appBar: AppBar(
              backgroundColor: Colors.white,
              surfaceTintColor: Colors.white,
              title: Text(isEditing ? '수정하기' : '약국 정보',
                  style: TextStyle(
                      fontWeight: PgFontWeight.medium,
                      fontSize: PgFontSize.base.fontSize,
                      height: PgFontSize.base.height)),
            ),
            body: SingleChildScrollView(
                child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('약국 프로필 이미지',
                              style: TextStyle(
                                  fontWeight: PgFontWeight.medium,
                                  fontSize: PgFontSize.base.fontSize,
                                  height: PgFontSize.base.height)),
                          PgGaps.h2,
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: profileImageUrl == ''
                                      ? Image.asset(
                                          'assets/images/user.png',
                                          width: 128,
                                          height: 128,
                                          fit: BoxFit.cover,
                                        )
                                      : Image.network(
                                          profileImageUrl,
                                          width: 128,
                                          height: 128,
                                          fit: BoxFit.cover,
                                        )),
                              PgGaps.w2,
                              isEditing
                                  ? PgMiniButton(
                                      onTap: () async {
                                        final pickedImage = await ImagePicker()
                                            .pickImage(
                                                source: ImageSource.gallery);
                                        final file = pickedImage == null
                                            ? null
                                            : File(pickedImage.path);
                                        String path = await supabase.storage
                                            .from('pillgood_bucket')
                                            .upload(
                                                'profile/${file!.path.split('/').last}',
                                                file);
                                        path =
                                            'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/$path';
                                        setState(() {
                                          profileImageUrl = path;
                                        });
                                      },
                                    )
                                  : const SizedBox.shrink()
                            ],
                          ),
                          PgGaps.h6,
                          Text('약국 이름',
                              style: TextStyle(
                                  fontWeight: PgFontWeight.medium,
                                  fontSize: PgFontSize.base.fontSize,
                                  height: PgFontSize.base.height)),
                          PgGaps.h2,
                          PgInput(
                            labelText: '약국 이름',
                            initialValue: name,
                            enabled: isEditing,
                            onChanged: (value) {
                              setState(() {
                                name = value;
                              });
                            },
                          ),
                          PgGaps.h6,
                          Text('운영 시간',
                              style: TextStyle(
                                  fontWeight: PgFontWeight.medium,
                                  fontSize: PgFontSize.base.fontSize,
                                  height: PgFontSize.base.height)),
                          PgGaps.h2,
                          PgInput(
                            labelText: '운영 시간',
                            initialValue: worktime,
                            enabled: isEditing,
                            onChanged: (value) {
                              setState(() {
                                worktime = value;
                              });
                            },
                          ),
                          PgGaps.h6,
                          Text('주소',
                              style: TextStyle(
                                  fontWeight: PgFontWeight.medium,
                                  fontSize: PgFontSize.base.fontSize,
                                  height: PgFontSize.base.height)),
                          PgGaps.h2,
                          isEditing
                              ? Row(
                                  children: [
                                    Expanded(
                                      child: PgInput(
                                        disabledText: postcode != null
                                            ? postcode!
                                            : '우편번호',
                                        labelText: postcode != null
                                            ? postcode!
                                            : '우편번호',
                                        initialValue: postcode,
                                        enabled: false,
                                      ),
                                    ),
                                    PgGaps.w2,
                                    SizedBox(
                                      width: 100,
                                      child: PgButton(
                                        onTap: () {
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    SearchAddressScreen(),
                                                fullscreenDialog: true),
                                          ).then((value) async {
                                            DataModel dataModel =
                                                value as DataModel;
                                            KakaoApiService kakaoApiService =
                                                KakaoApiService();

                                            final response =
                                                await kakaoApiService
                                                    .searchByKeyword(
                                                        dataModel.address);

                                            setState(() {
                                              postcode = dataModel.zonecode;
                                              address = dataModel.address;
                                              if (response?.lat != null &&
                                                  response?.lon != null) {
                                                lat = response!.lat;
                                                lon = response.lon;
                                              }
                                            });
                                          });
                                        },
                                        child: Text(
                                          '주소 찾기',
                                          style: TextStyle(
                                              fontWeight: PgFontWeight.bold,
                                              fontSize:
                                                  PgFontSize.base.fontSize,
                                              height: PgFontSize.base.height,
                                              color: PgColors.white),
                                        ),
                                      ),
                                    )
                                  ],
                                )
                              : PgInput(
                                  labelText: '우편번호',
                                  initialValue: postcode,
                                  enabled: false,
                                ),
                          PgGaps.h2,
                          PgInput(
                            labelText: '주소',
                            initialValue: address,
                            enabled: false,
                          ),
                          PgGaps.h2,
                          isEditing
                              ? PgInput(
                                  labelText: '상세 주소',
                                  initialValue: addressDetail,
                                  enabled: true,
                                  onChanged: (value) {
                                    setState(() {
                                      addressDetail = value;
                                    });
                                  },
                                )
                              : PgInput(
                                  labelText: '상세 주소',
                                  initialValue: addressDetail,
                                  enabled: false,
                                ),
                          const SizedBox(
                            height: 100,
                          )
                        ]))),
            floatingActionButton: PartnerInfoFab(
              isEditing: isEditing,
              onTap: () {
                setState(() {
                  isEditing = !isEditing;
                });
              },
              onEdit: () async {
                final response = await supabase
                    .from('pharmacy')
                    .update({
                      'profile_image_url': profileImageUrl,
                      'name': name,
                      'worktime': worktime,
                      'postcode': postcode,
                      'address': address,
                      'address_detail': addressDetail,
                      'latitude': lat,
                      'longitude': lon
                    })
                    .eq('id', pharmacist.pharmacyId)
                    .select()
                    .single();

                Navigator.pop(context);
              },
              text: isEditing ? '저장하기' : '수정하기',
            ),
            floatingActionButtonLocation:
                FloatingActionButtonLocation.centerDocked,
          );
        });
  }
}
