import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/constants/pg_icons.dart';
import 'package:pillgood_client/models/pharmacy_model.dart';
import 'package:pillgood_client/providers/pharmacist_provider.dart';
import 'package:pillgood_client/screens/partner/my_chat_card.dart';
import 'package:pillgood_client/screens/partner/partner_chat_card.dart';
import 'package:pillgood_client/screens/partner/settings_body.dart';
import 'package:pillgood_client/widgets/pg_header.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';
import 'package:pillgood_client/widgets/pg_toggle.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PartnerHomeScreen extends StatefulWidget {
  const PartnerHomeScreen({super.key});

  @override
  State<PartnerHomeScreen> createState() => _PartnerHomeScreenState();
}

class _PartnerHomeScreenState extends State<PartnerHomeScreen>
    with SingleTickerProviderStateMixin {
  int index = 0;
  int tabBarIndex = 0;
  bool isWorking = false;
  final supabase = Supabase.instance.client;
  late TabController tabController;

  late Stream<List<dynamic>> _chatsStream;
  late Future<PharmacyModel> pharmacy;

  Future<PharmacyModel> getPharmacyModel(int id) async {
    final response =
        await supabase.from('pharmacy').select('*').eq('id', id).single();
    final pharmacyModel = PharmacyModel.fromJson(response);
    isWorking = pharmacyModel.isWorking;
    return pharmacyModel;
  }

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
    final pharmacist = context.read<PharmacistProvider>().pharmacistModel;
    pharmacy = getPharmacyModel(pharmacist!.pharmacyId);
    _chatsStream = supabase
        .from('chat')
        .stream(primaryKey: ['id'])
        .eq('pharmacy_id',
            context.read<PharmacistProvider>().pharmacistModel!.pharmacyId)
        .order('updated_at', ascending: false);
    @override
    void initState() {
      super.initState();

      FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
        // delay until widget is built
        WidgetsBinding.instance.addPostFrameCallback((_) {
          // get current route
          // if current route is partner home, then push to partner chat
          // else push to chat
          Future.delayed(const Duration(seconds: 1), () {
            Navigator.popUntil(context, ModalRoute.withName('/partner/home'));
            Navigator.pushNamed(context, '/partner/chat',
                arguments: {'roomId': message.data['roomId']});
          });
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final pharmacist = context.watch<PharmacistProvider>().pharmacistModel;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: PgHeader(
        onPressed: () {
          setState(() {
            index = 0;
          });
        },
        actions: [
          PgIcon(
            PgIcons.bars3,
            color: index == 1 ? PgColors.violet_500 : PgColors.gray_800,
            onTap: () {
              setState(() {
                index = 1;
              });
            },
          ),
        ],
      ),
      body: index == 0
          ? FutureBuilder(
              future: pharmacy,
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  return Column(
                    children: [
                      Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 24.0),
                          child: Column(children: [
                            Row(
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: Image.network(
                                    snapshot.data!.profileImageUrl,
                                    width: 40,
                                    height: 40,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                PgGaps.w4,
                                Text(
                                  snapshot.data!.name,
                                  style: TextStyle(
                                      fontSize: PgFontSize.xl.fontSize,
                                      fontWeight: PgFontWeight.bold,
                                      height: PgFontSize.xl.height),
                                ),
                              ],
                            ),
                            PgGaps.h6,
                            Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(24),
                                decoration: BoxDecoration(
                                    color: isWorking
                                        ? PgColors.violet_400
                                        : PgColors.gray_500,
                                    borderRadius: BorderRadius.circular(8)),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      isWorking ? '영업중' : '영업종료',
                                      style: TextStyle(
                                          fontSize: PgFontSize.xl.fontSize,
                                          fontWeight: PgFontWeight.bold,
                                          height: PgFontSize.xl.height,
                                          color: PgColors.white),
                                    ),
                                    PgToggle(
                                      value: isWorking,
                                      onChanged: (value) {
                                        setState(() {
                                          isWorking = !value;
                                          supabase
                                              .from('pharmacy')
                                              .update({'is_working': isWorking})
                                              .eq('id', pharmacist!.pharmacyId)
                                              .then((_) => isWorking = !value);
                                        });
                                      },
                                    ),
                                  ],
                                )),
                          ])),
                      TabBar(
                          controller: tabController,
                          overlayColor: MaterialStateColor.resolveWith(
                              (states) => Colors.transparent),
                          indicatorSize: TabBarIndicatorSize.tab,
                          onTap: (value) {
                            setState(() {
                              tabBarIndex = value;
                            });
                          },
                          tabs: [
                            Tab(
                              child: Text(
                                '전체 채팅',
                                style: TextStyle(
                                    fontSize: PgFontSize.base.fontSize,
                                    fontWeight: tabBarIndex == 0
                                        ? PgFontWeight.bold
                                        : PgFontWeight.medium,
                                    height: PgFontSize.base.height,
                                    color: tabBarIndex == 0
                                        ? PgColors.violet_500
                                        : PgColors.gray_300),
                              ),
                            ),
                            Tab(
                              child: Text(
                                '내 채팅',
                                style: TextStyle(
                                    fontSize: PgFontSize.base.fontSize,
                                    fontWeight: tabBarIndex == 1
                                        ? PgFontWeight.bold
                                        : PgFontWeight.medium,
                                    height: PgFontSize.base.height,
                                    color: tabBarIndex == 1
                                        ? PgColors.violet_500
                                        : PgColors.gray_300),
                              ),
                            ),
                          ]),
                      Expanded(
                        child: StreamBuilder(
                            stream: _chatsStream,
                            builder: (context, snapshot) {
                              if (snapshot.hasData) {
                                final chats = snapshot.data!;
                                final myChats = chats
                                    .where((element) =>
                                        element['pharmacist_id'] != null &&
                                        element['pharmacist_id'] ==
                                            pharmacist!.userId)
                                    .toList();
                                for (final myChat in myChats) {
                                  print(myChat['id']);
                                }

                                if (tabBarIndex == 0) {
                                  return ListView.builder(
                                      itemBuilder: ((context, index) =>
                                          PartnerChatCard(
                                              chatId: chats[index]['id'],
                                              updatedAt: DateTime.parse(
                                                  chats[index]['updated_at']),
                                              pharmacyId: chats[index]
                                                  ['pharmacy_id'],
                                              pharmacistId: chats[index]
                                                  ['pharmacist_id'])),
                                      itemCount: chats.length);
                                } else {
                                  return ListView.builder(
                                      itemBuilder: ((context, index) =>
                                          MyChatCard(
                                              chatId: myChats[index]['id'],
                                              updatedAt: DateTime.parse(
                                                  myChats[index]['updated_at']),
                                              pharmacyId: myChats[index]
                                                  ['pharmacy_id'],
                                              pharmacistId: myChats[index]
                                                  ['pharmacist_id'])),
                                      // Text(
                                      //     myChats[index]['id'].toString())),
                                      itemCount: myChats.length);
                                }
                              } else {
                                return const Center(
                                    child: CircularProgressIndicator());
                              }
                            }),
                      )
                    ],
                  );
                } else {
                  return const Center(child: CircularProgressIndicator());
                }
              },
            )
          : SettingsBody(),
    );
  }
}
