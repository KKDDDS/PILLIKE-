import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';

class MemberCard extends StatefulWidget {
  final String userId;
  final String name;
  final String type;
  final bool isOwner;
  final bool showChip;
  final Function? onDelete;
  final Function? onAccept;
  const MemberCard(
      {super.key,
      required this.userId,
      required this.name,
      required this.type,
      this.isOwner = false,
      this.showChip = true,
      this.onDelete,
      this.onAccept});

  @override
  State<MemberCard> createState() => _MemberCardState();
}

class _MemberCardState extends State<MemberCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.all(16),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Row(
            children: [
              widget.showChip
                  ? _MemberTypeChip(memberType: widget.type)
                  : const SizedBox(),
              PgGaps.w2,
              Text(
                widget.name,
                style: TextStyle(
                  fontSize: PgFontSize.base.fontSize,
                  height: PgFontSize.base.height,
                  fontWeight: PgFontWeight.bold,
                  color: PgColors.gray_900,
                ),
              ),
            ],
          ),
          widget.isOwner && widget.type == 'MEMBER' && widget.showChip
              ? TextButton(
                  onPressed: () {
                    if (widget.onDelete != null) widget.onDelete!();
                  },
                  child: const Text('삭제'),
                )
              : widget.showChip
                  ? const SizedBox.shrink()
                  : Row(
                      children: [
                        GestureDetector(
                          onTap: () {
                            if (widget.onAccept != null) widget.onAccept!();
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              color: PgColors.violet_500,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              '승인하기',
                              style: TextStyle(
                                  color: PgColors.white,
                                  fontWeight: PgFontWeight.bold,
                                  fontSize: PgFontSize.sm.fontSize,
                                  height: PgFontSize.sm.height),
                            ),
                          ),
                        ),
                        PgGaps.w2,
                        GestureDetector(
                          onTap: () {
                            if (widget.onDelete != null) widget.onDelete!();
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: PgColors.gray_500),
                            ),
                            child: Text(
                              '거절',
                              style: TextStyle(
                                  color: PgColors.gray_500,
                                  fontWeight: PgFontWeight.bold,
                                  fontSize: PgFontSize.sm.fontSize,
                                  height: PgFontSize.sm.height),
                            ),
                          ),
                        ),
                      ],
                    )
        ]));
  }
}

class _MemberTypeChip extends StatelessWidget {
  final String memberType;
  const _MemberTypeChip({super.key, required this.memberType});

  getMemberTypeString() {
    switch (memberType) {
      case 'OWNER':
        return '약국장';
      case 'MEMBER':
        return '약사';
      default:
        return '약사';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: memberType == 'OWNER' ? PgColors.violet_100 : PgColors.gray_100,
        borderRadius: BorderRadius.circular(6),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      child: Text(
        getMemberTypeString(),
        style: TextStyle(
          fontSize: PgFontSize.sm.fontSize,
          height: PgFontSize.sm.height,
          fontWeight: PgFontWeight.bold,
          color:
              memberType == 'OWNER' ? PgColors.violet_500 : PgColors.gray_500,
        ),
      ),
    );
  }
}
