import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/providers/pharmacist_provider.dart';
import 'package:pillgood_client/screens/partner/members/member_card.dart';
import 'package:pillgood_client/widgets/pg_dialog.dart';
import 'package:pillgood_client/widgets/pg_divider.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MembersScreen extends StatefulWidget {
  const MembersScreen({super.key});

  @override
  State<MembersScreen> createState() => _MembersScreenState();
}

class _MembersScreenState extends State<MembersScreen> {
  final supabase = Supabase.instance.client;
  Future<Set> getPharmacyAndMembers() async {
    final pharmacist = context.read<PharmacistProvider>().pharmacistModel;
    final pharmacy = await supabase
        .from('pharmacy')
        .select('*')
        .eq('id', pharmacist?.pharmacyId)
        .single();
    final members = await supabase
        .from('pharmacist')
        .select('*')
        .eq('pharmacy_id', pharmacist?.pharmacyId);

    return {pharmacy, members};
  }

  removeMember(String userId) async {
    final response =
        await supabase.from('pharmacist').delete().eq('user_id', userId);

    return response;
  }

  acceptMember(String userId) async {
    final response = await supabase
        .from('pharmacist')
        .update({'is_verified': true}).eq('user_id', userId);

    return response;
  }

  @override
  Widget build(BuildContext context) {
    final isOwner =
        context.read<PharmacistProvider>().pharmacistModel!.type == 'OWNER';
    return FutureBuilder(
        future: getPharmacyAndMembers(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final pharmacy = snapshot.data!.elementAt(0);
          final List<dynamic> members = snapshot.data!.elementAt(1);

          final invitedMembers = members.where((element) {
            return element['type'] == 'MEMBER' &&
                element['is_verified'] == false;
          }).toList();
          final verifiedMembers = members.where((element) {
            return element['is_verified'];
          }).toList();

          return Scaffold(
              resizeToAvoidBottomInset: false,
              appBar: AppBar(
                backgroundColor: Colors.white,
                surfaceTintColor: Colors.white,
                title: Text('멤버관리',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        fontSize: PgFontSize.base.fontSize,
                        height: PgFontSize.base.height)),
              ),
              body: SingleChildScrollView(
                child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: double.infinity,
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: PgColors.violet_50,
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '멤버 초대 코드',
                                style: TextStyle(
                                  color: PgColors.violet_400,
                                  fontSize: PgFontSize.sm.fontSize,
                                  height: PgFontSize.sm.height,
                                  fontWeight: PgFontWeight.medium,
                                ),
                              ),
                              PgGaps.h2,
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    pharmacy['invitation_code'],
                                    style: TextStyle(
                                      color: PgColors.violet_500,
                                      fontSize: PgFontSize.xl_2.fontSize,
                                      height: PgFontSize.xl_2.height,
                                      fontWeight: PgFontWeight.bold,
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      Clipboard.setData(ClipboardData(
                                          text: pharmacy['invitation_code']));
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(SnackBar(
                                        content: Text('복사되었습니다.'),
                                        duration: Duration(seconds: 1),
                                      ));
                                    },
                                    child: Text(
                                      '복사하기',
                                      style: TextStyle(
                                          color: PgColors.violet_400,
                                          fontSize: PgFontSize.sm.fontSize,
                                          height: PgFontSize.sm.height,
                                          fontWeight: PgFontWeight.medium,
                                          decoration: TextDecoration.underline,
                                          decorationColor: PgColors.violet_400),
                                    ),
                                  )
                                ],
                              ),
                            ],
                          ),
                        ),
                        invitedMembers.isNotEmpty
                            ? Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  PgGaps.h8,
                                  Text('초대 요청 ${invitedMembers.length}',
                                      style: TextStyle(
                                          fontWeight: PgFontWeight.bold,
                                          fontSize: PgFontSize.lg.fontSize,
                                          height: PgFontSize.lg.height,
                                          color: PgColors.gray_900)),
                                  PgGaps.h2,
                                  Container(
                                    padding:
                                        const EdgeInsets.symmetric(vertical: 8),
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                        color: PgColors.gray_100,
                                      ),
                                      borderRadius: BorderRadius.circular(16),
                                    ),
                                    child: Column(
                                      children: invitedMembers
                                          .asMap()
                                          .entries
                                          .map((entry) {
                                        final e = entry.value;
                                        final index = entry.key;
                                        if (index < invitedMembers.length - 1) {
                                          return Column(
                                            children: [
                                              MemberCard(
                                                showChip: false,
                                                userId: e['user_id'],
                                                name: e['name'],
                                                type: e['type'],
                                                isOwner: isOwner,
                                                onAccept: () {
                                                  acceptMember(e['user_id']);
                                                  Navigator.pop(context);
                                                },
                                                onDelete: () {
                                                  showDialog(
                                                      context: context,
                                                      barrierColor: PgColors
                                                          .black
                                                          .withOpacity(0.8),
                                                      builder: (_) => PgDialog(
                                                            title: '확인해주세요!',
                                                            description:
                                                                '${e['name']}님을 삭제하시겠어요?',
                                                            buttonLabel: '삭제하기',
                                                            onPressed: () {
                                                              removeMember(
                                                                  e['user_id']);
                                                              Navigator.pop(
                                                                  context);
                                                            },
                                                          ));
                                                },
                                              ),
                                              const PgDivider(),
                                            ],
                                          );
                                        } else {
                                          return Column(
                                            children: [
                                              MemberCard(
                                                showChip: false,
                                                userId: e['user_id'],
                                                name: e['name'],
                                                type: e['type'],
                                                isOwner: isOwner,
                                                onAccept: () {
                                                  acceptMember(e['user_id']);
                                                  Navigator.pop(context);
                                                },
                                                onDelete: () {
                                                  showDialog(
                                                      context: context,
                                                      barrierColor: PgColors
                                                          .black
                                                          .withOpacity(0.8),
                                                      builder: (_) => PgDialog(
                                                            title: '확인해주세요!',
                                                            description:
                                                                '${e['name']}님을 삭제하시겠어요?',
                                                            buttonLabel: '삭제하기',
                                                            onPressed: () {
                                                              removeMember(
                                                                  e['user_id']);
                                                              Navigator.pop(
                                                                  context);
                                                            },
                                                          ));
                                                },
                                              ),
                                            ],
                                          );
                                        }
                                      }).toList(),
                                    ),
                                  )
                                ],
                              )
                            : const SizedBox(),
                        PgGaps.h8,
                        Text('멤버 ${verifiedMembers.length}',
                            style: TextStyle(
                                fontWeight: PgFontWeight.bold,
                                fontSize: PgFontSize.lg.fontSize,
                                height: PgFontSize.lg.height,
                                color: PgColors.gray_900)),
                        PgGaps.h2,
                        Container(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: PgColors.gray_100,
                            ),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: Column(
                            children:
                                verifiedMembers.asMap().entries.map((entry) {
                              final e = entry.value;
                              final index = entry.key;
                              if (index < verifiedMembers.length - 1) {
                                return Column(
                                  children: [
                                    MemberCard(
                                      userId: e['user_id'],
                                      name: e['name'],
                                      type: e['type'],
                                      isOwner: isOwner,
                                      onDelete: () {
                                        showDialog(
                                            context: context,
                                            barrierColor:
                                                PgColors.black.withOpacity(0.8),
                                            builder: (_) => PgDialog(
                                                  title: '확인해주세요!',
                                                  description:
                                                      '${e['name']}님을 삭제하시겠어요?',
                                                  buttonLabel: '삭제하기',
                                                  onPressed: () {},
                                                ));
                                      },
                                    ),
                                    const PgDivider(),
                                  ],
                                );
                              } else {
                                return Column(
                                  children: [
                                    MemberCard(
                                      userId: e['user_id'],
                                      name: e['name'],
                                      type: e['type'],
                                      isOwner: isOwner,
                                      onDelete: () {
                                        showDialog(
                                            context: context,
                                            barrierColor:
                                                PgColors.black.withOpacity(0.8),
                                            builder: (_) => PgDialog(
                                                  title: '확인해주세요!',
                                                  description:
                                                      '${e['name']}님을 삭제하시겠어요?',
                                                  buttonLabel: '삭제하기',
                                                  onPressed: () {},
                                                ));
                                      },
                                    ),
                                  ],
                                );
                              }
                            }).toList(),
                          ),
                        )
                      ],
                    )),
              ));
        });
  }
}
