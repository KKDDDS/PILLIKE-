import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/constants/pg_icons.dart';
import 'package:pillgood_client/constants/pg_sizes.dart';
import 'package:pillgood_client/providers/information_provider.dart';
import 'package:pillgood_client/widgets/pg_fab.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';
import 'package:pillgood_client/widgets/pg_input.dart';
import 'package:pillgood_client/widgets/pg_mini_button.dart';
import 'package:pillgood_client/widgets/pg_title.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final supabase = Supabase.instance.client;

  @override
  Widget build(BuildContext context) {
    final information = context.watch<InformationProvider>();
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const PharmacyBanner(),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const PgTitle(),
                      PgGaps.h6,
                      const Text(
                        '프로필 이미지 (선택)',
                        style: TextStyle(
                            fontWeight: PgFontWeight.medium,
                            color: PgColors.gray_900),
                      ),
                      PgGaps.h2,
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: information.profileImageUrl == ''
                                ? Image.asset(
                                    'assets/images/user.png',
                                    width: 128,
                                    height: 128,
                                    fit: BoxFit.cover,
                                  )
                                : Image.network(
                                    information.profileImageUrl,
                                    width: 128,
                                    height: 128,
                                    fit: BoxFit.cover,
                                  ),
                          ),
                          PgGaps.w2,
                          PgMiniButton(
                            onTap: () async {
                              final pickedImage = await ImagePicker()
                                  .pickImage(source: ImageSource.gallery);
                              final file = pickedImage == null
                                  ? null
                                  : File(pickedImage.path);
                              String path = await supabase.storage
                                  .from('pillgood_bucket')
                                  .upload(
                                      'profile/${file!.path.split('/').last}',
                                      file);
                              path =
                                  'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/$path';
                              information.setProfileImageUrl(path);
                            },
                          )
                        ],
                      ),
                      PgGaps.h6,
                      const Text(
                        '이름',
                        style: TextStyle(
                            fontWeight: PgFontWeight.medium,
                            color: PgColors.gray_900),
                      ),
                      PgGaps.h2,
                      PgInput(
                        labelText: '이름을 입력해주세요',
                        initialValue: information.name,
                        onChanged: (value) {
                          information.setName(value);
                        },
                      ),
                    ]),
              )
            ],
          ),
        ),
      ),
      resizeToAvoidBottomInset: false,
      floatingActionButton: PgFAB(
        onTap: () {
          Navigator.pushNamed(context, '/info');
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}

class PharmacyBanner extends StatelessWidget {
  const PharmacyBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamedAndRemoveUntil(
            context, '/signup/partner', (route) => false);
      },
      child: Container(
          decoration: const BoxDecoration(
              color: PgColors.gray_50,
              border: Border(bottom: BorderSide(color: PgColors.gray_100))),
          padding: const EdgeInsets.all(PgSizes.size4),
          width: double.infinity,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '약사분이신가요?',
                    style: TextStyle(
                        fontWeight: PgFontWeight.bold,
                        color: PgColors.gray_500),
                  ),
                  Text(
                    '약사로 회원가입하기',
                    style: TextStyle(fontSize: 12, color: PgColors.gray_500),
                  )
                ],
              ),
              PgIcon(
                PgIcons.arrowRight,
                color: PgColors.gray_500,
              )
            ],
          )),
    );
  }
}
