import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/models/profile_model.dart';
import 'package:pillgood_client/providers/fcm_token_provider.dart';
import 'package:pillgood_client/providers/information_provider.dart';
import 'package:pillgood_client/providers/profile_provider.dart';
import 'package:pillgood_client/widgets/pg_checkbox.dart';
import 'package:pillgood_client/widgets/pg_divider.dart';
import 'package:pillgood_client/widgets/pg_fab.dart';
import 'package:pillgood_client/widgets/pg_input.dart';
import 'package:pillgood_client/widgets/pg_radio.dart';
import 'package:pillgood_client/widgets/pg_selector.dart';
import 'package:pillgood_client/widgets/pg_title.dart';
import 'package:provider/provider.dart';

class InfoScreen extends StatefulWidget {
  const InfoScreen({super.key});

  @override
  State<InfoScreen> createState() => _InfoScreenState();
}

class _InfoScreenState extends State<InfoScreen> {
  bool _isMale = true;
  String _birthYear = '2000';
  List<String> birthYearOptions = [];
  String _drinking = '거의 하지 않음';
  List<String> drinkingOptions = [
    '거의 하지 않음',
    '한 달에 한 번',
    '한 달에 두 번 이상',
  ];
  String _smoking = '비흡연';
  List<String> smokingOptions = [
    '비흡연',
    '흡연',
    '금연중',
  ];
  String _pregnant = '임신 가능성 없음';
  List<String> pregnantOptions = [
    '임신 가능성 없음',
    '임신 가능성 있음',
    '임신중',
  ];
  bool termsAgree = false;
  bool privacyAgree = false;

  @override
  void initState() {
    for (int i = 2021; i >= 1900; i--) {
      birthYearOptions.add(i.toString());
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final information = context.watch<InformationProvider>();
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
          child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const PgTitle(
                subtitle: '정확한 안내를 위해',
                title: '세부 정보를 입력해주세요',
              ),
              PgGaps.h6,
              const Text(
                '성별',
                style: TextStyle(
                    fontWeight: PgFontWeight.medium, color: PgColors.gray_900),
              ),
              PgGaps.h2,
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                    color: PgColors.violet_50,
                    border: Border.all(color: PgColors.violet_100),
                    borderRadius: BorderRadius.circular(16.0)),
                child: Row(
                  children: [
                    PgRadio(
                      checked: _isMale,
                      onChanged: (value) {
                        setState(() {
                          _isMale = !_isMale;
                        });
                        information.setSex(_isMale ? '남성' : '여성');
                      },
                    ),
                    PgGaps.w4,
                    const Text(
                      '남성',
                      style: TextStyle(
                          fontWeight: PgFontWeight.medium,
                          color: PgColors.gray_900),
                    ),
                    PgGaps.w4,
                    PgRadio(
                      checked: !_isMale,
                      onChanged: (value) {
                        setState(() {
                          _isMale = !_isMale;
                        });
                        information.setSex(_isMale ? '남성' : '여성');
                      },
                    ),
                    PgGaps.w4,
                    const Text(
                      '여성',
                      style: TextStyle(
                          fontWeight: PgFontWeight.medium,
                          color: PgColors.gray_900),
                    ),
                  ],
                ),
              ),
              PgGaps.h6,
              const Text(
                '출생년도',
                style: TextStyle(
                    fontWeight: PgFontWeight.medium, color: PgColors.gray_900),
              ),
              PgGaps.h2,
              PgSelector(
                labelText: _birthYear,
                options: birthYearOptions,
                onChanged: (value) {
                  setState(() {
                    _birthYear = value;
                  });
                  information.setBirthYear(int.parse(_birthYear));
                },
              ),
              PgGaps.h6,
              const Text(
                '음주 여부',
                style: TextStyle(
                    fontWeight: PgFontWeight.medium, color: PgColors.gray_900),
              ),
              PgGaps.h2,
              PgSelector(
                labelText: _drinking,
                options: drinkingOptions,
                onChanged: (value) {
                  setState(() {
                    _drinking = value;
                  });
                  information.setDrinking(_drinking);
                },
              ),
              PgGaps.h6,
              const Text(
                '흡연 여부',
                style: TextStyle(
                    fontWeight: PgFontWeight.medium, color: PgColors.gray_900),
              ),
              PgGaps.h2,
              PgSelector(
                labelText: _smoking,
                options: smokingOptions,
                onChanged: (value) {
                  setState(() {
                    _smoking = value;
                  });
                  information.setSmoking(_smoking);
                },
              ),
              PgGaps.h6,
              const Text(
                '임신 가능성',
                style: TextStyle(
                    fontWeight: PgFontWeight.medium, color: PgColors.gray_900),
              ),
              PgGaps.h2,
              PgSelector(
                labelText: _pregnant,
                options: pregnantOptions,
                onChanged: (value) {
                  setState(() {
                    _pregnant = value;
                  });
                  information.setPregnant(_pregnant);
                },
              ),
              PgGaps.h6,
              const Text(
                '지병 (선택)',
                style: TextStyle(
                    fontWeight: PgFontWeight.medium, color: PgColors.gray_900),
              ),
              PgGaps.h2,
              PgInput(
                labelText: '앓고 계신 지병이 있다면 적어주세요',
                onChanged: (value) {
                  information.setDisease(value);
                },
              ),
              PgGaps.h6,
              const Text(
                '주의해야 할 의약품 (선택)',
                style: TextStyle(
                    fontWeight: PgFontWeight.medium, color: PgColors.gray_900),
              ),
              PgGaps.h2,
              PgInput(
                labelText: '주의해야 할 의약품이 있다면 적어주세요',
                onChanged: (value) {
                  information.setCautions(value);
                },
              ),
              PgGaps.h6,
              const PgDivider(),
              PgGaps.h6,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pushNamed(context, '/browser', arguments: {
                          'url':
                              'https://aromatic-star-e53.notion.site/35224fc8937d486ebcaede1527a9adf4',
                          'title': '이용약관',
                        });
                      },
                      behavior: HitTestBehavior.opaque,
                      child: Text(
                        '이용약관 동의',
                        style: TextStyle(
                            fontWeight: PgFontWeight.medium,
                            color: PgColors.gray_900),
                      ),
                    ),
                  ),
                  PgCheckBox(
                    checked: termsAgree,
                    onChanged: (value) {
                      setState(() {
                        termsAgree = !termsAgree;
                      });
                      information.setTermsAgree(termsAgree);
                    },
                  )
                ],
              ),
              PgGaps.h6,
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pushNamed(context, '/browser', arguments: {
                          'url':
                              'https://aromatic-star-e53.notion.site/10dc44bf62514e3db5831e88ff2cc84f',
                          'title': '개인정보 처리방침',
                        });
                      },
                      behavior: HitTestBehavior.opaque,
                      child: Text(
                        '개인정보 처리방침 동의',
                        style: TextStyle(
                            fontWeight: PgFontWeight.medium,
                            color: PgColors.gray_900),
                      ),
                    ),
                  ),
                  PgCheckBox(
                    checked: privacyAgree,
                    onChanged: (value) {
                      setState(() {
                        privacyAgree = !privacyAgree;
                      });
                      information.setPrivacyAgree(privacyAgree);
                    },
                  )
                ],
              ),
              const SizedBox(
                height: 100,
              )
            ],
          ),
        ),
      )),
      floatingActionButton: PgFAB(
        disabled: !termsAgree || !privacyAgree || information.isCreating,
        onTap: () async {
          final fcmToken = context.read<FcmTokenProvider>().fcmToken;
          final data = await information.create(fcmToken);
          if (data != null) {
            context
                .read<ProfileProvider>()
                .setProfile(ProfileModel.fromJson(data));
            Navigator.pushNamedAndRemoveUntil(
                context, '/map', (route) => false);
          }
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}

enum Sex { male, female }

class SexRadioButton extends StatelessWidget {
  final Sex sex;
  const SexRadioButton({super.key, this.sex = Sex.male});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
