import 'dart:io';
import 'dart:math';

import 'package:daum_postcode_search/daum_postcode_search.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/constants/pg_icons.dart';
import 'package:pillgood_client/constants/pg_sizes.dart';
import 'package:pillgood_client/models/pharmacist_model.dart';
import 'package:pillgood_client/providers/fcm_token_provider.dart';
import 'package:pillgood_client/providers/pharmacist_provider.dart';
import 'package:pillgood_client/screens/signup/partner/search_address_screen.dart';
import 'package:pillgood_client/services/kakao_api_service.dart';
import 'package:pillgood_client/widgets/pg_button.dart';
import 'package:pillgood_client/widgets/pg_checkbox.dart';
import 'package:pillgood_client/widgets/pg_divider.dart';
import 'package:pillgood_client/widgets/pg_fab.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';
import 'package:pillgood_client/widgets/pg_input.dart';
import 'package:pillgood_client/widgets/pg_mini_button.dart';
import 'package:pillgood_client/widgets/pg_title.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class NewPartnerScreen extends StatefulWidget {
  const NewPartnerScreen({super.key});

  @override
  State<NewPartnerScreen> createState() => _NewPartnerScreenState();
}

class _NewPartnerScreenState extends State<NewPartnerScreen> {
  bool termsAgree = false;
  bool privacyAgree = false;
  String profileImageUrl = '';
  String verifyDocumentUrl = '';
  String pharmacistVerifyDocumentUrl = '';
  String? postcode;
  String? address;
  String addressDetail = '';

  String name = '';
  String ownerName = '';
  String worktime = '';
  final supabase = Supabase.instance.client;
  bool disabled = true;

  double lat = 0;
  double lon = 0;

  bool getDisabled() {
    return profileImageUrl == '' ||
        verifyDocumentUrl == '' ||
        pharmacistVerifyDocumentUrl == '' ||
        !termsAgree ||
        !privacyAgree;
  }

  @override
  void setState(VoidCallback fn) {
    disabled = getDisabled();
    super.setState(fn);
  }

  var _chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz1234567890';
  Random _rnd = Random();
  String getRandomString(int length) => String.fromCharCodes(Iterable.generate(
      length, (_) => _chars.codeUnitAt(_rnd.nextInt(_chars.length))));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
          child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const NormalBanner(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const PgTitle(
                    subtitle: '약국 등록을 위해',
                    title: '정보를 입력해주세요',
                  ),
                  PgGaps.h6,
                  GestureDetector(
                    onTap: () {
                      Navigator.pushNamedAndRemoveUntil(
                          context, '/signup/partner/code', (route) => false);
                    },
                    child: Row(
                      children: [
                        Text('약국 초대코드 입력하기',
                            style: TextStyle(
                                fontWeight: PgFontWeight.medium,
                                fontSize: PgFontSize.base.fontSize,
                                height: PgFontSize.base.height,
                                color: PgColors.violet_500)),
                        PgIcon(
                          PgIcons.chevronRight,
                          size: IconSize.sm,
                          color: PgColors.violet_500,
                        )
                      ],
                    ),
                  ),
                  PgGaps.h6,
                  Text(
                    '약국 프로필 이미지',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        fontSize: PgFontSize.base.fontSize,
                        height: PgFontSize.base.height,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  profileImageUrl == ''
                      ? GestureDetector(
                          onTap: () async {
                            final pickedImage = await ImagePicker()
                                .pickImage(source: ImageSource.gallery);
                            final file = pickedImage == null
                                ? null
                                : File(pickedImage.path);
                            if (file == null) {
                              return;
                            }
                            String path = await supabase.storage
                                .from('pillgood_bucket')
                                .upload(
                                    'profile/${DateTime.now()}/${file!.path.split('/').last}',
                                    file);
                            path =
                                'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/$path';
                            setState(() {
                              profileImageUrl = path;
                            });
                          },
                          child: Image.asset(
                            'assets/images/image-upload.png',
                            width: 128,
                            height: 128,
                          ))
                      : Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.network(
                                profileImageUrl,
                                width: 128,
                                height: 128,
                                fit: BoxFit.cover,
                              ),
                            ),
                            const SizedBox(
                              width: 8,
                            ),
                            PgMiniButton(
                              onTap: () async {
                                final pickedImage = await ImagePicker()
                                    .pickImage(source: ImageSource.gallery);
                                final file = pickedImage == null
                                    ? null
                                    : File(pickedImage.path);
                                if (file == null) {
                                  return;
                                }
                                String path = await supabase.storage
                                    .from('pillgood_bucket')
                                    .upload(
                                        'profile/${DateTime.now()}/${file!.path.split('/').last}',
                                        file);
                                path =
                                    'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/$path';
                                setState(() {
                                  profileImageUrl = path;
                                });
                              },
                            )
                          ],
                        ),
                  PgGaps.h6,
                  Text(
                    '약국 이름',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        fontSize: PgFontSize.base.fontSize,
                        height: PgFontSize.base.height,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  PgInput(
                    labelText: '약국 이름을 적어주세요',
                    onChanged: (value) {
                      setState(() {
                        name = value;
                      });
                    },
                  ),
                  PgGaps.h6,
                  Text(
                    '약사명',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        fontSize: PgFontSize.base.fontSize,
                        height: PgFontSize.base.height,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  PgInput(
                    labelText: '홍길동',
                    onChanged: (value) {
                      setState(() {
                        ownerName = value;
                      });
                    },
                  ),
                  PgGaps.h6,
                  Text(
                    '운영시간',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        fontSize: PgFontSize.base.fontSize,
                        height: PgFontSize.base.height,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  PgInput(
                    labelText: '평일 8:00~20:00 / 주말 10:00~18:00',
                    onChanged: (value) {
                      setState(() {
                        worktime = value;
                      });
                    },
                  ),
                  PgGaps.h6,
                  Text(
                    '주소',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        fontSize: PgFontSize.base.fontSize,
                        height: PgFontSize.base.height,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  Row(
                    children: [
                      Expanded(
                        child: PgInput(
                          disabledText: postcode != null ? postcode! : '우편번호',
                          labelText: postcode != null ? postcode! : '우편번호',
                          initialValue: postcode,
                          enabled: false,
                        ),
                      ),
                      PgGaps.w2,
                      SizedBox(
                        width: 100,
                        child: PgButton(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => SearchAddressScreen(),
                                  fullscreenDialog: true),
                            ).then((value) async {
                              DataModel dataModel = value as DataModel;
                              KakaoApiService kakaoApiService =
                                  KakaoApiService();

                              final response = await kakaoApiService
                                  .searchByKeyword(dataModel.address);

                              setState(() {
                                postcode = dataModel.zonecode;
                                address = dataModel.address;
                                if (response?.lat != null &&
                                    response?.lon != null) {
                                  lat = response!.lat;
                                  lon = response.lon;
                                }
                              });
                            });
                          },
                          child: Text(
                            '주소 찾기',
                            style: TextStyle(
                                fontWeight: PgFontWeight.bold,
                                fontSize: PgFontSize.base.fontSize,
                                height: PgFontSize.base.height,
                                color: PgColors.white),
                          ),
                        ),
                      )
                    ],
                  ),
                  address != null
                      ? Column(
                          children: [
                            PgGaps.h2,
                            PgInput(
                              labelText: address!,
                              initialValue: address,
                              enabled: false,
                            ),
                            PgGaps.h2,
                            PgInput(
                              labelText: '101동 2001호',
                              onChanged: (value) {
                                setState(() {
                                  addressDetail = value;
                                });
                              },
                            ),
                          ],
                        )
                      : const SizedBox(),
                  PgGaps.h6,
                  Text(
                    '약국 인증 서류',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        fontSize: PgFontSize.base.fontSize,
                        height: PgFontSize.base.height,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  verifyDocumentUrl == ''
                      ? GestureDetector(
                          onTap: () async {
                            final pickedImage = await ImagePicker()
                                .pickImage(source: ImageSource.gallery);
                            final file = pickedImage == null
                                ? null
                                : File(pickedImage.path);
                            if (file == null) {
                              return;
                            }
                            String path = await supabase.storage
                                .from('pillgood_bucket')
                                .upload(
                                    'profile/${DateTime.now()}/${file!.path.split('/').last}',
                                    file);
                            path =
                                'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/$path';
                            setState(() {
                              verifyDocumentUrl = path;
                            });
                          },
                          child: Image.asset(
                            'assets/images/file-upload.png',
                            width: 128,
                            height: 128,
                          ))
                      : Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.network(
                                verifyDocumentUrl,
                                width: 128,
                                height: 128,
                                fit: BoxFit.cover,
                              ),
                            ),
                            PgGaps.w2,
                            PgMiniButton(
                              onTap: () async {
                                final pickedImage = await ImagePicker()
                                    .pickImage(source: ImageSource.gallery);
                                final file = pickedImage == null
                                    ? null
                                    : File(pickedImage.path);
                                if (file == null) {
                                  return;
                                }
                                String path = await supabase.storage
                                    .from('pillgood_bucket')
                                    .upload(
                                        'profile/${DateTime.now()}/${file!.path.split('/').last}',
                                        file);
                                path =
                                    'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/$path';
                                setState(() {
                                  verifyDocumentUrl = path;
                                });
                              },
                            )
                          ],
                        ),
                  PgGaps.h6,
                  Text(
                    '약사 인증 서류',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        fontSize: PgFontSize.base.fontSize,
                        height: PgFontSize.base.height,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  pharmacistVerifyDocumentUrl == ''
                      ? GestureDetector(
                          onTap: () async {
                            final pickedImage = await ImagePicker()
                                .pickImage(source: ImageSource.gallery);
                            final file = pickedImage == null
                                ? null
                                : File(pickedImage.path);
                            if (file == null) {
                              return;
                            }
                            String path = await supabase.storage
                                .from('pillgood_bucket')
                                .upload(
                                    'profile/${DateTime.now()}/${file!.path.split('/').last}',
                                    file);
                            path =
                                'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/$path';
                            setState(() {
                              pharmacistVerifyDocumentUrl = path;
                            });
                          },
                          child: Image.asset(
                            'assets/images/file-upload.png',
                            width: 128,
                            height: 128,
                          ))
                      : Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.network(
                                pharmacistVerifyDocumentUrl,
                                width: 128,
                                height: 128,
                                fit: BoxFit.cover,
                              ),
                            ),
                            PgGaps.w2,
                            PgMiniButton(
                              onTap: () async {
                                final pickedImage = await ImagePicker()
                                    .pickImage(source: ImageSource.gallery);
                                final file = pickedImage == null
                                    ? null
                                    : File(pickedImage.path);
                                if (file == null) {
                                  return;
                                }
                                String path = await supabase.storage
                                    .from('pillgood_bucket')
                                    .upload(
                                        'profile/${DateTime.now()}/${file!.path.split('/').last}',
                                        file);
                                path =
                                    'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/$path';
                                setState(() {
                                  pharmacistVerifyDocumentUrl = path;
                                });
                              },
                            )
                          ],
                        ),
                  PgGaps.h6,
                  const PgDivider(),
                  PgGaps.h6,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: () {
                            Navigator.pushNamed(context, '/browser',
                                arguments: {
                                  'url':
                                      'https://aromatic-star-e53.notion.site/35224fc8937d486ebcaede1527a9adf4',
                                  'title': '이용약관',
                                });
                          },
                          child: Text(
                            '이용약관 동의',
                            style: TextStyle(
                                fontWeight: PgFontWeight.medium,
                                fontSize: PgFontSize.base.fontSize,
                                height: PgFontSize.base.height,
                                color: PgColors.gray_900),
                          ),
                        ),
                      ),
                      PgCheckBox(
                        checked: termsAgree,
                        onChanged: (value) {
                          setState(() {
                            termsAgree = !termsAgree;
                          });
                        },
                      )
                    ],
                  ),
                  PgGaps.h6,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: () {
                            Navigator.pushNamed(context, '/browser',
                                arguments: {
                                  'url':
                                      'https://aromatic-star-e53.notion.site/10dc44bf62514e3db5831e88ff2cc84f',
                                  'title': '개인정보 처리방침',
                                });
                          },
                          child: Text(
                            '개인정보 처리방침 동의',
                            style: TextStyle(
                                fontWeight: PgFontWeight.medium,
                                fontSize: PgFontSize.base.fontSize,
                                height: PgFontSize.base.height,
                                color: PgColors.gray_900),
                          ),
                        ),
                      ),
                      PgCheckBox(
                        checked: privacyAgree,
                        onChanged: (value) {
                          setState(() {
                            privacyAgree = !privacyAgree;
                          });
                        },
                      )
                    ],
                  ),
                  const SizedBox(
                    height: 100,
                  )
                ],
              ),
            )
          ],
        ),
      )),
      floatingActionButton: PgFAB(
        disabled: profileImageUrl == '' ||
            verifyDocumentUrl == '' ||
            pharmacistVerifyDocumentUrl == '' ||
            !termsAgree ||
            !privacyAgree ||
            name == '' ||
            ownerName == '' ||
            worktime == '' ||
            address == '' ||
            addressDetail == '' ||
            lat == 0 ||
            lon == 0,
        text: '확인',
        onTap: () async {
          int count = 0;
          final fcmToken = context.read<FcmTokenProvider>().fcmToken;
          while (true) {
            String randomString = getRandomString(7).toUpperCase();

            try {
              final pharmacyData = await supabase
                  .from('pharmacy')
                  .insert({
                    'name': name,
                    'worktime': worktime,
                    'address': address,
                    'postcode': postcode,
                    'address_detail': addressDetail,
                    'latitude': lat,
                    'longitude': lon,
                    'profile_image_url': profileImageUrl,
                    'invitation_code': randomString,
                    'verify_document_url': verifyDocumentUrl,
                  })
                  .select()
                  .single();
              final pharmacyId = pharmacyData['id'];
              final pharmacistData = await supabase
                  .from('pharmacist')
                  .insert({
                    'user_id': supabase.auth.currentUser?.id,
                    'is_verified': true,
                    'pharmacy_id': pharmacyId,
                    'name': ownerName,
                    'verify_document_url': pharmacistVerifyDocumentUrl,
                    'type': 'OWNER',
                    'fcm_token': fcmToken,
                  })
                  .select()
                  .single();

              PharmacistModel pharmacistModel =
                  PharmacistModel.fromJson(pharmacistData);
              context.read<PharmacistProvider>().setPharmacist(pharmacistModel);
              Navigator.pushNamedAndRemoveUntil(
                  context, '/partner/home', (route) => false);

              break;
            } catch (e) {
              count++;
              if (count > 10) {
                break;
              }
              print(e);
              continue;
            }
          }
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}

class NormalBanner extends StatelessWidget {
  const NormalBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamedAndRemoveUntil(context, '/signup', (route) => false);
      },
      child: Container(
          decoration: const BoxDecoration(
              color: PgColors.gray_50,
              border: Border(bottom: BorderSide(color: PgColors.gray_100))),
          padding: const EdgeInsets.all(PgSizes.size4),
          width: double.infinity,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '약사가 아니신가요?',
                    style: TextStyle(
                        fontWeight: PgFontWeight.bold,
                        color: PgColors.gray_500),
                  ),
                  Text(
                    '일반 사용자로 회원가입하기',
                    style: TextStyle(fontSize: 12, color: PgColors.gray_500),
                  )
                ],
              ),
              PgIcon(
                PgIcons.arrowRight,
                color: PgColors.gray_500,
              )
            ],
          )),
    );
  }
}
