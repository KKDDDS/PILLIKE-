import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';

class PendingScreen extends StatefulWidget {
  const PendingScreen({super.key});

  @override
  State<PendingScreen> createState() => _PendingScreenState();
}

class _PendingScreenState extends State<PendingScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
          child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(
                'assets/images/check.png',
                width: 240,
                height: 240,
              ),
              PgGaps.h6,
              Text(
                '초대 요청을 보냈어요',
                style: TextStyle(
                    fontWeight: PgFontWeight.bold,
                    color: PgColors.gray_900,
                    fontSize: PgFontSize.xl_2.fontSize),
              ),
              PgGaps.h2,
              const Text(
                '관리자 승인 후 약국 정보를 확인할 수 있어요.',
                style: TextStyle(
                  fontWeight: PgFontWeight.medium,
                  color: PgColors.gray_900,
                ),
              ),
              const Text(
                '조금만 기다려주세요.',
                style: TextStyle(
                  fontWeight: PgFontWeight.medium,
                  color: PgColors.gray_900,
                ),
              ),
            ],
          ),
        ),
      )),
    );
  }
}
