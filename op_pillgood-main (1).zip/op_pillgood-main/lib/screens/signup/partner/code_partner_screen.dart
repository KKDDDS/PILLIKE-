import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/constants/pg_icons.dart';
import 'package:pillgood_client/constants/pg_sizes.dart';
import 'package:pillgood_client/models/pharmacist_model.dart';
import 'package:pillgood_client/providers/fcm_token_provider.dart';
import 'package:pillgood_client/providers/pharmacist_provider.dart';
import 'package:pillgood_client/widgets/pg_fab.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';
import 'package:pillgood_client/widgets/pg_input.dart';
import 'package:pillgood_client/widgets/pg_mini_button.dart';
import 'package:pillgood_client/widgets/pg_title.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class CodePartnerScreen extends StatefulWidget {
  const CodePartnerScreen({super.key});

  @override
  State<CodePartnerScreen> createState() => _CodePartnerScreenState();
}

class _CodePartnerScreenState extends State<CodePartnerScreen> {
  bool termsAgree = false;
  bool privacyAgree = false;
  String code = '';
  String name = '';
  String pharmacistVerifyDocumentUrl = '';

  final supabase = Supabase.instance.client;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: SafeArea(
          child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const NormalBanner(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const PgTitle(
                    subtitle: '멤버 등록을 위해',
                    title: '정보를 입력해주세요',
                  ),
                  PgGaps.h6,
                  GestureDetector(
                    onTap: () {
                      Navigator.pushNamedAndRemoveUntil(
                          context, '/signup/partner', (route) => false);
                    },
                    child: Row(
                      children: [
                        const Text('약국 등록하기',
                            style: TextStyle(
                                fontWeight: PgFontWeight.medium,
                                color: PgColors.violet_500)),
                        PgIcon(
                          PgIcons.chevronRight,
                          size: IconSize.sm,
                          color: PgColors.violet_500,
                        )
                      ],
                    ),
                  ),
                  PgGaps.h6,
                  const Text(
                    '초대코드',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  PgInput(
                      labelText: '초대코드를 적어주세요',
                      onChanged: (value) {
                        setState(() {
                          code = value;
                        });
                      }),
                  PgGaps.h6,
                  Text(
                    '약사명',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        fontSize: PgFontSize.base.fontSize,
                        height: PgFontSize.base.height,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  PgInput(
                    labelText: '홍길동',
                    onChanged: (value) {
                      setState(() {
                        name = value;
                      });
                    },
                  ),
                  PgGaps.h6,
                  Text(
                    '약사 인증 서류',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        fontSize: PgFontSize.base.fontSize,
                        height: PgFontSize.base.height,
                        color: PgColors.gray_900),
                  ),
                  PgGaps.h2,
                  pharmacistVerifyDocumentUrl == ''
                      ? GestureDetector(
                          onTap: () async {
                            final pickedImage = await ImagePicker()
                                .pickImage(source: ImageSource.gallery);
                            final file = pickedImage == null
                                ? null
                                : File(pickedImage.path);
                            String path = await supabase.storage
                                .from('pillgood_bucket')
                                .upload('profile/${file!.path.split('/').last}',
                                    file);
                            path =
                                'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/$path';
                            setState(() {
                              pharmacistVerifyDocumentUrl = path;
                            });
                          },
                          child: Image.asset(
                            'assets/images/file-upload.png',
                            width: 128,
                            height: 128,
                          ))
                      : Row(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(8),
                              child: Image.network(
                                pharmacistVerifyDocumentUrl,
                                width: 128,
                                height: 128,
                                fit: BoxFit.cover,
                              ),
                            ),
                            PgGaps.w2,
                            PgMiniButton(
                              onTap: () async {
                                final pickedImage = await ImagePicker()
                                    .pickImage(source: ImageSource.gallery);
                                final file = pickedImage == null
                                    ? null
                                    : File(pickedImage.path);
                                String path = await supabase.storage
                                    .from('pillgood_bucket')
                                    .upload(
                                        'profile/${file!.path.split('/').last}',
                                        file);
                                path =
                                    'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/$path';
                                setState(() {
                                  pharmacistVerifyDocumentUrl = path;
                                });
                              },
                            )
                          ],
                        ),
                  const SizedBox(
                    height: 100,
                  )
                ],
              ),
            )
          ],
        ),
      )),
      floatingActionButton: PgFAB(
        text: '확인',
        disabled: !termsAgree ||
            !privacyAgree ||
            pharmacistVerifyDocumentUrl == '' ||
            name == '' ||
            code == '',
        onTap: () async {
          final pharmacy = await supabase
              .from('pharmacy')
              .select('*')
              .eq('invitation_code', code)
              .limit(1)
              .single();
          if (pharmacy == null) {
            ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('초대코드가 올바르지 않습니다.')));
            return;
          }
          final fcmToken = context.read<FcmTokenProvider>().fcmToken;
          try {
            final pharmacistData = await supabase
                .from('pharmacist')
                .insert({
                  'user_id': supabase.auth.currentUser?.id,
                  'is_verified': false,
                  'pharmacy_id': pharmacy['id'],
                  'name': name,
                  'verify_document_url': pharmacistVerifyDocumentUrl,
                  'type': 'MEMBER',
                  'fcm_token': fcmToken,
                })
                .select()
                .single();

            final pharmacist = PharmacistModel.fromJson(pharmacistData);
            context.read<PharmacistProvider>().setPharmacist(pharmacist);
            Navigator.pushNamedAndRemoveUntil(
                context, '/pending', (route) => false);
          } catch (e) {}
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}

class NormalBanner extends StatelessWidget {
  const NormalBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamedAndRemoveUntil(context, '/signup', (route) => false);
      },
      child: Container(
          decoration: const BoxDecoration(
              color: PgColors.gray_50,
              border: Border(bottom: BorderSide(color: PgColors.gray_100))),
          padding: const EdgeInsets.all(PgSizes.size4),
          width: double.infinity,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '약사가 아니신가요?',
                    style: TextStyle(
                        fontWeight: PgFontWeight.bold,
                        color: PgColors.gray_500),
                  ),
                  Text(
                    '일반 사용자로 회원가입하기',
                    style: TextStyle(fontSize: 12, color: PgColors.gray_500),
                  )
                ],
              ),
              PgIcon(
                PgIcons.arrowRight,
                color: PgColors.gray_500,
              )
            ],
          )),
    );
  }
}
