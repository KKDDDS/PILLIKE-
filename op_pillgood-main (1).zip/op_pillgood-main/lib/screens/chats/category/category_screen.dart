import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/widgets/pg_fab.dart';
import 'package:pillgood_client/widgets/pg_title.dart';

class CaregoryScreen extends StatefulWidget {
  final int pharmacyId;
  const CaregoryScreen({super.key, required this.pharmacyId});

  @override
  State<CaregoryScreen> createState() => _CaregoryScreenState();
}

class _CaregoryScreenState extends State<CaregoryScreen> {
  List<ICategory> categories = [
    const ICategory(
        title: '복약 지도',
        imageUrl: 'assets/images/1.png',
        route: '/chats/new/guide'),
    const ICategory(
        title: '의약품',
        imageUrl: 'assets/images/2.png',
        route: '/chats/new/medicine'),
    const ICategory(
        title: '건강기능식품',
        imageUrl: 'assets/images/3.png',
        route: '/chats/new/health'),
    const ICategory(
        title: '의약품간\n상호작용',
        imageUrl: 'assets/images/4.png',
        route: '/chats/new/interaction'),
    const ICategory(
        title: '의약품 부작용',
        imageUrl: 'assets/images/5.png',
        route: '/chats/new/side_effect'),
    const ICategory(
        title: '기타 문의',
        imageUrl: 'assets/images/6.png',
        route: '/chats/new/etc'),
  ];
  int selectedIndex = -1;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        title: Text('카테고리',
            style: TextStyle(
                fontWeight: PgFontWeight.medium,
                fontSize: PgFontSize.base.fontSize,
                height: PgFontSize.base.height)),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const PgTitle(
              subtitle: '무엇에 대해 문의하고싶은지',
              title: '선택해주세요',
            ),
            PgGaps.h6,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CategoryTile(
                    onTap: () {
                      setState(() {
                        selectedIndex = 0;
                      });
                    },
                    selected: selectedIndex == 0,
                    title: categories[0].title,
                    imageUrl: categories[0].imageUrl),
                CategoryTile(
                    onTap: () {
                      setState(() {
                        selectedIndex = 1;
                      });
                    },
                    selected: selectedIndex == 1,
                    title: categories[1].title,
                    imageUrl: categories[1].imageUrl),
              ],
            ),
            PgGaps.h4,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CategoryTile(
                    onTap: () {
                      setState(() {
                        selectedIndex = 2;
                      });
                    },
                    selected: selectedIndex == 2,
                    title: categories[2].title,
                    imageUrl: categories[2].imageUrl),
                CategoryTile(
                    onTap: () {
                      setState(() {
                        selectedIndex = 3;
                      });
                    },
                    selected: selectedIndex == 3,
                    title: categories[3].title,
                    imageUrl: categories[3].imageUrl),
              ],
            ),
            PgGaps.h4,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                CategoryTile(
                    onTap: () {
                      setState(() {
                        selectedIndex = 4;
                      });
                    },
                    selected: selectedIndex == 4,
                    title: categories[4].title,
                    imageUrl: categories[4].imageUrl),
                CategoryTile(
                    onTap: () {
                      setState(() {
                        selectedIndex = 5;
                      });
                    },
                    selected: selectedIndex == 5,
                    title: categories[5].title,
                    imageUrl: categories[5].imageUrl),
              ],
            ),
            const SizedBox(height: 100)
          ]),
        ),
      ),
      floatingActionButton: PgFAB(
        text: '확인',
        onTap: () {
          if (selectedIndex == -1) return;
          Navigator.pushNamed(context, categories[selectedIndex].route,
              arguments: {
                'pharmacyId': widget.pharmacyId,
              });
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}

class CategoryTile extends StatefulWidget {
  final String title;
  final String imageUrl;
  bool selected;
  final Function? onTap;
  CategoryTile(
      {super.key,
      required this.title,
      required this.imageUrl,
      this.selected = false,
      this.onTap});

  @override
  State<CategoryTile> createState() => _CategoryTileState();
}

class _CategoryTileState extends State<CategoryTile> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          widget.selected = !widget.selected;
        });
        if (widget.onTap != null) widget.onTap!();
      },
      child: Container(
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
            color: widget.selected ? PgColors.violet_50 : Colors.white,
            border: Border.all(
              color: widget.selected ? PgColors.violet_100 : PgColors.gray_100,
            ),
            borderRadius: BorderRadius.circular(16)),
        height: 150,
        width: MediaQuery.sizeOf(context).width / 2 - 16 - 8,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(widget.imageUrl),
            Text(
              widget.title,
              style: TextStyle(
                  fontWeight: PgFontWeight.bold,
                  fontSize: PgFontSize.lg.fontSize,
                  height: PgFontSize.lg.height,
                  color: widget.selected
                      ? PgColors.violet_500
                      : PgColors.gray_500),
            )
          ],
        ),
      ),
    );
  }
}

class ICategory {
  final String title;
  final String imageUrl;
  final String route;
  const ICategory(
      {required this.title, required this.imageUrl, this.route = ''});
}
