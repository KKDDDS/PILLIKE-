import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/providers/profile_provider.dart';
import 'package:pillgood_client/widgets/pg_fab.dart';
import 'package:pillgood_client/widgets/pg_images_picker.dart';
import 'package:pillgood_client/widgets/pg_input.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class InteractionScreen extends StatefulWidget {
  final int pharmacyId;
  const InteractionScreen({super.key, required this.pharmacyId});

  @override
  State<InteractionScreen> createState() => _InteractionScreenState();
}

class _InteractionScreenState extends State<InteractionScreen> {
  String medicineName = '';
  List<String> medicineImages = [];
  String question = '';

  final supabase = Supabase.instance.client;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text('문의하기',
            style: TextStyle(
                fontWeight: PgFontWeight.medium,
                fontSize: PgFontSize.base.fontSize,
                height: PgFontSize.base.height)),
      ),
      body: SingleChildScrollView(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding:
                const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 8),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                '복용중인 의약품을 모두 알려주세요',
                style: TextStyle(
                    fontSize: PgFontSize.base.fontSize,
                    height: PgFontSize.base.height,
                    fontWeight: PgFontWeight.medium),
              ),
              const SizedBox(
                height: 2,
              ),
              Text('이름을 입력하거나 사진을 올려주세요',
                  style: TextStyle(
                      fontSize: PgFontSize.sm.fontSize,
                      height: PgFontSize.sm.height,
                      fontWeight: PgFontWeight.normal,
                      color: PgColors.gray_400)),
            ]),
          ),
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: PgInput(
                labelText: '약품명을 적어주세요',
                onChanged: (value) {
                  setState(() {
                    medicineName = value;
                  });
                },
              )),
          PgGaps.h2,
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: PgImagesPicker(
              imageUrls: medicineImages,
              onAdd: (url) {
                setState(() {
                  medicineImages.add(url);
                });
              },
              onDelete: (url) {
                setState(() {
                  medicineImages.remove(url);
                });
              },
            ),
          ),
          PgGaps.h8,
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '상호작용이 궁금하신 이유를 알려주세요',
                  style: TextStyle(
                      fontSize: PgFontSize.base.fontSize,
                      height: PgFontSize.base.height,
                      fontWeight: PgFontWeight.medium),
                ),
                const SizedBox(
                  height: 8,
                ),
                PgInput(
                    labelText: '',
                    onChanged: (value) {
                      setState(() {
                        question = value;
                      });
                    }),
                PgGaps.h8,
              ],
            ),
          ),
        ],
      )),
      floatingActionButton: PgFAB(
        text: '문의하기',
        onTap: () async {
          final userId = context.read<ProfileProvider>().profileModel!.id;
          final pharmacyId = widget.pharmacyId;
          final chat = await supabase.from('chat').insert({
            'pharmacy_id': pharmacyId,
            'user_id': userId,
            'type': '의약품간 상호작용'
          }).select();
          final chatInfo = await supabase.from('chat_info').insert({
            'title': '복용중인 의약품을 모두 알려주세요',
            'chat_id': chat.first['id'],
            'answer': medicineName,
          }).select();
          for (var image in medicineImages) {
            await supabase.from('chat_info_image').insert({
              'chat_info_id': chatInfo.first['id'],
              'image_url': image,
            });
          }
          await supabase.from('chat_info').insert({
            'title': '상호작용이 궁금하신 이유를 알려주세요',
            'chat_id': chat.first['id'],
            'answer': question,
          });
          Navigator.pushNamed(context, '/chats/room',
              arguments: {'roomId': chat.first['id']});
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}
