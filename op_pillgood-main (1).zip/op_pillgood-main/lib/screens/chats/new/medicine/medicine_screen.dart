import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/providers/profile_provider.dart';
import 'package:pillgood_client/widgets/pg_fab.dart';
import 'package:pillgood_client/widgets/pg_images_picker.dart';
import 'package:pillgood_client/widgets/pg_input.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MedicineScreen extends StatefulWidget {
  final int pharmacyId;
  const MedicineScreen({super.key, required this.pharmacyId});

  @override
  State<MedicineScreen> createState() => _MedicineScreenState();
}

class _MedicineScreenState extends State<MedicineScreen> {
  String medicineName = '';
  List<String> medicineImages = [];
  String question = '';
  final supabase = Supabase.instance.client;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text('문의하기',
            style: TextStyle(
                fontWeight: PgFontWeight.medium,
                fontSize: PgFontSize.base.fontSize,
                height: PgFontSize.base.height)),
      ),
      body: SingleChildScrollView(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 8),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                '어떤 약이 궁금하신가요?',
                style: TextStyle(
                    fontSize: PgFontSize.base.fontSize,
                    height: PgFontSize.base.height,
                    fontWeight: PgFontWeight.medium),
              ),
              SizedBox(
                height: 2,
              ),
              Text('이름을 입력하거나 사진을 올려주세요',
                  style: TextStyle(
                      fontSize: PgFontSize.sm.fontSize,
                      height: PgFontSize.sm.height,
                      fontWeight: PgFontWeight.normal,
                      color: PgColors.gray_400)),
            ]),
          ),
          Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: PgInput(
                labelText: '약품명을 적어주세요',
              )),
          PgGaps.h2,
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: PgImagesPicker(
              imageUrls: medicineImages,
              onAdd: (url) {
                setState(() {
                  medicineImages.add(url);
                });
              },
              onDelete: (url) {
                setState(() {
                  medicineImages.remove(url);
                });
              },
            ),
          ),
          PgGaps.h8,
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '어떤 점이 궁금한가요?',
                  style: TextStyle(
                      fontSize: PgFontSize.base.fontSize,
                      height: PgFontSize.base.height,
                      fontWeight: PgFontWeight.medium),
                ),
                SizedBox(
                  height: 2,
                ),
                Text('용량/용법, 효능, 주의사항, 복약상담 등',
                    style: TextStyle(
                        fontSize: PgFontSize.sm.fontSize,
                        height: PgFontSize.sm.height,
                        fontWeight: PgFontWeight.normal,
                        color: PgColors.gray_400)),
                PgGaps.h2,
                PgInput(
                    labelText: '',
                    onChanged: (value) {
                      setState(() {
                        question = value;
                      });
                    })
              ],
            ),
          ),
        ],
      )),
      floatingActionButton: PgFAB(
        text: '문의하기',
        onTap: () async {
          final userId = context.read<ProfileProvider>().profileModel!.id;
          final pharmacyId = widget.pharmacyId;
          final chat = await supabase.from('chat').insert({
            'pharmacy_id': pharmacyId,
            'user_id': userId,
            'type': '의약품'
          }).select();
          final chatInfo = await supabase.from('chat_info').insert({
            'title': '어떤 약이 궁금하신가요?',
            'chat_id': chat.first['id'],
            'answer': medicineName,
          }).select();
          for (var image in medicineImages) {
            await supabase.from('chat_info_image').insert({
              'chat_info_id': chatInfo.first['id'],
              'image_url': image,
            });
          }

          await supabase.from('chat_info').insert({
            'title': '어떤 점이 궁금한가요?',
            'chat_id': chat.first['id'],
            'answer': question,
          });

          Navigator.pushNamed(context, '/chats/room',
              arguments: {'roomId': chat.first['id']});
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}
