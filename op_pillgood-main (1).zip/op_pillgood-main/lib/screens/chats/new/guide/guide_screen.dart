import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/providers/profile_provider.dart';
import 'package:pillgood_client/widgets/pg_checkbox.dart';
import 'package:pillgood_client/widgets/pg_fab.dart';
import 'package:pillgood_client/widgets/pg_images_picker.dart';
import 'package:pillgood_client/widgets/pg_input.dart';
import 'package:pillgood_client/widgets/pg_selector.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class GuideScreen extends StatefulWidget {
  final int pharmacyId;
  const GuideScreen({super.key, required this.pharmacyId});

  @override
  State<GuideScreen> createState() => _GuideScreenState();
}

class _GuideScreenState extends State<GuideScreen> {
  String medicineName = '';
  List<String> medicineImages = [];
  String reason = '';
  String duration = '1~2일';
  String guide = '';
  List<String> needs = [];
  var needOptions = [
    '언제 먹어야 하는지',
    '주의사항으로 어떤 것이 있는지',
    '예상되는 부작용으론 무엇이 있는지',
    '기타'
  ];
  var selectedNeeds = [];
  var etcGuide = '';

  final supabase = Supabase.instance.client;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        title: Text('문의하기',
            style: TextStyle(
                fontWeight: PgFontWeight.medium,
                fontSize: PgFontSize.base.fontSize,
                height: PgFontSize.base.height)),
      ),
      body: SingleChildScrollView(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding:
                const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 8),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(
                '어떤 약을 처방받으셨나요?',
                style: TextStyle(
                    fontSize: PgFontSize.base.fontSize,
                    height: PgFontSize.base.height,
                    fontWeight: PgFontWeight.medium),
              ),
              const SizedBox(
                height: 2,
              ),
              Text('이름을 입력하거나 사진을 올려주세요',
                  style: TextStyle(
                      fontSize: PgFontSize.sm.fontSize,
                      height: PgFontSize.sm.height,
                      fontWeight: PgFontWeight.normal,
                      color: PgColors.gray_400)),
            ]),
          ),
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: PgInput(
                labelText: '약품명을 적어주세요',
                initialValue: medicineName,
                onChanged: (value) {
                  setState(() {
                    medicineName = value;
                  });
                },
              )),
          PgGaps.h2,
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: PgImagesPicker(
              imageUrls: medicineImages,
              onAdd: (url) {
                setState(() {
                  medicineImages.add(url);
                });
              },
              onDelete: (url) {
                setState(() {
                  medicineImages.remove(url);
                });
              },
            ),
          ),
          PgGaps.h8,
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '약 처방을 받은 이유가 무엇인가요? (선택)',
                  style: TextStyle(
                      fontSize: PgFontSize.base.fontSize,
                      height: PgFontSize.base.height,
                      fontWeight: PgFontWeight.medium),
                ),
                PgGaps.h2,
                PgInput(
                  labelText: '',
                  initialValue: reason,
                  onChanged: (value) {
                    setState(() {
                      reason = value;
                    });
                  },
                ),
                PgGaps.h8,
                Text(
                  '약 처방을 받은지 어느정도 되셨나요?',
                  style: TextStyle(
                      fontSize: PgFontSize.base.fontSize,
                      height: PgFontSize.base.height,
                      fontWeight: PgFontWeight.medium),
                ),
                PgGaps.h2,
                PgSelector(
                  labelText: '1~2일',
                  onChanged: (value) {
                    setState(() {
                      duration = value;
                    });
                  },
                  options: const ['1~2일', '3~4일', '5~6일', '일주일 이상'],
                ),
                PgGaps.h8,
                Text(
                  '어떤 복약지도가 필요하신가요?',
                  style: TextStyle(
                      fontSize: PgFontSize.base.fontSize,
                      height: PgFontSize.base.height,
                      fontWeight: PgFontWeight.medium),
                ),
                PgGaps.h2,
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                      color: PgColors.violet_50,
                      border: Border.all(color: PgColors.violet_100),
                      borderRadius: BorderRadius.circular(8)),
                  child: Column(
                    children: needOptions
                        .map(
                          (e) => Column(
                            children: [
                              Row(
                                children: [
                                  PgCheckBox(
                                    checked: selectedNeeds.contains(e),
                                    onChanged: (value) {
                                      setState(() {
                                        if (value) {
                                          selectedNeeds.add(e);
                                        } else {
                                          selectedNeeds.remove(e);
                                        }
                                      });
                                    },
                                  ),
                                  PgGaps.w4,
                                  Text(
                                    e,
                                    style: TextStyle(
                                        fontSize: PgFontSize.base.fontSize,
                                        height: PgFontSize.base.height,
                                        fontWeight: PgFontWeight.medium),
                                  )
                                ],
                              ),
                              e == needOptions.last ? Container() : PgGaps.h6
                            ],
                          ),
                        )
                        .toList(),
                  ),
                ),
                selectedNeeds.contains('기타')
                    ? Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          PgGaps.h8,
                          Text(
                            '어떤 지도가 필요한지 적어주세요',
                            style: TextStyle(
                                fontSize: PgFontSize.base.fontSize,
                                height: PgFontSize.base.height,
                                fontWeight: PgFontWeight.medium),
                          ),
                          PgGaps.h2,
                          PgInput(
                            labelText: '',
                            maxLines: 5,
                            initialValue: etcGuide,
                            onChanged: (value) {
                              setState(() {
                                etcGuide = value;
                              });
                            },
                          ),
                        ],
                      )
                    : Container(),
              ],
            ),
          ),
          SizedBox(
            height: 200,
          )
        ],
      )),
      floatingActionButton: PgFAB(
        text: '문의하기',
        disabled: (medicineName.isEmpty && medicineImages.isEmpty) ||
            selectedNeeds.isEmpty ||
            (selectedNeeds.contains('기타') && etcGuide.isEmpty),
        onTap: () async {
          final userId = context.read<ProfileProvider>().profileModel!.id;
          final pharmacyId = widget.pharmacyId;
          final chat = await supabase.from('chat').insert({
            'pharmacy_id': pharmacyId,
            'user_id': userId,
            'type': '복약 지도'
          }).select();
          final chatInfo = await supabase.from('chat_info').insert({
            'title': '어떤 약을 처방받으셨나요?',
            'chat_id': chat.first['id'],
            'answer': medicineName,
          }).select();
          for (var image in medicineImages) {
            await supabase.from('chat_info_image').insert({
              'chat_info_id': chatInfo.first['id'],
              'image_url': image,
            });
          }
          await supabase.from('chat_info').insert({
            'title': '약 처방을 받은 이유가 무엇인가요? (선택)',
            'chat_id': chat.first['id'],
            'answer': reason,
          }).select();
          await supabase.from('chat_info').insert({
            'title': '약 처방을 받은지 어느정도 되셨나요?',
            'chat_id': chat.first['id'],
            'answer': duration,
          }).select();
          await supabase.from('chat_info').insert({
            'title': '어떤 복약지도가 필요하신가요?',
            'chat_id': chat.first['id'],
            'answer': selectedNeeds.join(', '),
          }).select();
          if (etcGuide.isNotEmpty) {
            await supabase.from('chat_info').insert({
              'title': '어떤 지도가 필요한지 적어주세요',
              'chat_id': chat.first['id'],
              'answer': etcGuide,
            }).select();
          }
          Navigator.pushNamed(context, '/chats/room',
              arguments: {'roomId': chat.first['id']});
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}
