import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/providers/profile_provider.dart';
import 'package:pillgood_client/widgets/pg_fab.dart';
import 'package:pillgood_client/widgets/pg_input.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class EtcScreen extends StatefulWidget {
  final int pharmacyId;
  const EtcScreen({super.key, required this.pharmacyId});

  @override
  State<EtcScreen> createState() => _EtcScreenState();
}

class _EtcScreenState extends State<EtcScreen> {
  String question = '';

  final supabase = Supabase.instance.client;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text('문의하기',
            style: TextStyle(
                fontWeight: PgFontWeight.medium,
                fontSize: PgFontSize.base.fontSize,
                height: PgFontSize.base.height)),
      ),
      body: SingleChildScrollView(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '문의사항을 알려주세요',
                  style: TextStyle(
                      fontSize: PgFontSize.base.fontSize,
                      height: PgFontSize.base.height,
                      fontWeight: PgFontWeight.medium),
                ),
                const SizedBox(
                  height: 8,
                ),
                PgInput(
                    labelText: '',
                    maxLines: 5,
                    onChanged: (value) {
                      setState(() {
                        question = value;
                      });
                    }),
                PgGaps.h8,
              ],
            ),
          ),
        ],
      )),
      floatingActionButton: PgFAB(
        text: '문의하기',
        onTap: () async {
          final userId = context.read<ProfileProvider>().profileModel!.id;
          final pharmacyId = widget.pharmacyId;
          final chat = await supabase.from('chat').insert({
            'pharmacy_id': pharmacyId,
            'user_id': userId,
            'type': '기타'
          }).select();
          await supabase.from('chat_info').insert({
            'title': '문의사항을 알려주세요',
            'chat_id': chat.first['id'],
            'answer': question,
          });
          Navigator.pushNamed(context, '/chats/room',
              arguments: {'roomId': chat.first['id']});
        },
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
    );
  }
}
