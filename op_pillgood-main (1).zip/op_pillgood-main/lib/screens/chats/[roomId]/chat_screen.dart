import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/models/chat_info_model.dart';
import 'package:pillgood_client/models/pharmacist_model.dart';
import 'package:pillgood_client/models/pharmacy_model.dart';
import 'package:pillgood_client/models/profile_model.dart';
import 'package:pillgood_client/screens/chats/%5BroomId%5D/chat_info_section.dart';
import 'package:pillgood_client/screens/chats/%5BroomId%5D/chat_item.dart';
import 'package:pillgood_client/widgets/pg_input.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ChatScreen extends StatefulWidget {
  final int roomId;
  const ChatScreen({super.key, required this.roomId});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late Future<dynamic> chatRoomFuture;
  late Stream<dynamic> chatMessageStream;
  final supabase = Supabase.instance.client;
  TextEditingController controller = TextEditingController();
  ScrollController scrollController = ScrollController();

  String currentMessage = '';

  late Future<dynamic> _future;

  getPharmacy(int pharmacyId) async {
    final pharmacy = await supabase
        .from('pharmacy')
        .select('*')
        .eq('id', pharmacyId)
        .limit(1)
        .single();
    return PharmacyModel.fromJson(pharmacy);
  }

  getProfile(String userId) async {
    final profile = await supabase
        .from('profile')
        .select('*')
        .eq('user_id', userId)
        .limit(1)
        .single();
    return ProfileModel.fromJson(profile);
  }

  getPharmacist(String pharmacistId) async {
    final pharmacist = await supabase
        .from('pharmacist')
        .select('*')
        .eq('user_id', pharmacistId)
        .limit(1)
        .single();
    return PharmacistModel.fromJson(pharmacist);
  }

  getAllInfo() async {
    final chat = await supabase
        .from('chat')
        .select('*, chat_message(*), chat_info(*, chat_info_image(*))')
        .eq('id', widget.roomId)
        .limit(1)
        .single();
    final pharmacy = await getPharmacy(chat['pharmacy_id']);
    final profile = await getProfile(chat['user_id']);
    dynamic pharmacist;
    if (chat['pharmacist_id'] != null) {
      pharmacist = await getPharmacist(chat['pharmacist_id']);
    }
    return {
      'pharmacy': pharmacy,
      'chat': chat,
      'profile': profile,
      'pharmacist': pharmacist
    };
  }

  getChatMessageStream() {
    return supabase
        .from('chat_message')
        .stream(primaryKey: ['id']).eq('chat_id', widget.roomId);
  }

  @override
  void initState() {
    _future = getAllInfo();
    chatMessageStream = getChatMessageStream();

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            final List<ChatInfoModel> chatInfos =
                snapshot.data['chat']['chat_info'] != null
                    ? (snapshot.data['chat']['chat_info'] as List<dynamic>)
                        .map((e) => ChatInfoModel.fromJson(e))
                        .toList()
                    : [];
            final PharmacyModel pharmacy = snapshot.data['pharmacy'];
            return Scaffold(
              appBar: AppBar(
                  backgroundColor: Colors.white,
                  surfaceTintColor: Colors.white,
                  title: Text(pharmacy.name,
                      style: TextStyle(
                          fontWeight: PgFontWeight.medium,
                          fontSize: PgFontSize.base.fontSize,
                          height: PgFontSize.base.height))),
              body: Column(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(children: [
                        StreamBuilder(
                            stream: chatMessageStream,
                            builder: (context, stream) {
                              if (stream.hasData) {
                                List<dynamic> chatMessages =
                                    stream.data as List<dynamic>;
                                List<Widget> items = [];
                                items.add(const UserMessageSentBanner());
                                items.add(PgGaps.h6);
                                items.add(ChatInfoSection(
                                  chatInfos: chatInfos,
                                  profileModel: snapshot.data['profile'],
                                ));
                                items.add(PgGaps.h6);
                                items.addAll(chatMessages
                                    .map((e) => ChatItem(
                                        profileImageUrl:
                                            pharmacy.profileImageUrl,
                                        content: e['content'],
                                        isMine: e['user_id'] != null &&
                                            snapshot.data['profile'].id ==
                                                e['user_id'],
                                        createdAt:
                                            DateTime.parse(e['created_at'])))
                                    .toList());
                                items = items.reversed.toList();
                                return Expanded(
                                  child: ListView.builder(
                                      reverse: true,
                                      controller: scrollController,
                                      itemCount: items.length,
                                      itemBuilder: (context, index) {
                                        return items[index];
                                      }),
                                );
                              } else {
                                return const Center(
                                    child: CircularProgressIndicator());
                              }
                            })
                      ]),
                    ),
                  ),
                  Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        children: [
                          Expanded(
                              child: PgInput(
                            labelText: '메시지 보내기',
                            controller: controller,
                            onChanged: (value) {
                              setState(() {
                                currentMessage = value;
                              });
                            },
                          )),
                          PgGaps.w4,
                          SizedBox(
                            width: 32,
                            height: 32,
                            child: GestureDetector(
                              onTap: () async {
                                if (currentMessage.isEmpty) return;
                                await supabase.from('chat_message').insert([
                                  {
                                    'chat_id': widget.roomId,
                                    'content': currentMessage,
                                    'user_id': snapshot.data['profile'].id
                                  }
                                ]);

                                await supabase.from('chat').update({
                                  'updated_at':
                                      DateTime.now().toUtc().toString()
                                }).eq('id', widget.roomId);
                                if (snapshot.data['pharmacist'] != null) {
                                  try {
                                    await supabase.functions
                                        .invoke('push-notifications', body: {
                                      'token':
                                          snapshot.data['pharmacist'].fcmToken,
                                      'content':
                                          '${snapshot.data['profile'].name} : $currentMessage',
                                      'roomId': widget.roomId.toString(),
                                    });
                                  } catch (e) {
                                    print(e);
                                  }
                                }
                                scrollController.animateTo(
                                  0.0,
                                  duration: const Duration(milliseconds: 300),
                                  curve: Curves.easeOut,
                                );
                                controller.clear();
                                setState(() {
                                  currentMessage = '';
                                });
                              },
                              child: Image.asset(
                                'assets/images/send.png',
                              ),
                            ),
                          )
                        ],
                      )),
                  SizedBox(height: MediaQuery.of(context).padding.bottom),
                ],
              ),
            );
          } else {
            return const Center(child: CircularProgressIndicator());
          }
        });
  }
}

class UserMessageSentBanner extends StatelessWidget {
  const UserMessageSentBanner({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            'assets/images/check.png',
            width: 160,
            height: 160,
          ),
          const SizedBox(
            height: 18,
          ),
          Text('메시지를 전달했어요',
              style: TextStyle(
                  fontWeight: PgFontWeight.bold,
                  fontSize: PgFontSize.xl_2.fontSize,
                  height: PgFontSize.xl_2.height)),
          PgGaps.h2,
          Text('약사님이 빠른 시간 안에 답장할 수 있도록',
              style: TextStyle(
                  fontWeight: PgFontWeight.medium,
                  fontSize: PgFontSize.base.fontSize,
                  height: PgFontSize.base.height,
                  color: PgColors.gray_500)),
          Text('도와드릴게요.',
              style: TextStyle(
                  fontWeight: PgFontWeight.medium,
                  fontSize: PgFontSize.base.fontSize,
                  height: PgFontSize.base.height,
                  color: PgColors.gray_500))
        ],
      ),
    );
  }
}
