import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/utils/pg_formatter.dart';

class ChatItem extends StatelessWidget {
  final String content;
  final bool isMine;
  final DateTime createdAt;
  final String profileImageUrl;
  const ChatItem(
      {super.key,
      required this.content,
      required this.profileImageUrl,
      required this.isMine,
      required this.createdAt});

  @override
  Widget build(BuildContext context) {
    final maxWidth = MediaQuery.of(context).size.width * 0.7;
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment:
            isMine ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          !isMine
              ? Row(
                  children: [
                    ClipRRect(
                        borderRadius: BorderRadius.circular(24),
                        child: Image.network(
                          profileImageUrl,
                          width: 32,
                          height: 32,
                          fit: BoxFit.cover,
                        )),
                    PgGaps.w2,
                  ],
                )
              : const SizedBox(),
          Row(
            mainAxisAlignment:
                isMine ? MainAxisAlignment.end : MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              isMine
                  ? Row(
                      children: [
                        Text(
                          PgFormatter.formatChatDate(createdAt),
                          style: TextStyle(
                              color: PgColors.gray_400,
                              fontSize: PgFontSize.sm.fontSize,
                              height: PgFontSize.sm.height,
                              fontWeight: PgFontWeight.medium),
                        ),
                        PgGaps.w2
                      ],
                    )
                  : SizedBox(),
              Container(
                constraints: BoxConstraints(maxWidth: maxWidth),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: isMine ? PgColors.violet_500 : PgColors.gray_100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  content,
                  style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w400,
                      color: isMine ? Colors.white : Colors.black),
                ),
              ),
              !isMine
                  ? Row(
                      children: [
                        PgGaps.w2,
                        Text(
                          PgFormatter.formatChatDate(createdAt),
                          style: TextStyle(
                              color: PgColors.gray_400,
                              fontSize: PgFontSize.sm.fontSize,
                              height: PgFontSize.sm.height,
                              fontWeight: PgFontWeight.medium),
                        ),
                      ],
                    )
                  : SizedBox(),
            ],
          ),
        ],
      ),
    );
  }
}
