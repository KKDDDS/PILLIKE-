import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/models/chat_info_model.dart';
import 'package:pillgood_client/models/profile_model.dart';
import 'package:pillgood_client/widgets/pg_divider.dart';

class ChatInfoSection extends StatelessWidget {
  final List<ChatInfoModel> chatInfos;
  final ProfileModel profileModel;
  const ChatInfoSection(
      {super.key, required this.chatInfos, required this.profileModel});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        color: PgColors.gray_100,
      ),
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(
          '문의내용',
          style: TextStyle(
              fontSize: PgFontSize.base.fontSize,
              fontWeight: PgFontWeight.bold,
              height: PgFontSize.base.height),
        ),
        PgGaps.h4,
        ...chatInfos.map((e) => ChatInfo(chatInfo: e)).toList(),
        const PgDivider(),
        PgGaps.h4,
        Text(
          '사용자 정보',
          style: TextStyle(
              fontSize: PgFontSize.base.fontSize,
              fontWeight: PgFontWeight.bold,
              height: PgFontSize.base.height),
        ),
        PgGaps.h4,
        Profile(profileModel: profileModel),
      ]),
    );
  }
}

class ChatInfo extends StatelessWidget {
  final ChatInfoModel chatInfo;
  const ChatInfo({super.key, required this.chatInfo});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          chatInfo.title,
          style: TextStyle(
              fontSize: PgFontSize.sm.fontSize,
              fontWeight: PgFontWeight.medium,
              height: PgFontSize.sm.height,
              color: PgColors.gray_400),
        ),
        PgGaps.h1,
        Text(
          chatInfo.answer,
          style: TextStyle(
              fontSize: PgFontSize.base.fontSize,
              fontWeight: PgFontWeight.medium,
              height: PgFontSize.base.height,
              color: PgColors.gray_500),
        ),
        chatInfo.images.isNotEmpty ? PgGaps.h4 : Container(),
        ...chatInfo.images
            .map((e) => Column(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.network(
                        e.imageUrl,
                        width: double.infinity,
                        height: 160,
                        fit: BoxFit.cover,
                      ),
                    ),
                    PgGaps.h1,
                  ],
                ))
            .toList(),
        PgGaps.h4,
      ],
    );
  }
}

class Profile extends StatelessWidget {
  final ProfileModel profileModel;
  const Profile({super.key, required this.profileModel});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(
        '성별',
        style: TextStyle(
            fontSize: PgFontSize.sm.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.sm.height,
            color: PgColors.gray_400),
      ),
      PgGaps.h1,
      Text(
        profileModel.sex == 'male' ? '남성' : '여성',
        style: TextStyle(
            fontSize: PgFontSize.base.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.base.height,
            color: PgColors.gray_500),
      ),
      PgGaps.h2,
      Text(
        '출생년도',
        style: TextStyle(
            fontSize: PgFontSize.sm.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.sm.height,
            color: PgColors.gray_400),
      ),
      PgGaps.h1,
      Text(
        profileModel.birthyear.toString(),
        style: TextStyle(
            fontSize: PgFontSize.base.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.base.height,
            color: PgColors.gray_500),
      ),
      PgGaps.h2,
      Text(
        '음주여부',
        style: TextStyle(
            fontSize: PgFontSize.sm.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.sm.height,
            color: PgColors.gray_400),
      ),
      PgGaps.h1,
      Text(
        profileModel.drink,
        style: TextStyle(
            fontSize: PgFontSize.base.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.base.height,
            color: PgColors.gray_500),
      ),
      PgGaps.h2,
      Text(
        '흡연여부',
        style: TextStyle(
            fontSize: PgFontSize.sm.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.sm.height,
            color: PgColors.gray_400),
      ),
      PgGaps.h1,
      Text(
        profileModel.smoke,
        style: TextStyle(
            fontSize: PgFontSize.base.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.base.height,
            color: PgColors.gray_500),
      ),
      PgGaps.h2,
      Text(
        '임신 가능성',
        style: TextStyle(
            fontSize: PgFontSize.sm.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.sm.height,
            color: PgColors.gray_400),
      ),
      PgGaps.h1,
      Text(
        profileModel.pregnant,
        style: TextStyle(
            fontSize: PgFontSize.base.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.base.height,
            color: PgColors.gray_500),
      ),
      PgGaps.h2,
      Text(
        '지병',
        style: TextStyle(
            fontSize: PgFontSize.sm.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.sm.height,
            color: PgColors.gray_400),
      ),
      PgGaps.h1,
      Text(
        profileModel.disease,
        style: TextStyle(
            fontSize: PgFontSize.base.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.base.height,
            color: PgColors.gray_500),
      ),
      PgGaps.h2,
      Text(
        '주의해야할 의약품',
        style: TextStyle(
            fontSize: PgFontSize.sm.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.sm.height,
            color: PgColors.gray_400),
      ),
      PgGaps.h1,
      Text(
        profileModel.cautions,
        style: TextStyle(
            fontSize: PgFontSize.base.fontSize,
            fontWeight: PgFontWeight.medium,
            height: PgFontSize.base.height,
            color: PgColors.gray_500),
      ),
      PgGaps.h2,
    ]);
  }
}
