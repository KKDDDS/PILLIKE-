import 'package:flutter/material.dart';
import 'package:pillgood_client/providers/profile_provider.dart';
import 'package:pillgood_client/screens/map/chat_card.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ChatsBody extends StatefulWidget {
  const ChatsBody({super.key});

  @override
  State<ChatsBody> createState() => _ChatsBodyState();
}

class _ChatsBodyState extends State<ChatsBody> {
  final supabase = Supabase.instance.client;

  late Stream<List<dynamic>> _chatsStream;

  @override
  void initState() {
    _chatsStream = supabase
        .from('chat')
        .stream(primaryKey: ['id'])
        .eq('user_id', context.read<ProfileProvider>().profileModel!.id)
        .order('updated_at', ascending: false);

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<dynamic>>(
        stream: _chatsStream,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            final chats = snapshot.data!;
            return ListView.builder(
                itemCount: chats.length,
                itemBuilder: (context, index) {
                  final chat = chats[index];
                  return ChatCard(
                      chatId: chat['id'],
                      updatedAt: DateTime.parse(chat['updated_at']),
                      pharmacyId: chat['pharmacy_id'],
                      pharmacistId: chat['pharmacist_id']);
                });
          } else {
            return const Center(child: CircularProgressIndicator());
          }
        });
  }
}
