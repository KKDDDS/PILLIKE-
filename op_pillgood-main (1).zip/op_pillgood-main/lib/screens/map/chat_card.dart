import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/utils/pg_formatter.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ChatCard extends StatefulWidget {
  final int chatId;
  final int pharmacyId;
  final String? pharmacistId;
  final DateTime updatedAt;
  const ChatCard(
      {super.key,
      required this.chatId,
      required this.updatedAt,
      required this.pharmacyId,
      this.pharmacistId});

  @override
  State<ChatCard> createState() => _ChatCardState();
}

class _ChatCardState extends State<ChatCard> {
  final supabase = Supabase.instance.client;
  late Future<dynamic> _future;

  getPharmacy() async {
    final pharmacy = await supabase
        .from('pharmacy')
        .select('name, profile_image_url')
        .eq('id', widget.pharmacyId)
        .limit(1)
        .single();
    return pharmacy;
  }

  getAllInfo() async {
    final pharmacy = await getPharmacy();
    final chat = await supabase
        .from('chat')
        .select('*, chat_message(*)')
        .eq('id', widget.chatId)
        .order('created_at', foreignTable: 'chat_message', ascending: false)
        .limit(1, foreignTable: 'chat_message')
        .single();
    return {'pharmacy': pharmacy, 'chat': chat};
  }

  @override
  void didUpdateWidget(covariant ChatCard oldWidget) {
    // TODO: implement didUpdateWidget
    _future = getAllInfo();
    super.didUpdateWidget(oldWidget);
  }

  @override
  void initState() {
    _future = getAllInfo();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, '/chats/room',
            arguments: {'roomId': widget.chatId});
      },
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 24, 16, 0),
        child: Container(
          padding: const EdgeInsets.only(bottom: 24),
          decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: PgColors.gray_100))),
          child: FutureBuilder(
            future: _future,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: Image.network(
                        snapshot.data!['pharmacy']['profile_image_url'],
                        width: 48,
                        height: 48,
                        fit: BoxFit.cover,
                      ),
                    ),
                    PgGaps.w4,
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              snapshot.data!['pharmacy']['name'],
                              style: TextStyle(
                                  fontSize: PgFontSize.sm.fontSize,
                                  height: PgFontSize.sm.height,
                                  fontWeight: FontWeight.bold),
                            ),
                            PgGaps.w2,
                            Text(
                              '약사 · ${PgFormatter.formatDate(widget.updatedAt)}',
                              style: TextStyle(
                                  fontSize: PgFontSize.sm.fontSize,
                                  height: PgFontSize.sm.height,
                                  color: PgColors.gray_500),
                            ),
                          ],
                        ),
                        PgGaps.h2,
                        Text(
                          snapshot.data['chat']['chat_message'].isNotEmpty
                              ? snapshot.data['chat']['chat_message'][0]
                                  ['content']
                              : '채팅 내용이 없습니다.',
                          style: TextStyle(
                              fontSize: PgFontSize.base.fontSize,
                              height: PgFontSize.base.height,
                              fontWeight: PgFontWeight.medium),
                        ),
                      ],
                    )
                  ],
                );
              } else {
                return const SizedBox();
              }
            },
          ),
        ),
      ),
    );
  }
}
