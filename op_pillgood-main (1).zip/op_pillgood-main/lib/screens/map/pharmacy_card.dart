import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/constants/pg_icons.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';

class PharmacyCard extends StatelessWidget {
  final String pharmacyName;
  final String pharmacistName;
  final String workTime;
  final String imageUrl;
  final int pharmacyId;
  final Function? onTap;
  const PharmacyCard(
      {super.key,
      required this.pharmacyName,
      required this.pharmacistName,
      required this.workTime,
      required this.pharmacyId,
      this.imageUrl =
          'https://fastly.picsum.photos/id/1077/200/300.jpg?hmac=BqQneQETTwZkHqmZmg4VxHsD-Lia-Qxp6nXv0c2eaac',
      this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (onTap != null) {
          onTap!();
        }
      },
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        child: Column(children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    pharmacyName,
                    style: TextStyle(
                        fontWeight: PgFontWeight.bold,
                        fontSize: PgFontSize.base.fontSize,
                        height: PgFontSize.base.height),
                  ),
                  PgGaps.h1,
                  Text(
                    '$pharmacistName 약사',
                    style: TextStyle(
                        fontWeight: PgFontWeight.medium,
                        fontSize: PgFontSize.base.fontSize,
                        height: PgFontSize.base.height),
                  ),
                  PgGaps.h1,
                  Text(
                    workTime,
                    style: TextStyle(
                        color: PgColors.gray_500,
                        fontSize: PgFontSize.sm.fontSize),
                  ),
                ],
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.network(
                  imageUrl,
                  width: 80,
                  height: 80,
                  fit: BoxFit.cover,
                ),
              )
            ],
          ),
          PgGaps.h2,
          GestureDetector(
            onTap: () {
              Navigator.pushNamed(context, '/chats/category', arguments: {
                'pharmacyId': pharmacyId,
              });
            },
            child: Container(
                padding: EdgeInsets.symmetric(vertical: 8),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    border: Border.all(color: PgColors.violet_500),
                    borderRadius: BorderRadius.circular(8)),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      '채팅하기',
                      style: TextStyle(
                          color: PgColors.violet_500,
                          fontSize: PgFontSize.sm.fontSize,
                          height: PgFontSize.sm.height,
                          fontWeight: PgFontWeight.bold),
                    ),
                    PgIcon(
                      PgIcons.chevronRight,
                      size: IconSize.sm,
                      color: PgColors.violet_500,
                    )
                  ],
                )),
          )
        ]),
      ),
    );
  }
}
