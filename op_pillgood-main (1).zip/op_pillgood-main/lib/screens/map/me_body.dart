import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/constants/pg_icons.dart';
import 'package:pillgood_client/providers/profile_provider.dart';
import 'package:pillgood_client/widgets/pg_divider.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MeBody extends StatefulWidget {
  const MeBody({super.key});

  @override
  State<MeBody> createState() => _MeBodyState();
}

class _MeBodyState extends State<MeBody> {
  final supabase = Supabase.instance.client;
  @override
  Widget build(BuildContext context) {
    final profile = context.watch<ProfileProvider>().profileModel;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(32),
              child: profile?.profileImageUrl != '' && profile == null
                  ? Image.asset(
                      'assets/images/user.png',
                      width: 64,
                      height: 64,
                      fit: BoxFit.cover,
                    )
                  : Image.network(
                      profile?.profileImageUrl ??
                          'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/pillgood_bucket/profile/Image.png',
                      width: 64,
                      height: 64,
                      fit: BoxFit.cover,
                    ),
            ),
            const SizedBox(
              width: 16,
            ),
            Text(
              profile!.name,
              style: TextStyle(
                  fontWeight: PgFontWeight.bold,
                  fontSize: PgFontSize.xl.fontSize,
                  height: PgFontSize.xl.height,
                  color: PgColors.gray_900),
            )
          ],
        ),
        GestureDetector(
          onTap: () {
            Navigator.pushNamed(context, '/me/profile');
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 24),
            child: Row(children: [
              PgIcon(PgIcons.pencilSquare),
              PgGaps.w4,
              Text(
                '내 정보 관리',
                style: TextStyle(
                    fontWeight: PgFontWeight.medium,
                    fontSize: PgFontSize.base.fontSize,
                    height: PgFontSize.base.height,
                    color: PgColors.gray_900),
              ),
            ]),
          ),
        ),
        const PgDivider(),
        GestureDetector(
          onTap: () {
            Navigator.pushNamed(context, '/browser', arguments: {
              'url':
                  'https://aromatic-star-e53.notion.site/bc02b00ebd1949e69752c711449d1d93',
              'title': '공지사항',
            });
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 24),
            child: Row(children: [
              PgIcon(PgIcons.megaphone),
              PgGaps.w4,
              Text(
                '공지사항',
                style: TextStyle(
                    fontWeight: PgFontWeight.medium,
                    fontSize: PgFontSize.base.fontSize,
                    height: PgFontSize.base.height,
                    color: PgColors.gray_900),
              ),
            ]),
          ),
        ),
        const PgDivider(),
        PgGaps.h6,
        const FaqBanner(),
        PgGaps.h6,
        GestureDetector(
          onTap: () {
            supabase.auth.signOut();
            Navigator.pushNamedAndRemoveUntil(
                context, '/login', (route) => false);
          },
          child: const Text('로그아웃',
              style: TextStyle(
                  color: PgColors.gray_500,
                  decoration: TextDecoration.underline,
                  decorationColor: PgColors.gray_500)),
        )
      ]),
    );
  }
}

class FaqBanner extends StatelessWidget {
  const FaqBanner({super.key});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pushNamed(context, '/browser', arguments: {
          'url': 'http://7zwq0.channel.io/',
          'title': '1:1 문의하기',
        });
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        width: double.infinity,
        decoration: BoxDecoration(
            color: PgColors.violet_50,
            border: Border.all(color: PgColors.violet_100),
            borderRadius: BorderRadius.circular(16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text(
            '1:1 문의하기',
            style: TextStyle(
                fontWeight: PgFontWeight.bold, color: PgColors.violet_500),
          ),
          const SizedBox(
            height: 2,
          ),
          Text(
            '필굿에 궁금한 점을 물어보세요',
            style: TextStyle(
                fontSize: PgFontSize.sm.fontSize,
                height: PgFontSize.sm.height,
                color: PgColors.violet_500),
          ),
        ]),
      ),
    );
  }
}
