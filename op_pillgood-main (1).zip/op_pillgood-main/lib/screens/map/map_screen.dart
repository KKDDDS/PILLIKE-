import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:kakao_map_plugin/kakao_map_plugin.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_icons.dart';
import 'package:pillgood_client/models/pharmacy_model.dart';
import 'package:pillgood_client/providers/location_provider.dart';
import 'package:pillgood_client/screens/map/chats_body.dart';
import 'package:pillgood_client/screens/map/me_body.dart';
import 'package:pillgood_client/screens/map/pharmacy_card.dart';
import 'package:pillgood_client/widgets/pg_header.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  int index = 0;
  bool isSelected = false;
  int selectedIndex = 0;
  KakaoMapController? mapController;
  final supabase = Supabase.instance.client;
  final List<IconData> icons = const [
    Icons.message,
    Icons.call,
    Icons.mail,
    Icons.notifications,
    Icons.settings,
  ];

  Future<List<PharmacyModel>> getPharmacies() async {
    final location =
        await context.read<LocationProvider>().setCurrentLocation();
    final List<dynamic> response = await supabase
        .rpc('get_pharmacies', params: {
          'lat': location['latitude'],
          'long': location['longitude'],
        })
        .eq('is_verified', true)
        .eq('is_working', true);

    for (final element in response) {
      print(element['distance']);
    }
    final pharmacies = response.map((e) => PharmacyModel.fromJson(e)).toList();
    return pharmacies;
  }

  @override
  void initState() {
    super.initState();

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      // delay until widget is built
      WidgetsBinding.instance.addPostFrameCallback((_) {
        Future.delayed(const Duration(seconds: 1), () {
          Navigator.popUntil(context, ModalRoute.withName('/map'));
          Navigator.pushNamed(context, '/chats/room',
              arguments: {'roomId': message.data['roomId']});
        });
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final totalHeight = MediaQuery.of(context).size.height;
    const headerHeight = 106.0;
    const previewHeight = 220.0;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: PgHeader(
        onPressed: () {
          setState(() {
            index = 0;
          });
        },
        actions: [
          PgIcon(
            PgIcons.chatBubbleLeftRight,
            color: index == 1 ? PgColors.violet_500 : PgColors.gray_800,
            onTap: () {
              setState(() {
                index = 1;
              });
            },
          ),
          PgIcon(
            PgIcons.user,
            color: index == 2 ? PgColors.violet_500 : PgColors.gray_800,
            onTap: () {
              setState(() {
                index = 2;
              });
            },
          )
        ],
      ),
      body: index == 0
          ? FutureBuilder(
              future: getPharmacies(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  return Stack(
                    children: [
                      BackgroundMap(
                        pharmacies: snapshot.data as List<PharmacyModel>,
                        onMapCreated: (controller) {
                          mapController = controller;
                        },
                        onDragChangeCallback: () {
                          setState(() {
                            isSelected = false;
                          });
                        },
                      ),
                      DraggableScrollableSheet(
                        minChildSize:
                            previewHeight / (totalHeight - headerHeight),
                        initialChildSize:
                            previewHeight / (totalHeight - headerHeight),
                        maxChildSize: isSelected
                            ? previewHeight / (totalHeight - headerHeight)
                            : 1 - 40 / (totalHeight - headerHeight),
                        builder: (context, scrollController) {
                          return Container(
                              decoration: const BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(16),
                                      topRight: Radius.circular(16))),
                              child: isSelected
                                  ? PreviewWidget(
                                      pharmacies:
                                          snapshot.data as List<PharmacyModel>,
                                      onTap: (lat, long, pharmacyId) {},
                                      isSelected: isSelected,
                                      selectedPharmacyId: selectedIndex)
                                  : ExpandedWidget(
                                      pharmacies:
                                          snapshot.data as List<PharmacyModel>,
                                      onTap: (lat, long, pharmacyId) {
                                        mapController
                                            ?.setCenter(LatLng(lat, long));
                                        setState(() {
                                          isSelected = true;
                                          scrollController.jumpTo(0);
                                          selectedIndex = pharmacyId;
                                        });
                                      },
                                      isSelected: isSelected,
                                      controller: scrollController));
                        },
                      )
                    ],
                  );
                } else if (snapshot.hasError) {
                  return Center(child: Text(snapshot.error.toString()));
                } else {
                  return const Center(child: CircularProgressIndicator());
                }
              })
          : index == 1
              ? const ChatsBody()
              : const MeBody(),
    );
  }
}

class ExpandedWidget extends StatefulWidget {
  const ExpandedWidget({
    super.key,
    required this.pharmacies,
    required this.onTap,
    required this.controller,
    required this.isSelected,
  });
  final List<PharmacyModel> pharmacies;
  final Function(double lat, double long, int pharmacyId)? onTap;
  final ScrollController? controller;
  final bool isSelected;

  @override
  State<ExpandedWidget> createState() => _ExpandedWidgetState();
}

class _ExpandedWidgetState extends State<ExpandedWidget> {
  bool isSelected = false;

  @override
  Widget build(BuildContext context) {
    final totalHeight = MediaQuery.of(context).size.height;
    const headerHeight = 106.0;
    const previewHeight = 220.0;
    return Container(
      padding: const EdgeInsets.all(16),
      height: isSelected ? previewHeight / (totalHeight + headerHeight) : null,
      width: double.infinity,
      decoration: const BoxDecoration(
        color: PgColors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Expanded(
            child: ListView.builder(
              controller: widget.controller,
              itemCount: widget.pharmacies.length + 1,
              itemBuilder: (context, index) {
                if (index == 0) {
                  return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          alignment: Alignment.center,
                          child: Container(
                            height: 4,
                            width: 40,
                            decoration: BoxDecoration(
                                color: PgColors.gray_200,
                                borderRadius: BorderRadius.circular(4)),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '채팅 가능 약국',
                          style: TextStyle(
                              fontSize: PgFontSize.xl_2.fontSize,
                              fontWeight: PgFontWeight.bold,
                              height: PgFontSize.xl_2.height),
                        ),
                        const SizedBox(height: 8)
                      ]);
                }
                final pharmacy = widget.pharmacies[index - 1];
                return PharmacyCard(
                  pharmacyId: pharmacy.id,
                  pharmacistName: pharmacy.pharmacists!
                      .firstWhere((element) => element.type == 'OWNER')
                      .name,
                  pharmacyName: pharmacy.name,
                  workTime: pharmacy.worktime,
                  imageUrl: pharmacy.profileImageUrl,
                  onTap: () {
                    if (widget.onTap != null) {
                      widget.onTap!(
                          pharmacy.latitude, pharmacy.longitude, pharmacy.id);
                    }
                  },
                );
              },
            ),
          )
        ],
      ),
    );
  }
}

class PreviewWidget extends StatefulWidget {
  const PreviewWidget({
    super.key,
    required this.pharmacies,
    required this.onTap,
    required this.isSelected,
    this.selectedPharmacyId,
  });
  final int? selectedPharmacyId;
  final List<PharmacyModel> pharmacies;
  final Function(double lat, double long, int pharmacyId)? onTap;
  final bool isSelected;

  @override
  State<PreviewWidget> createState() => _PreviewWidgetState();
}

class _PreviewWidgetState extends State<PreviewWidget> {
  bool isSelected = false;

  @override
  void didUpdateWidget(covariant PreviewWidget oldWidget) {
    // TODO: implement didUpdateWidget
    if (oldWidget.isSelected != widget.isSelected) {
      setState(() {
        isSelected = widget.isSelected;
      });
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    final pharmacy = widget.pharmacies
        .where((element) => element.id == widget.selectedPharmacyId)
        .firstOrNull;
    return Container(
      padding: const EdgeInsets.all(16),
      height: 300,
      width: double.infinity,
      decoration: const BoxDecoration(
        color: PgColors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(16),
          topRight: Radius.circular(16),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          isSelected
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      alignment: Alignment.center,
                      child: Container(
                        height: 4,
                        width: 40,
                        decoration: BoxDecoration(
                            color: PgColors.gray_200,
                            borderRadius: BorderRadius.circular(4)),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '채팅 가능 약국',
                      style: TextStyle(
                          fontSize: PgFontSize.xl_2.fontSize,
                          fontWeight: PgFontWeight.bold,
                          height: PgFontSize.xl_2.height),
                    ),
                  ],
                )
              : const SizedBox(),
          const SizedBox(height: 8),
          pharmacy != null
              ? PharmacyCard(
                  pharmacyId: pharmacy.id,
                  pharmacistName: pharmacy.pharmacists!
                      .firstWhere((element) => element.type == 'OWNER')
                      .name,
                  pharmacyName: pharmacy.name,
                  workTime: pharmacy.worktime,
                  imageUrl: pharmacy.profileImageUrl,
                  onTap: () {
                    if (widget.onTap != null) {
                      widget.onTap!(
                          pharmacy.latitude, pharmacy.longitude, pharmacy.id);
                    }
                  },
                )
              : const SizedBox()
        ],
      ),
    );
  }
}

class BackgroundMap extends StatefulWidget {
  final Function(KakaoMapController)? onMapCreated;
  final Function()? onDragChangeCallback;
  final List<PharmacyModel> pharmacies;
  const BackgroundMap({
    super.key,
    required this.pharmacies,
    this.onMapCreated,
    this.onDragChangeCallback,
  });

  @override
  State<BackgroundMap> createState() => _BackgroundMapState();
}

class _BackgroundMapState extends State<BackgroundMap> {
  List<Marker> markers = [];
  @override
  Widget build(BuildContext context) {
    return KakaoMap(
      onMapCreated: (controller) {
        for (final pharmacy in widget.pharmacies) {
          setState(() {
            markers.add(Marker(
              markerId: pharmacy.id.toString(),
              latLng: LatLng(pharmacy.latitude, pharmacy.longitude),
            ));
          });
        }
        if (widget.onMapCreated != null) {
          widget.onMapCreated!(controller);
        }
      },
      center: context.watch<LocationProvider>().latitude != null &&
              context.watch<LocationProvider>().longitude != null
          ? LatLng(context.watch<LocationProvider>().latitude!,
              context.watch<LocationProvider>().longitude!)
          : LatLng(37.5087553, 127.0632877),
      markers: markers,
      onDragChangeCallback: (_, __, ___) {
        if (widget.onDragChangeCallback != null) {
          widget.onDragChangeCallback!();
        }
      },
    );
  }
}
