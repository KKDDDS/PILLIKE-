import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:kakao_flutter_sdk/kakao_flutter_sdk.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/models/pharmacist_model.dart';
import 'package:pillgood_client/models/profile_model.dart';
import 'package:pillgood_client/providers/fcm_token_provider.dart';
import 'package:pillgood_client/providers/information_provider.dart';
import 'package:pillgood_client/providers/pharmacist_provider.dart';
import 'package:pillgood_client/providers/profile_provider.dart';
import 'package:pillgood_client/widgets/social_login_button.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as sb;

class KakaoUser {
  final String? id;
  final String? nickname;
  final String? email;
  final String? profileImageUrl;

  KakaoUser({this.id, this.nickname, this.email, this.profileImageUrl});
}

class LoginScreen extends StatefulWidget {
  LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final supabase = sb.Supabase.instance.client;
  KakaoUser? kakaoUser = null;

  goToSignUp(BuildContext context) {
    Navigator.pushNamed(
      context,
      '/signup',
    );
  }

  @override
  Widget build(BuildContext context) {
    final fcmTokenProvider = context.read<FcmTokenProvider>();

    supabase.auth.onAuthStateChange.listen((data) async {
      Map<String, dynamic>? userMetadata;
      ProfileModel? profileModel;
      final user = data.session?.user;
      PharmacistModel? pharmacistModel;
      if (user == null) {
        return;
      }
      try {
        final List<dynamic> profile = await supabase
            .from('profile')
            .select('*')
            .eq('user_id', supabase.auth.currentUser?.id);
        final List<dynamic> pharmacist = await supabase
            .from('pharmacist')
            .select('*')
            .eq('user_id', supabase.auth.currentUser?.id);

        if (pharmacist.isNotEmpty) {
          pharmacistModel = PharmacistModel.fromJson(pharmacist.first);
          // updating push notification token
          if (pharmacistModel.fcmToken != fcmTokenProvider.fcmToken &&
              fcmTokenProvider.fcmToken != null) {
            await supabase
                .from('pharmacist')
                .update({'fcm_token': fcmTokenProvider.fcmToken}).eq(
                    'user_id', pharmacistModel.userId);
          }
          if (pharmacistModel.type == 'MEMBER' &&
              pharmacistModel.isVerified == false) {
            Navigator.pushNamedAndRemoveUntil(
                context, '/pending', (route) => false);
          } else {
            context.read<PharmacistProvider>().setPharmacist(pharmacistModel);
            Navigator.pushNamedAndRemoveUntil(
                context, '/partner/home', (route) => false);
          }
        } else if (profile.isNotEmpty) {
          profileModel = ProfileModel.fromJson(profile.first!);
          // updating push notification token
          if (profileModel.fcmToken != fcmTokenProvider.fcmToken &&
              fcmTokenProvider.fcmToken != null) {
            await supabase
                .from('profile')
                .update({'fcm_token': fcmTokenProvider.fcmToken}).eq(
                    'user_id', profileModel.id);
          }
          context.read<ProfileProvider>().setProfile(profileModel);
          Navigator.pushNamedAndRemoveUntil(context, '/map', (route) => false);
        } else if (kakaoUser != null) {
          context.read<InformationProvider>().setKakaoUser(kakaoUser!);
          Navigator.pushNamedAndRemoveUntil(
              context, '/signup', (route) => false);
        } else {
          userMetadata = supabase.auth.currentUser?.userMetadata;
          context.read<InformationProvider>().setMetadata(userMetadata);
          Navigator.pushNamedAndRemoveUntil(
              context, '/signup', (route) => false);
        }
      } catch (e) {}
    });

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          children: [
            Expanded(
                child: Center(
                    child: Image.asset(
              'assets/images/Splash.png',
              height: 80,
            ))),
            PgGaps.h4,
            const Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  '간편하게 로그인하고',
                  style: TextStyle(
                      fontWeight: PgFontWeight.medium,
                      color: PgColors.gray_500),
                ),
                Text(
                  '내 근처 약사와 채팅하세요',
                  style: TextStyle(
                      fontWeight: PgFontWeight.medium,
                      color: PgColors.gray_500),
                ),
              ],
            ),
            PgGaps.h4,
            SocialLoginButton(
                type: SocialLoginType.kakao,
                onTap: (authProvider, authKey) async {
                  if (await isKakaoTalkInstalled()) {
                    try {
                      await UserApi.instance.loginWithKakaoTalk();
                      print('카카오톡으로 로그인 성공');
                    } catch (error) {
                      print('카카오톡으로 로그인 실패 $error');

                      // 사용자가 카카오톡 설치 후 디바이스 권한 요청 화면에서 로그인을 취소한 경우,
                      // 의도적인 로그인 취소로 보고 카카오계정으로 로그인 시도 없이 로그인 취소로 처리 (예: 뒤로 가기)
                      if (error is PlatformException &&
                          error.code == 'CANCELED') {
                        return;
                      }
                      // 카카오톡에 연결된 카카오계정이 없는 경우, 카카오계정으로 로그인
                      try {
                        await UserApi.instance.loginWithKakaoAccount();
                        print('카카오계정으로 로그인 성공');
                      } catch (error) {
                        print('카카오계정으로 로그인 실패 $error');
                      }
                    }
                  } else {
                    try {
                      await UserApi.instance.loginWithKakaoAccount();
                      print('카카오계정으로 로그인 성공');
                    } catch (error) {
                      print('카카오계정으로 로그인 실패 $error');
                    }
                  }
                  User user = await UserApi.instance.me();
                  try {
                    print('사용자 정보 요청 성공'
                        '\n회원번호: ${user.id}'
                        '\n닉네임: ${user.kakaoAccount?.profile?.nickname}'
                        '\n이메일: ${user.kakaoAccount?.email}'
                        '\n프로필사진: ${user.kakaoAccount?.profile?.profileImageUrl}');

                    kakaoUser = KakaoUser(
                        id: user.id.toString(),
                        nickname: user.kakaoAccount?.profile?.nickname,
                        email: user.kakaoAccount?.email,
                        profileImageUrl:
                            user.kakaoAccount?.profile?.profileImageUrl);

                    await supabase.auth.signInWithPassword(
                        password: user.id.toString(),
                        email: user.kakaoAccount?.email ?? '');
                  } catch (error) {
                    await supabase.auth.signUp(
                      password: user.id.toString(),
                      email: user.kakaoAccount?.email ?? '',
                    );
                  }
                }),
            PgGaps.h2,
            SocialLoginButton(
                type: SocialLoginType.apple,
                onTap: (authProvider, authKey) async {
                  try {
                    await supabase.auth.signInWithApple();
                  } catch (e) {}
                }),
            PgGaps.h10
          ],
        ),
      ),
    );
  }
}
