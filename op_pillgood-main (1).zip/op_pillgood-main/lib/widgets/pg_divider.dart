import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';

class PgDivider extends StatelessWidget {
  const PgDivider({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 1,
      decoration: const BoxDecoration(color: PgColors.gray_300),
    );
  }
}
