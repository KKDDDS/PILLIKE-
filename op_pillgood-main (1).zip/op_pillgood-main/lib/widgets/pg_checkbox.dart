import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_icons.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';

class PgCheckBox extends StatelessWidget {
  final bool checked;
  final Function(bool)? onChanged;
  const PgCheckBox({super.key, this.checked = false, this.onChanged});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (onChanged != null) onChanged!(!checked);
      },
      child: checked
          ? PgIcon(
              PgIcons.checkedBox,
              gradient: true,
            )
          : PgIcon(
              PgIcons.uncheckedBox,
              gradient: true,
            ),
    );
  }
}
