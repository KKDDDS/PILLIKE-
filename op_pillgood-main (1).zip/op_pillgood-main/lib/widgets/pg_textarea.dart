import 'package:flutter/material.dart';

class PgTextArea extends StatefulWidget {
  const PgTextArea({super.key});

  @override
  State<PgTextArea> createState() => _PgTextAreaState();
}

class _PgTextAreaState extends State<PgTextArea> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
