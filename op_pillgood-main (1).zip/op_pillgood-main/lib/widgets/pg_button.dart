import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_sizes.dart';

class PgButton extends StatelessWidget {
  final Widget child;
  final void Function()? onTap;
  final Color? color;
  final bool disabled;
  final bool border;
  final double width;
  const PgButton(
      {super.key,
      required this.child,
      this.onTap,
      this.color,
      this.disabled = false,
      this.border = false,
      this.width = double.infinity});

  @override
  Widget build(BuildContext context) {
    final backgroundColor = color ?? PgColors.violet_500;
    return GestureDetector(
      onTap: () {
        if (disabled) {
          return;
        }
        if (onTap != null) {
          onTap!();
        }
      },
      child: Container(
        width: width,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            color: disabled ? PgColors.gray_100 : backgroundColor,
            borderRadius: BorderRadius.circular(PgSizes.size4),
            border: border
                ? Border.all(color: PgColors.violet_500)
                : Border.fromBorderSide(BorderSide.none)),
        child: Padding(
          padding: const EdgeInsets.all(PgSizes.size4),
          child: child,
        ),
      ),
    );
  }
}
