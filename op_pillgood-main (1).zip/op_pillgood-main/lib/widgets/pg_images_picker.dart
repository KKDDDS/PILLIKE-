import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/constants/pg_icons.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class PgImagesPicker extends StatefulWidget {
  List<String> imageUrls;
  Function(String imageUrl)? onAdd;
  Function(String imageUrl)? onDelete;
  PgImagesPicker(
      {super.key, this.imageUrls = const [], this.onAdd, this.onDelete});

  @override
  State<PgImagesPicker> createState() => _PgImagesPickerState();
}

class _PgImagesPickerState extends State<PgImagesPicker> {
  final supabase = Supabase.instance.client;

  pickImages() async {
    final imagePicker = ImagePicker();
    final pickedFiles = await imagePicker.pickMultiImage();
    if (pickedFiles.isEmpty) return;
    if (pickedFiles.length + widget.imageUrls.length > 5) {
      // show snackbar
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('사진은 최대 5장까지 업로드 가능합니다.'),
        ),
      );
      return;
    }
    for (final pickedFile in pickedFiles) {
      final file = File(pickedFile.path);
      final url = await uploadImage(file);
      if (widget.onAdd != null) widget.onAdd!(url);
    }
  }

  Future<String> uploadImage(File file) async {
    String path = await supabase.storage.from('pillgood_bucket').upload(
        'profile/${DateTime.now().toString()}/${file.path.split('/').last}',
        file);
    path =
        'https://ycfiqhyfgurszwobmanj.supabase.co/storage/v1/object/public/$path';
    return path;
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          PlusButton(
            count: widget.imageUrls.length,
            onTap: () async {
              await pickImages();
              setState(() {});
            },
          ),
          ...widget.imageUrls
              .map((e) => ImageButton(
                    imageUrl: e,
                    onDelete: () {
                      if (widget.onDelete != null) widget.onDelete!(e);
                      setState(() {});
                    },
                  ))
              .toList()
        ],
      ),
    );
  }
}

class ImageButton extends StatelessWidget {
  final String imageUrl;
  final Function()? onDelete;
  const ImageButton({super.key, required this.imageUrl, this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        PgGaps.w2,
        Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                imageUrl,
                width: 128,
                height: 128,
                fit: BoxFit.cover,
              ),
            ),
            Positioned(
                bottom: 4,
                right: 4,
                child: GestureDetector(
                  onTap: onDelete,
                  child: Container(
                    decoration: BoxDecoration(
                        color: const Color.fromRGBO(0, 0, 0, 0.5),
                        borderRadius: BorderRadius.circular(8)),
                    padding: const EdgeInsets.all(4),
                    child: PgIcon(
                      PgIcons.xMark,
                      color: PgColors.white,
                    ),
                  ),
                ))
          ],
        ),
      ],
    );
  }
}

class PlusButton extends StatelessWidget {
  final Function()? onTap;
  final int count;
  const PlusButton({super.key, this.onTap, this.count = 0});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 128,
        height: 128,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            color: PgColors.violet_50,
            border: Border.all(color: PgColors.violet_100),
            borderRadius: BorderRadius.circular(8)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            PgIcon(
              PgIcons.plus,
              color: PgColors.violet_500,
            ),
            PgGaps.h2,
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  '사진 추가',
                  style: TextStyle(
                    fontSize: 12,
                    color: PgColors.violet_500,
                  ),
                ),
                PgGaps.w1,
                Text(
                  '${count.toString()}/5',
                  style: const TextStyle(
                    fontSize: 12,
                    color: PgColors.violet_500,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
