import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';

class PgMiniButton extends StatelessWidget {
  final String text;
  final void Function()? onTap;
  const PgMiniButton({super.key, this.text = '변경하기', this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: PgColors.gray_500),
            borderRadius: BorderRadius.circular(12.0),
          ),
          padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
          child: Text(
            text,
            style: TextStyle(
                color: PgColors.gray_500,
                fontSize: PgFontSize.sm.fontSize,
                fontWeight: PgFontWeight.bold,
                height: PgFontSize.sm.height),
          )),
    );
  }
}
