import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';

enum IconSize { sm, md, lg, xl, xl_2 }

class PgIcon extends StatelessWidget {
  const PgIcon(
    this.icon, {
    super.key,
    this.size = IconSize.md,
    this.color = PgColors.black,
    this.onTap,
    this.gradient = false,
  });

  final String icon;
  final IconSize size;
  final Color color;
  final void Function()? onTap;
  final bool gradient;

  @override
  Widget build(BuildContext context) {
    double getIconSize() {
      switch (size) {
        case IconSize.sm:
          return 16.0;
        case IconSize.md:
          return 24.0;
        case IconSize.lg:
          return 32.0;
        case IconSize.xl:
          return 40.0;
        case IconSize.xl_2:
          return 56.0;
      }
    }

    return GestureDetector(
      onTap: onTap,
      child: Image.asset(
        icon,
        width: getIconSize(),
        height: getIconSize(),
        color: gradient == true ? null : color,
      ),
    );
  }
}
