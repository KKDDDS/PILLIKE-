import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';
import '../constants/Pg_colors.dart';
import '../constants/Pg_font.dart';
import '../constants/Pg_icons.dart';

// showDialog(
//   context: context,
//   barrierColor: SystemColor.black.withOpacity(0.8),
//   builder: (_) => MyDialog(
//     title: '지원취소',
//     description: '[과천 종합청사역 씨제이 칸막이 작...]\n현장 지원을 취소하시겠어요?',
//     buttonLabel: '네, 지원 취소할게요',
//     onPressed: () {},
//   ),
// );

class PgDialog extends StatelessWidget {
  const PgDialog({
    required this.title,
    required this.description,
    required this.buttonLabel,
    required this.onPressed,
    super.key,
  });

  final String title;
  final String description;
  final String buttonLabel;
  final void Function() onPressed;

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(24.0),
      elevation: 0,
      clipBehavior: Clip.hardEdge,
      child: Container(
        padding: const EdgeInsets.all(24.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          color: PgColors.gray_100,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: TextStyle(
                      fontSize: PgFontSize.base.fontSize,
                      fontWeight: PgFontWeight.medium,
                      color: PgColors.gray_500),
                ),
                // 창 닫기
              ],
            ),
            PgGaps.h2,
            Text(
              description,
              style: TextStyle(
                fontSize: PgFontSize.xl.fontSize,
                fontWeight: PgFontWeight.bold,
              ),
            ),
            PgGaps.h8,
            SizedBox(
              width: double.infinity,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                            color: PgColors.violet_500,
                            borderRadius: BorderRadius.circular(16.0)),
                        alignment: Alignment.center,
                        child: Text(
                          '취소',
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: PgFontSize.base.fontSize,
                              color: PgColors.white),
                        ),
                      ),
                    ),
                  ),
                  PgGaps.w2,
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                        onPressed();
                      },
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                            border: Border.all(color: PgColors.gray_500),
                            borderRadius: BorderRadius.circular(16.0)),
                        alignment: Alignment.center,
                        child: Text(
                          '삭제하기',
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: PgFontSize.base.fontSize,
                              color: PgColors.gray_500),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
