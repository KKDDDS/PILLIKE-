import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';

class PgInput extends StatefulWidget {
  const PgInput({
    required this.labelText,
    this.initialValue,
    this.controller,
    this.inputFormatters,
    this.maxLength,
    this.keyboardType,
    this.onChanged,
    this.enabled = true,
    this.validated = false,
    this.onSubmitted,
    this.submitButtonText = '확인',
    this.disabledText = '',
    this.maxLines = 1,
    super.key,
  });

  final String? initialValue;
  final String labelText;
  final TextEditingController? controller;
  final List<TextInputFormatter>? inputFormatters;
  final int? maxLength;
  final TextInputType? keyboardType;
  final void Function(String value)? onChanged;
  final bool enabled;
  final bool validated;
  final void Function(String value)? onSubmitted;
  final String submitButtonText;
  final String disabledText;
  final int? maxLines;
  @override
  State<PgInput> createState() => _PgInputState();
}

class _PgInputState extends State<PgInput> {
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      onFieldSubmitted: (value) {
        if (widget.onSubmitted != null) {
          widget.onSubmitted!(value);
        }
      },
      textInputAction: TextInputAction.search,
      autocorrect: false,
      enableSuggestions: false,
      initialValue: widget.initialValue,
      controller: widget.controller,
      inputFormatters: widget.inputFormatters,
      maxLength: widget.maxLength,
      keyboardType: widget.keyboardType,
      enabled: widget.enabled,
      maxLines: widget.maxLines,
      onChanged: (value) {
        if (widget.onChanged != null) {
          widget.onChanged!(value);
        }
      },
      style: TextStyle(
        fontSize: PgFontSize.base.fontSize,
        height: PgFontSize.base.height,
        fontWeight: PgFontWeight.medium,
        color: widget.enabled ? PgColors.black : PgColors.gray_400,
      ),
      decoration: InputDecoration(
        labelText: widget.enabled ? widget.labelText : widget.disabledText,
        counterText: '',
        contentPadding: const EdgeInsets.all(16.0),
        floatingLabelBehavior: FloatingLabelBehavior.never,
        fillColor: widget.enabled ? PgColors.white : PgColors.gray_50,
        filled: true,
        labelStyle: TextStyle(
          fontSize: PgFontSize.base.fontSize,
          height: PgFontSize.base.height,
          fontWeight: PgFontWeight.medium,
          color: widget.enabled ? PgColors.gray_300 : PgColors.gray_400,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16.0),
          borderSide: BorderSide(
            color: PgColors.gray_300,
            width: 1.0,
          ),
        ),
        disabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16.0),
          borderSide: BorderSide(
            color: PgColors.gray_50,
            width: 1.0,
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16.0),
          borderSide: BorderSide(
            color: PgColors.gray_300,
            width: 1.0,
          ),
        ),
      ),
    );
  }
}

class PhoneNumberTextInputFormatter extends TextInputFormatter {
  late List<String> _masks;
  late String _separator;
  String? _prevMask;

  PhoneNumberTextInputFormatter({
    required List<String> masks,
    required String separator,
  }) {
    _separator = (separator.isNotEmpty) ? separator : '';

    if (masks.isNotEmpty) {
      _masks = masks;
      _masks.sort((l, r) => l.length.compareTo(r.length));
      _prevMask = masks[0];
    }
  }

  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue oldValue, TextEditingValue newValue) {
    final newText = newValue.text;
    final oldText = oldValue.text;

    if (newText.isEmpty || newText.length < oldText.length) {
      return newValue;
    }

    final pasted = (newText.length - oldText.length).abs() > 1;
    final mask = _masks.firstWhere((value) {
      final maskValue = pasted ? value.replaceAll(_separator, '') : value;
      return newText.length <= maskValue.length;
    }, orElse: () => '');

    if (mask.isEmpty) {
      return oldValue;
    }

    final needReset =
        (_prevMask != mask || newText.length - oldText.length > 1);
    _prevMask = mask;

    if (needReset) {
      final text = newText.replaceAll(_separator, '');
      String resetValue = '';
      int sep = 0;

      for (int i = 0; i < text.length; i++) {
        if (mask[i + sep] == _separator) {
          resetValue += _separator;
          ++sep;
        }
        resetValue += text[i];
      }

      return TextEditingValue(
        text: resetValue,
        selection: TextSelection.collapsed(offset: resetValue.length),
      );
    }

    if (newText.length < mask.length &&
        mask[newText.length - 1] == _separator) {
      final text =
          '$oldText$_separator${newText.substring(newText.length - 1)}';
      return TextEditingValue(
        text: text,
        selection: TextSelection.collapsed(offset: text.length),
      );
    }

    return newValue;
  }
}
