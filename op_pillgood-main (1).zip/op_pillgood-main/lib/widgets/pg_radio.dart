import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_icons.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';

class PgRadio extends StatelessWidget {
  final bool checked;
  final Function(bool)? onChanged;
  final bool disabled;
  const PgRadio(
      {super.key, this.checked = false, this.onChanged, this.disabled = false});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (disabled) {
          return;
        }
        if (onChanged != null) onChanged!(!checked);
      },
      child: checked
          ? PgIcon(
              PgIcons.checked,
              color: disabled ? PgColors.gray_400 : PgColors.violet_500,
            )
          : PgIcon(
              PgIcons.unchecked,
              color: disabled ? PgColors.gray_300 : PgColors.violet_300,
            ),
    );
  }
}
