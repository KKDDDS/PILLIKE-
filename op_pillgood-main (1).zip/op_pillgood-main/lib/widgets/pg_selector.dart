import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/constants/pg_icons.dart';
import 'package:pillgood_client/widgets/pg_icon.dart';

import '../constants/pg_colors.dart';

class PgSelector extends StatefulWidget {
  final String labelText;
  final bool selected;
  final List<String> options;
  final bool disabled;
  final void Function()? onPressed;
  final void Function(String value)? onChanged;
  const PgSelector({
    super.key,
    required this.labelText,
    this.selected = false,
    this.onPressed,
    this.options = const [],
    this.onChanged,
    this.disabled = false,
  });

  @override
  State<PgSelector> createState() => _PgSelectorState();
}

class _PgSelectorState extends State<PgSelector> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (widget.disabled) {
          return;
        }
        widget.onPressed?.call();
        showModalBottomSheet(
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(
              top: Radius.circular(16.0),
            ),
          ),
          context: context,
          builder: (BuildContext context) {
            return Container(
              height: 400,
              clipBehavior: Clip.hardEdge,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16.0),
                color: PgColors.white,
              ),
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 0),
                itemBuilder: (BuildContext context, int index) {
                  return GestureDetector(
                    // 터치 범위를 부모 위젯 크기에 종속
                    behavior: HitTestBehavior.opaque,
                    onTap: () {
                      if (widget.onChanged != null) {
                        widget.onChanged!(widget.options[index]);
                      }
                      Navigator.pop(context);
                    },
                    child: Container(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(widget.options[index]),
                    ),
                  );
                },
                separatorBuilder: (BuildContext context, int index) {
                  return const Divider(
                    height: 1.0,
                    thickness: 1.0,
                    color: PgColors.gray_100,
                  );
                },
                itemCount: widget.options.length,
              ),
            );
          },
        );
      },
      child: Container(
        padding: const EdgeInsets.all(15.0),
        decoration: BoxDecoration(
          border: Border.all(
            color: widget.disabled ? PgColors.gray_50 : PgColors.gray_300,
          ),
          borderRadius: BorderRadius.circular(16.0),
          color: widget.disabled ? PgColors.gray_50 : PgColors.white,
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(widget.labelText,
                  style: TextStyle(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w500,
                    color: widget.disabled ? PgColors.gray_400 : PgColors.black,
                  )),
            ),
            PgGaps.w10,
            PgIcon(
              PgIcons.chevronDown,
              color: widget.disabled ? PgColors.gray_400 : PgColors.black,
            ),
          ],
        ),
      ),
    );
  }
}
