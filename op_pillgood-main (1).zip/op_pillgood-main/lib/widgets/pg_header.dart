import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';

class PgHeader extends StatelessWidget implements PreferredSizeWidget {
  const PgHeader({
    super.key,
    this.title,
    this.onPressed,
    this.actions = const [],
  }) : preferredSize = const Size.fromHeight(56.0);

  @override
  final Size preferredSize;
  final String? title;
  final List<Widget> actions;

  final void Function()? onPressed;

  @override
  Widget build(BuildContext context) {
    List<Widget> renderContent() {
      if (title == null) {
        return [
          GestureDetector(
            onTap: onPressed,
            child: Image.asset(
              'assets/images/logo.png',
              height: 32.0,
            ),
          ),
          Wrap(
            spacing: 16.0,
            children: actions,
          )
        ];
      }
      return [
        Expanded(
          child: Text(
            title!,
            textAlign: TextAlign.left,
          ),
        ),
        actions.isNotEmpty
            ? Row(
                children: [PgGaps.w16, ...actions],
              )
            : PgGaps.w20,
      ];
    }

    return AppBar(
      surfaceTintColor: Colors.white,
      backgroundColor: Colors.white,
      elevation: 0,
      title: Container(
        decoration: BoxDecoration(
            border: Border(bottom: BorderSide(color: PgColors.gray_100))),
        child: Stack(
          children: [
            Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                mainAxisSize: MainAxisSize.max,
                children: renderContent(),
              ),
            ),
          ],
        ),
      ),
      titleSpacing: 0,
      automaticallyImplyLeading: false,
    );
  }
}
