import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';
import 'package:pillgood_client/constants/pg_sizes.dart';

enum SocialLoginType { kakao, apple }

class SocialLoginButton extends StatelessWidget {
  final SocialLoginType type;
  final void Function(String authProvider, String authKey) onTap;
  const SocialLoginButton({super.key, required this.type, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return type == SocialLoginType.kakao
        ? _KakaoLoginButton(
            onTap: onTap,
          )
        : _AppleLoginButton(
            onTap: onTap,
          );
  }
}

class _KakaoLoginButton extends StatelessWidget {
  final void Function(String authProvider, String authKey) onTap;
  const _KakaoLoginButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onTap('hello', 'world');
      },
      child: Container(
          padding: const EdgeInsets.symmetric(vertical: PgSizes.size3),
          decoration: BoxDecoration(
              color: Color.fromRGBO(254, 229, 0, 1),
              borderRadius: BorderRadius.all(Radius.circular(PgSizes.size4))),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/icons/kakao_login.png'),
              PgGaps.w4,
              const Text(
                '카카오로 로그인',
                style: TextStyle(
                  fontWeight: PgFontWeight.bold,
                  color: PgColors.black,
                ),
              ),
            ],
          )),
    );
  }
}

class _AppleLoginButton extends StatelessWidget {
  final void Function(String authProvider, String authKey) onTap;

  const _AppleLoginButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        onTap('hello', 'world');
      },
      child: Container(
          padding: const EdgeInsets.symmetric(vertical: PgSizes.size3),
          decoration: const BoxDecoration(
              color: PgColors.black,
              borderRadius: BorderRadius.all(Radius.circular(PgSizes.size4))),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/icons/apple_login.png'),
              PgGaps.w4,
              const Text(
                'Apple로 로그인',
                style: TextStyle(
                    fontWeight: PgFontWeight.bold, color: PgColors.white),
              ),
            ],
          )),
    );
  }
}
