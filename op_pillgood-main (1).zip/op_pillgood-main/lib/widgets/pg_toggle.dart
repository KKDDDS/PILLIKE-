import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';

class PgToggle extends StatefulWidget {
  bool value;
  final Function(bool)? onChanged;
  PgToggle({super.key, this.value = false, this.onChanged});

  @override
  State<PgToggle> createState() => _PgToggleState();
}

class _PgToggleState extends State<PgToggle> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          widget.onChanged!(widget.value);
        });
      },
      child: Container(
        width: 56,
        height: 28,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: PgColors.white,
        ),
        child: Stack(
          children: [
            AnimatedPositioned(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeIn,
              top: 4,
              right: widget.value ? 32 : 4,
              child: Container(
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(14),
                  color: widget.value ? PgColors.violet_400 : PgColors.gray_500,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
