import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_font.dart';
import 'package:pillgood_client/constants/pg_gaps.dart';

class PgTitle extends StatelessWidget {
  final String subtitle;
  final String title;
  const PgTitle({
    super.key,
    this.subtitle = '회원가입을 위해',
    this.title = '프로필을 입력해주세요',
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          subtitle,
          style: const TextStyle(
              fontWeight: PgFontWeight.medium,
              fontSize: 18,
              color: PgColors.gray_500),
        ),
        PgGaps.h1,
        Text(
          title,
          style: const TextStyle(
              fontWeight: PgFontWeight.bold,
              fontSize: 24,
              color: PgColors.black),
        ),
      ],
    );
  }
}
