import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/constants/pg_sizes.dart';
import 'package:pillgood_client/widgets/pg_button.dart';

class PgFAB extends StatelessWidget {
  final bool disabled;
  final String disabledText;
  final void Function()? onTap;
  final String text;
  const PgFAB(
      {super.key,
      this.disabled = false,
      this.onTap,
      this.text = '다음',
      this.disabledText = '모든 정보를 입력해주세요'});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      alignment: Alignment.bottomCenter,
      padding: const EdgeInsets.all(PgSizes.size4),
      child: SizedBox(
          height: PgSizes.size16,
          child: PgButton(
              disabled: disabled,
              onTap: () {
                if (onTap != null) {
                  onTap!();
                }
              },
              child: Text(
                disabled ? disabledText : text,
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: PgSizes.size5,
                    color: disabled ? PgColors.gray_300 : PgColors.white),
              ))),
    );
  }
}
