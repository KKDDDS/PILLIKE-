class PgFormatter {
  static formatDate(DateTime date) {
    // date to korean date
    // date = date.add(Duration(hours: 9));
    // check if date is today
    if (date.day == DateTime.now().toUtc().day) {
      // n분전, n시간전, n일전
      final diff = DateTime.now().toUtc().difference(date);
      if (diff.inMinutes < 60) {
        return '${diff.inMinutes}분 전';
      } else {
        return '${diff.inHours}시간 전';
      }
    } else {
      return '${date.month}월 ${date.day}일';
    }
  }

  static formatChatDate(DateTime date) {
    // make it to local time
    // return '${addZero(date.hour)}:${addZero(date.minute)}';
    // local korean time
    int hour = date.hour + 9;
    if (hour >= 24) {
      hour -= 24;
    }
    return '${addZero(hour)}:${addZero(date.minute)}';
  }

  static addZero(int number) {
    return number < 10 ? '0$number' : number;
  }
}
