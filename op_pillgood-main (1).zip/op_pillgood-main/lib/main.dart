import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:kakao_flutter_sdk/kakao_flutter_sdk.dart';
import 'package:kakao_map_plugin/kakao_map_plugin.dart';
import 'package:pillgood_client/constants/pg_colors.dart';
import 'package:pillgood_client/models/pharmacist_model.dart';
import 'package:pillgood_client/models/profile_model.dart';
import 'package:pillgood_client/providers/fcm_token_provider.dart';
import 'package:pillgood_client/providers/information_provider.dart';
import 'package:pillgood_client/providers/location_provider.dart';
import 'package:pillgood_client/providers/pharmacist_provider.dart';
import 'package:pillgood_client/screens/browser/pg_inapp_browser.dart';
import 'package:pillgood_client/screens/chats/%5BroomId%5D/chat_screen.dart';
import 'package:pillgood_client/screens/chats/category/category_screen.dart';
import 'package:pillgood_client/screens/chats/new/etc/etc_screen.dart';
import 'package:pillgood_client/screens/chats/new/guide/guide_screen.dart';
import 'package:pillgood_client/screens/chats/new/health/health_screen.dart';
import 'package:pillgood_client/screens/chats/new/interaction/interaction_screen.dart';
import 'package:pillgood_client/screens/chats/new/medicine/medicine_screen.dart';
import 'package:pillgood_client/screens/chats/new/side_effect/side_effect_screen.dart';
import 'package:pillgood_client/screens/login/login_screen.dart';
import 'package:pillgood_client/screens/map/map_screen.dart';
import 'package:pillgood_client/screens/me/profile_screen.dart';
import 'package:pillgood_client/screens/partner/chat/partner_chat_screen.dart';
import 'package:pillgood_client/screens/partner/home_screen.dart';
import 'package:pillgood_client/screens/partner/info/partner_info_screen.dart';
import 'package:pillgood_client/screens/partner/members/members_screen.dart';
import 'package:pillgood_client/screens/signup/info_screen.dart';
import 'package:pillgood_client/screens/signup/partner/code_partner_screen.dart';
import 'package:pillgood_client/screens/signup/partner/new_partner_screen.dart';
import 'package:pillgood_client/screens/signup/partner/pending_screen.dart';
import 'package:pillgood_client/screens/signup/signup_screen.dart';
import 'package:provider/provider.dart';
import 'providers/profile_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

Future<void> main() async {
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);
  AuthRepository.initialize(appKey: '11ed380820f6b939a2509f14ac075186');
  await Supabase.initialize(
    url: 'https://ycfiqhyfgurszwobmanj.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InljZmlxaHlmZ3Vyc3p3b2JtYW5qIiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTU4MDQ3NDQsImV4cCI6MjAxMTM4MDc0NH0.OKUTEB-DNMrR5mjNmgMBE96Thdqvt9oUZEqVFCFl5KI',
  );
  String initialRoute = '/login';
  Map<String, dynamic>? userMetadata;
  ProfileModel? profileModel;
  PharmacistModel? pharmacistModel;
  final supabase = Supabase.instance.client;
  String? fcmToken;
  try {
    FirebaseMessaging.instance.requestPermission(
      badge: true,
      alert: true,
      sound: true,
    );
    fcmToken = await FirebaseMessaging.instance.getToken();
  } catch (e) {
    fcmToken = null;
  }
  KakaoSdk.init(
    nativeAppKey: 'a5347df230be120c469c4ad458b1fa33',
    javaScriptAppKey: 'e39c55f136acb17b5b33236c46af0a80',
  );
  if (supabase.auth.currentUser != null &&
      supabase.auth.currentUser?.id != null) {
    final List<dynamic> profile = await supabase
        .from('profile')
        .select('*')
        .eq('user_id', supabase.auth.currentUser?.id);
    final List<dynamic> pharmacist = await supabase
        .from('pharmacist')
        .select('*')
        .eq('user_id', supabase.auth.currentUser?.id);

    if (pharmacist.isNotEmpty) {
      pharmacistModel = PharmacistModel.fromJson(pharmacist.first);
      // updating push notification token
      if (pharmacistModel.fcmToken != fcmToken && fcmToken != null) {
        await supabase
            .from('pharmacist')
            .update({'fcm_token': fcmToken}).eq('id', pharmacistModel.id);
      }
      if (pharmacistModel.type == 'MEMBER' &&
          pharmacistModel.isVerified == false) {
        initialRoute = '/pending';
      } else {
        initialRoute = '/partner/home';
      }
    } else if (profile.isNotEmpty) {
      profileModel = ProfileModel.fromJson(profile.first);
      // updating push notification token
      if (profileModel.fcmToken != fcmToken && fcmToken != null) {
        await supabase
            .from('profile')
            .update({'fcm_token': fcmToken}).eq('user_id', profileModel.id);
      }
      initialRoute = '/map';
    } else {
      userMetadata = supabase.auth.currentUser?.userMetadata;
      initialRoute = '/signup';
    }
  }

  FlutterNativeSplash.remove();

  runApp(MultiProvider(
      providers: [
        ChangeNotifierProvider(
            create: (_) => InformationProvider(userMetadata)),
        ChangeNotifierProvider(
            create: (_) => ProfileProvider(profileModel: profileModel)),
        ChangeNotifierProvider(
            create: (_) =>
                PharmacistProvider(pharmacistModel: pharmacistModel)),
        ChangeNotifierProvider(create: (_) => LocationProvider()),
        ChangeNotifierProvider(
            create: (_) => FcmTokenProvider(fcmToken: fcmToken))
      ],
      child: MyApp(
        initialRoute: initialRoute,
      )));
}

class MyApp extends StatefulWidget {
  final String initialRoute;
  const MyApp({super.key, this.initialRoute = '/login'});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: MaterialApp(
        initialRoute: widget.initialRoute,
        title: 'PillGood',
        theme: ThemeData(
          fontFamily: 'Pretendard',
          colorScheme: ColorScheme.fromSeed(seedColor: PgColors.violet_500),
          useMaterial3: true,
          scaffoldBackgroundColor: Colors.white,
        ),
        routes: {
          '/login': (context) => LoginScreen(),
          '/signup': (context) => const SignUpScreen(),
          '/info': (context) => const InfoScreen(),
          '/signup/partner': (context) => const NewPartnerScreen(),
          '/signup/partner/code': (context) => const CodePartnerScreen(),
          '/pending': (context) => const PendingScreen(),
          '/map': (context) => const MapScreen(),
          '/me/profile': (context) => const ProfileScreen(),
          '/partner/home': (context) => const PartnerHomeScreen(),
          '/partner/members': (context) => const MembersScreen(),
          '/partner/info': (context) => const PartnerInfoScreen(),
        },
        onGenerateRoute: (settings) {
          if (settings.name == '/browser') {
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (context) => PgInAppBrowser(
                      title: args['title'],
                      url: args['url'],
                    ));
          } else if (settings.name == '/chats/new/guide') {
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (context) => GuideScreen(
                      pharmacyId: args['pharmacyId'],
                    ));
          } else if (settings.name == '/chats/category') {
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (context) => CaregoryScreen(
                      pharmacyId: args['pharmacyId'],
                    ));
          } else if (settings.name == '/chats/new/health') {
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (context) => HealthScreen(
                      pharmacyId: args['pharmacyId'],
                    ));
          } else if (settings.name == '/chats/new/medicine') {
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (context) => MedicineScreen(
                      pharmacyId: args['pharmacyId'],
                    ));
          } else if (settings.name == '/chats/new/interaction') {
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (context) => InteractionScreen(
                      pharmacyId: args['pharmacyId'],
                    ));
          } else if (settings.name == '/chats/new/side_effect') {
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (context) => SideEffectScreen(
                      pharmacyId: args['pharmacyId'],
                    ));
          } else if (settings.name == '/chats/new/etc') {
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (context) => EtcScreen(
                      pharmacyId: args['pharmacyId'],
                    ));
          } else if (settings.name == '/chats/room') {
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (context) => ChatScreen(
                      roomId: args['roomId'].runtimeType == int
                          ? args['roomId']
                          : int.parse(args['roomId']),
                    ));
          } else if (settings.name == '/partner/chat') {
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
                builder: (context) => PartnerChatScreen(
                      roomId: args['roomId'],
                    ));
          }
        },
      ),
    );
  }
}
