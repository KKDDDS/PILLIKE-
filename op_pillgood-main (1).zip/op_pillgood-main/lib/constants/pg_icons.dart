class PgIcons {
  static String academicCap = const _PgIconData("academic-cap").path;
  static String briefcase = const _PgIconData("briefcase").path;
  static String ellipsisHorizontalCircle =
      const _PgIconData("ellipsis-horizontal-circle").path;
  static String phoneArrowUpRight =
      const _PgIconData("phone-arrow-up-right").path;
  static String adjustmentsHorizontal =
      const _PgIconData("adjustments-horizontal").path;
  static String bugAnt = const _PgIconData("bug-ant").path;
  static String ellipsisHorizontal =
      const _PgIconData("ellipsis-horizontal").path;
  static String phoneXMark = const _PgIconData("phone-x-mark").path;
  static String adjustmentsVertical =
      const _PgIconData("adjustments-vertical").path;
  static String buildingLibrary = const _PgIconData("building-library").path;
  static String ellipsisVertical = const _PgIconData("ellipsis-vertical").path;
  static String phone = const _PgIconData("phone").path;
  static String archiveBoxArrowDown =
      const _PgIconData("archive-box-arrow-down").path;
  static String buildingOffice2 = const _PgIconData("building-office-2").path;
  static String envelopeOpen = const _PgIconData("envelope-open").path;
  static String photo = const _PgIconData("photo").path;
  static String archiveBoxXMark = const _PgIconData("archive-box-x-mark").path;
  static String buildingOffice = const _PgIconData("building-office").path;
  static String envelope = const _PgIconData("envelope").path;
  static String playCircle = const _PgIconData("play-circle").path;
  static String archiveBox = const _PgIconData("archive-box").path;
  static String buildingStorefront =
      const _PgIconData("building-storefront").path;
  static String exclaimationCircle =
      const _PgIconData("exclaimation-circle").path;
  static String playPause = const _PgIconData("play-pause").path;
  static String arrowDownCircle = const _PgIconData("arrow-down-circle").path;
  static String cake = const _PgIconData("cake").path;
  static String exclamationTriangle =
      const _PgIconData("exclamation-triangle").path;
  static String play = const _PgIconData("play").path;
  static String arrowDownLeft = const _PgIconData("arrow-down-left").path;
  static String calculator = const _PgIconData("calculator").path;
  static String eyeDropper = const _PgIconData("eye-dropper").path;
  static String plusCircle = const _PgIconData("plus-circle").path;
  static String arrowDownOnSquareStack =
      const _PgIconData("arrow-down-on-square-stack").path;
  static String calendarDays = const _PgIconData("calendar-days").path;
  static String eyeSlash = const _PgIconData("eye-slash").path;
  static String plusSmall = const _PgIconData("plus-small").path;
  static String arrowDownOnSquare =
      const _PgIconData("arrow-down-on-square").path;
  static String calendar = const _PgIconData("calendar").path;
  static String eye = const _PgIconData("eye").path;
  static String plus = const _PgIconData("plus").path;
  static String arrowDownRight = const _PgIconData("arrow-down-right").path;
  static String camera = const _PgIconData("camera").path;
  static String faceFrown = const _PgIconData("face-frown").path;
  static String power = const _PgIconData("power").path;
  static String arrowDownTray = const _PgIconData("arrow-down-tray").path;
  static String chartBarSquare = const _PgIconData("chart-bar-square").path;
  static String faceSmile = const _PgIconData("face-smile").path;
  static String presentationChartBar =
      const _PgIconData("presentation-chart-bar").path;
  static String arrowDown = const _PgIconData("arrow-down").path;
  static String chartBar = const _PgIconData("chart-bar").path;
  static String film = const _PgIconData("film").path;
  static String presentationChartLine =
      const _PgIconData("presentation-chart-line").path;
  static String arrowLeftCircle = const _PgIconData("arrow-left-circle").path;
  static String chartPie = const _PgIconData("chart-pie").path;
  static String fingerprint = const _PgIconData("finger-print").path;
  static String printer = const _PgIconData("printer").path;
  static String arrowLeftOnRectangle =
      const _PgIconData("arrow-left-on-rectangle").path;
  static String chatBubbleBottomCenterText =
      const _PgIconData("chat-bubble-bottom-center-text").path;
  static String fire = const _PgIconData("fire").path;
  static String puzzlePiece = const _PgIconData("puzzle-piece").path;
  static String arrowLeft = const _PgIconData("arrow-left").path;
  static String chatBubbleBottomCenter =
      const _PgIconData("chat-bubble-bottom-center").path;
  static String flag = const _PgIconData("flag").path;
  static String qrCode = const _PgIconData("qr-code").path;
  static String arrowLongDown = const _PgIconData("arrow-long-down").path;
  static String chatBubbleLeftEllipsis =
      const _PgIconData("chat-bubble-left-ellipsis").path;
  static String folderArrowDown = const _PgIconData("folder-arrow-down").path;
  static String questionMarkCircle =
      const _PgIconData("question-mark-circle").path;
  static String arrowLongLeft = const _PgIconData("arrow-long-left").path;
  static String chatBubbleLeftRight =
      const _PgIconData("chat-bubble-left-right").path;
  static String folderMinus = const _PgIconData("folder-minus").path;
  static String queueList = const _PgIconData("queue-list").path;
  static String arrowLongRight = const _PgIconData("arrow-long-right").path;
  static String chatBubbleLeft = const _PgIconData("chat-bubble-left").path;
  static String folderOpen = const _PgIconData("folder-open").path;
  static String radio = const _PgIconData("radio").path;
  static String arrowLongUp = const _PgIconData("arrow-long-up").path;
  static String chatBubbleOvalLeftEllipsis =
      const _PgIconData("chat-bubble-oval-left-ellipsis").path;
  static String folderPlus = const _PgIconData("folder-plus").path;
  static String receiptPercent = const _PgIconData("receipt-percent").path;
  static String arrowPathRoundedSquare =
      const _PgIconData("arrow-path-rounded-square").path;
  static String chatBubbleOvalLeft =
      const _PgIconData("chat-bubble-oval-left").path;
  static String folder = const _PgIconData("folder").path;
  static String receiptRefund = const _PgIconData("receipt-refund").path;
  static String arrowPath = const _PgIconData("arrow-path").path;
  static String checkBadge = const _PgIconData("check-badge").path;
  static String forward = const _PgIconData("forward").path;
  static String rectangleGroup = const _PgIconData("rectangle-group").path;
  static String arrowRightCircle = const _PgIconData("arrow-right-circle").path;
  static String checkCircle = const _PgIconData("check-circle").path;
  static String funnel = const _PgIconData("funnel").path;
  static String rectangleStack = const _PgIconData("rectangle-stack").path;
  static String arrowRightOnRectangle =
      const _PgIconData("arrow-right-on-rectangle").path;
  static String check = const _PgIconData("check").path;
  static String gif = const _PgIconData("gif").path;
  static String rocketLaunch = const _PgIconData("rocket-launch").path;
  static String arrowRight = const _PgIconData("arrow-right").path;
  static String chevronDoubleDown =
      const _PgIconData("chevron-double-down").path;
  static String giftTop = const _PgIconData("gift-top").path;
  static String rss = const _PgIconData("rss").path;
  static String arrowSmallDown = const _PgIconData("arrow-small-down").path;
  static String chevronDoubleLeft =
      const _PgIconData("chevron-double-left").path;
  static String gift = const _PgIconData("gift").path;
  static String scale = const _PgIconData("scale").path;
  static String arrowSmallLeft = const _PgIconData("arrow-small-left").path;
  static String chevronDoubleRight =
      const _PgIconData("chevron-double-right").path;
  static String globeAlt = const _PgIconData("globe-alt").path;
  static String scissors = const _PgIconData("scissors").path;
  static String arrowSmallRight = const _PgIconData("arrow-small-right").path;
  static String chevronDoubleUp = const _PgIconData("chevron-double-up").path;
  static String globeAmericas = const _PgIconData("globe-americas").path;
  static String serverStack = const _PgIconData("server-stack").path;
  static String arrowSmallUp = const _PgIconData("arrow-small-up").path;
  static String chevronDown = const _PgIconData("chevron-down").path;
  static String globeAsiaAustralia =
      const _PgIconData("globe-asia-australia").path;
  static String server = const _PgIconData("server").path;
  static String arrowTopRightOnSquare =
      const _PgIconData("arrow-top-right-on-square").path;
  static String chevronLeft = const _PgIconData("chevron-left").path;
  static String globeEuropeAfrica =
      const _PgIconData("globe-europe-africa").path;
  static String share = const _PgIconData("share").path;
  static String arrowTrendingDown =
      const _PgIconData("arrow-trending-down").path;
  static String chevronRight = const _PgIconData("chevron-right").path;
  static String handRaised = const _PgIconData("hand-raised").path;
  static String shieldCheck = const _PgIconData("shield-check").path;
  static String arrowTrendingUp = const _PgIconData("arrow-trending-up").path;
  static String chevronUpDown = const _PgIconData("chevron-up-down").path;
  static String handThumbDown = const _PgIconData("hand-thumb-down").path;
  static String shieldExclamation =
      const _PgIconData("shield-exclamation").path;
  static String arrowUpCircle = const _PgIconData("arrow-up-circle").path;
  static String chevronUp = const _PgIconData("chevron-up").path;
  static String handThumbUp = const _PgIconData("hand-thumb-up").path;
  static String shoppingBag = const _PgIconData("shopping-bag").path;
  static String arrowUpLeft = const _PgIconData("arrow-up-left").path;
  static String circleStack = const _PgIconData("circle-stack").path;
  static String hashtag = const _PgIconData("hashtag").path;
  static String shoppingCart = const _PgIconData("shopping-cart").path;
  static String arrowUpOnSquareStack =
      const _PgIconData("arrow-up-on-square-stack").path;
  static String clipboardDocumentCheck =
      const _PgIconData("clipboard-document-check").path;
  static String heart = const _PgIconData("heart").path;
  static String signalSlash = const _PgIconData("signal-slash").path;
  static String arrowUpOnSquare = const _PgIconData("arrow-up-on-square").path;
  static String clipboardDocumentList =
      const _PgIconData("clipboard-document-list").path;
  static String homeModern = const _PgIconData("home-modern").path;
  static String signal = const _PgIconData("signal").path;
  static String arrowUpRight = const _PgIconData("arrow-up-right").path;
  static String clipboardDocument =
      const _PgIconData("clipboard-document").path;
  static String home = const _PgIconData("home").path;
  static String sparkles = const _PgIconData("sparkles").path;
  static String arrowUpTray = const _PgIconData("arrow-up-tray").path;
  static String clipboard = const _PgIconData("clipboard").path;
  static String identification = const _PgIconData("identification").path;
  static String speakerWave = const _PgIconData("speaker-wave").path;
  static String arrowUp = const _PgIconData("arrow-up").path;
  static String clock = const _PgIconData("clock").path;
  static String inboxArrowDown = const _PgIconData("inbox-arrow-down").path;
  static String speakerXMark = const _PgIconData("speaker-x-mark").path;
  static String arrowUturnDown = const _PgIconData("arrow-uturn-down").path;
  static String cloudArrowDown = const _PgIconData("cloud-arrow-down").path;
  static String inboxStack = const _PgIconData("inbox-stack").path;
  static String square2Stack = const _PgIconData("square-2-stack").path;
  static String arrowUturnLeft = const _PgIconData("arrow-uturn-left").path;
  static String cloudArrowUp = const _PgIconData("cloud-arrow-up").path;
  static String inbox = const _PgIconData("inbox").path;
  static String square3Stack3d = const _PgIconData("square-3-stack-3d").path;
  static String arrowUturnRight = const _PgIconData("arrow-uturn-right").path;
  static String cloud = const _PgIconData("cloud").path;
  static String informationCircle =
      const _PgIconData("information-circle").path;
  static String squares2x2 = const _PgIconData("squares-2x2").path;
  static String arrowUturnUp = const _PgIconData("arrow-uturn-up").path;
  static String codeBracketSquare =
      const _PgIconData("code-bracket-square").path;
  static String key = const _PgIconData("key").path;
  static String squaresPlus = const _PgIconData("squares-plus").path;
  static String arrowsPointingIn = const _PgIconData("arrows-pointing-in").path;
  static String codeBracket = const _PgIconData("code-bracket").path;
  static String language = const _PgIconData("language").path;
  static String star = const _PgIconData("star").path;
  static String arrowsPointingOut =
      const _PgIconData("arrows-pointing-out").path;
  static String cog6Tooth = const _PgIconData("cog-6-tooth").path;
  static String lifebuoy = const _PgIconData("lifebuoy").path;
  static String stopCircle = const _PgIconData("stop-circle").path;
  static String arrowsRightLeft = const _PgIconData("arrows-right-left").path;
  static String cog8Tooth = const _PgIconData("cog-8-tooth").path;
  static String lightBulb = const _PgIconData("light-bulb").path;
  static String stop = const _PgIconData("stop").path;
  static String arrowsUpDown = const _PgIconData("arrows-up-down").path;
  static String cog = const _PgIconData("cog").path;
  static String link = const _PgIconData("link").path;
  static String sun = const _PgIconData("sun").path;
  static String atSymbol = const _PgIconData("at-symbol").path;
  static String commandLine = const _PgIconData("command-line").path;
  static String listBullet = const _PgIconData("list-bullet").path;
  static String swatch = const _PgIconData("swatch").path;
  static String backspace = const _PgIconData("backspace").path;
  static String computerDesktop = const _PgIconData("computer-desktop").path;
  static String lockClosed = const _PgIconData("lock-closed").path;
  static String tableCells = const _PgIconData("table-cells").path;
  static String backward = const _PgIconData("backward").path;
  static String cpuChip = const _PgIconData("cpu-chip").path;
  static String lockOpen = const _PgIconData("lock-open").path;
  static String tag = const _PgIconData("tag").path;
  static String banknotes = const _PgIconData("banknotes").path;
  static String creditCard = const _PgIconData("credit-card").path;
  static String magnifyingGlassCircle =
      const _PgIconData("magnifying-glass-circle").path;
  static String ticket = const _PgIconData("ticket").path;
  static String bars2 = const _PgIconData("bars-2").path;
  static String cubeTransparent = const _PgIconData("cube-transparent").path;
  static String magnifyingGlassMinus =
      const _PgIconData("magnifying-glass-minus").path;
  static String trash = const _PgIconData("trash").path;
  static String bars3BottomLeft = const _PgIconData("bars-3-bottom-left").path;
  static String cube = const _PgIconData("cube").path;
  static String magnifyingGlassPlus =
      const _PgIconData("magnifying-glass-plus").path;
  static String trophy = const _PgIconData("trophy").path;
  static String bars3BottomRight =
      const _PgIconData("bars-3-bottom-right").path;
  static String currencyBangladeshi =
      const _PgIconData("currency-bangladeshi").path;
  static String magnifyingGlass = const _PgIconData("magnifying-glass").path;
  static String truck = const _PgIconData("truck").path;
  static String bars3CenterLeft = const _PgIconData("bars-3-center-left").path;
  static String currencyDollar = const _PgIconData("currency-dollar").path;
  static String mapPin = const _PgIconData("map-pin").path;
  static String tv = const _PgIconData("tv").path;
  static String bars3 = const _PgIconData("bars-3").path;
  static String currencyEuro = const _PgIconData("currency-euro").path;
  static String map = const _PgIconData("map").path;
  static String userCircle = const _PgIconData("user-circle").path;
  static String bars4 = const _PgIconData("bars-4").path;
  static String currencyPound = const _PgIconData("currency-pound").path;
  static String megaphone = const _PgIconData("megaphone").path;
  static String userGroup = const _PgIconData("user-group").path;
  static String barsArrowDown = const _PgIconData("bars-arrow-down").path;
  static String currencyRupee = const _PgIconData("currency-rupee").path;
  static String microphone = const _PgIconData("microphone").path;
  static String userMinus = const _PgIconData("user-minus").path;
  static String barsArrowUp = const _PgIconData("bars-arrow-up").path;
  static String currencyYen = const _PgIconData("currency-yen").path;
  static String minusCircle = const _PgIconData("minus-circle").path;
  static String userPlus = const _PgIconData("user-plus").path;
  static String battery0 = const _PgIconData("battery-0").path;
  static String cursorArrowRays = const _PgIconData("cursor-arrow-rays").path;
  static String minusSmall = const _PgIconData("minus-small").path;
  static String user = const _PgIconData("user").path;
  static String battery100 = const _PgIconData("battery-100").path;
  static String cursorArrowRipple =
      const _PgIconData("cursor-arrow-ripple").path;
  static String minus = const _PgIconData("minus").path;
  static String users = const _PgIconData("users").path;
  static String battery50 = const _PgIconData("battery-50").path;
  static String devicePhoneMobile =
      const _PgIconData("device-phone-mobile").path;
  static String moon = const _PgIconData("moon").path;
  static String variable = const _PgIconData("variable").path;
  static String beaker = const _PgIconData("beaker").path;
  static String deviceTablet = const _PgIconData("device-tablet").path;
  static String musicalNote = const _PgIconData("musical-note").path;
  static String videoCameraSlash = const _PgIconData("video-camera-slash").path;
  static String bellAlert = const _PgIconData("bell-alert").path;
  static String documentArrowDown =
      const _PgIconData("document-arrow-down").path;
  static String newspaper = const _PgIconData("newspaper").path;
  static String videoCamera = const _PgIconData("video-camera").path;
  static String bellSlash = const _PgIconData("bell-slash").path;
  static String documentArrowUp = const _PgIconData("document-arrow-up").path;
  static String noSymbol = const _PgIconData("no-symbol").path;
  static String viewColumns = const _PgIconData("view-columns").path;
  static String bellSnooze = const _PgIconData("bell-snooze").path;
  static String documentChartBar = const _PgIconData("document-chart-bar").path;
  static String paintBrush = const _PgIconData("paint-brush").path;
  static String viewfinderDot = const _PgIconData("viewfinder-dot").path;
  static String bell = const _PgIconData("bell").path;
  static String documentCheck = const _PgIconData("document-check").path;
  static String paperAirplane = const _PgIconData("paper-airplane").path;
  static String wallet = const _PgIconData("wallet").path;
  static String boltSlash = const _PgIconData("bolt-slash").path;
  static String documentDuplicate =
      const _PgIconData("document-duplicate").path;
  static String paperClip = const _PgIconData("paper-clip").path;
  static String wifi = const _PgIconData("wifi").path;
  static String bolt = const _PgIconData("bolt").path;
  static String documentMagnifyingGlass =
      const _PgIconData("document-magnifying-glass").path;
  static String pauseCircle = const _PgIconData("pause-circle").path;
  static String window = const _PgIconData("window").path;
  static String bookOpen = const _PgIconData("book-open").path;
  static String documentMinus = const _PgIconData("document-minus").path;
  static String pause = const _PgIconData("pause").path;
  static String wrenchScrewdriver =
      const _PgIconData("wrench-screwdriver").path;
  static String bookmarkSlash = const _PgIconData("bookmark-slash").path;
  static String documentPlus = const _PgIconData("document-plus").path;
  static String pencilSquare = const _PgIconData("pencil-square").path;
  static String wrench = const _PgIconData("wrench").path;
  static String bookmarkSquare = const _PgIconData("bookmark-square").path;
  static String documentText = const _PgIconData("document-text").path;
  static String pencil = const _PgIconData("pencil").path;
  static String xCircle = const _PgIconData("x-circle").path;
  static String bookmark = const _PgIconData("bookmark").path;
  static String document = const _PgIconData("document").path;
  static String phoneArrowDownLeft =
      const _PgIconData("phone-arrow-down-left").path;
  static String xMark = const _PgIconData("x-mark").path;
  // checked
  static String checked = const _PgIconData("checked").path;
  // unchecked
  static String unchecked = const _PgIconData("unchecked").path;
  // checkedBox
  static String checkedBox = const _PgIconData("checked-box").path;
  // uncheckedBox
  static String uncheckedBox = const _PgIconData("unchecked-box").path;
}

class _PgIconData {
  const _PgIconData(this.name);
  final String name;
  final _location = 'assets/icons/';
  String get path => '$_location$name.png';
}
