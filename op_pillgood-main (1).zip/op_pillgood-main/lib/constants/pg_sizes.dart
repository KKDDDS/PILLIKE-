class PgSizes {
  static const double size1 = 4.0;
  static const double size2 = 8.0;
  static const double size3 = 12.0;
  static const double size4 = 16.0;
  static const double size5 = 20.0;
  static const double size6 = 24.0;
  static const double size7 = 28.0;
  static const double size8 = 32.0;
  static const double size9 = 36.0;
  static const double size10 = 40.0;
  static const double size11 = 44.0;
  static const double size12 = 48.0;
  static const double size13 = 52.0;
  static const double size14 = 56.0;
  static const double size15 = 60.0;
  static const double size16 = 64.0;
  static const double size17 = 68.0;
  static const double size18 = 72.0;
  static const double size19 = 76.0;
  static const double size20 = 80.0;
}
