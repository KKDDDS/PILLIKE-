import 'package:flutter/material.dart';
import 'package:pillgood_client/constants/pg_sizes.dart';

class PgGaps {
  static const SizedBox w1 = SizedBox(width: PgSizes.size1, height: 0);
  static const SizedBox w2 = SizedBox(width: PgSizes.size2, height: 0);
  static const SizedBox w3 = SizedBox(width: PgSizes.size3, height: 0);
  static const SizedBox w4 = SizedBox(width: PgSizes.size4, height: 0);
  static const SizedBox w5 = SizedBox(width: PgSizes.size5, height: 0);
  static const SizedBox w6 = SizedBox(width: PgSizes.size6, height: 0);
  static const SizedBox w7 = SizedBox(width: PgSizes.size7, height: 0);
  static const SizedBox w8 = SizedBox(width: PgSizes.size8, height: 0);
  static const SizedBox w9 = SizedBox(width: PgSizes.size9, height: 0);
  static const SizedBox w10 = SizedBox(width: PgSizes.size10, height: 0);
  static const SizedBox w11 = SizedBox(width: PgSizes.size11, height: 0);
  static const SizedBox w12 = SizedBox(width: PgSizes.size12, height: 0);
  static const SizedBox w13 = SizedBox(width: PgSizes.size13, height: 0);
  static const SizedBox w14 = SizedBox(width: PgSizes.size14, height: 0);
  static const SizedBox w15 = SizedBox(width: PgSizes.size15, height: 0);
  static const SizedBox w16 = SizedBox(width: PgSizes.size16, height: 0);
  static const SizedBox w17 = SizedBox(width: PgSizes.size17, height: 0);
  static const SizedBox w18 = SizedBox(width: PgSizes.size18, height: 0);
  static const SizedBox w19 = SizedBox(width: PgSizes.size19, height: 0);
  static const SizedBox w20 = SizedBox(width: PgSizes.size20, height: 0);

  static const SizedBox h1 = SizedBox(height: PgSizes.size1, width: 0);
  static const SizedBox h2 = SizedBox(height: PgSizes.size2, width: 0);
  static const SizedBox h3 = SizedBox(height: PgSizes.size3, width: 0);
  static const SizedBox h4 = SizedBox(height: PgSizes.size4, width: 0);
  static const SizedBox h5 = SizedBox(height: PgSizes.size5, width: 0);
  static const SizedBox h6 = SizedBox(height: PgSizes.size6, width: 0);
  static const SizedBox h7 = SizedBox(height: PgSizes.size7, width: 0);
  static const SizedBox h8 = SizedBox(height: PgSizes.size8, width: 0);
  static const SizedBox h9 = SizedBox(height: PgSizes.size9, width: 0);
  static const SizedBox h10 = SizedBox(height: PgSizes.size10, width: 0);
  static const SizedBox h11 = SizedBox(height: PgSizes.size11, width: 0);
  static const SizedBox h12 = SizedBox(height: PgSizes.size12, width: 0);
  static const SizedBox h13 = SizedBox(height: PgSizes.size13, width: 0);
  static const SizedBox h14 = SizedBox(height: PgSizes.size14, width: 0);
  static const SizedBox h15 = SizedBox(height: PgSizes.size15, width: 0);
  static const SizedBox h16 = SizedBox(height: PgSizes.size16, width: 0);
  static const SizedBox h17 = SizedBox(height: PgSizes.size17, width: 0);
  static const SizedBox h18 = SizedBox(height: PgSizes.size18, width: 0);
  static const SizedBox h19 = SizedBox(height: PgSizes.size19, width: 0);
  static const SizedBox h20 = SizedBox(height: PgSizes.size20, width: 0);
}
