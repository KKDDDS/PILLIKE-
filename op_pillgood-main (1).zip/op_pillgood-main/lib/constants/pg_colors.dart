import 'package:flutter/material.dart';

class PgColors {
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF000000);

  static const Color violet_50 = Color(0xFFF7F5FF);
  static const Color violet_100 = Color(0xFFF0ECFF);
  static const Color violet_200 = Color(0xFFD9CFFF);
  static const Color violet_300 = Color(0xFFC3B3FF);
  static const Color violet_400 = Color(0xFF967AFF);
  static const Color violet_500 = Color(0xFF6941FF);
  static const Color violet_600 = Color(0xFF5434CC);
  static const Color violet_700 = Color(0xFF4A2EB2);
  static const Color violet_800 = Color(0xFF3A248C);
  static const Color violet_900 = Color(0xFF2A1A66);

  static const Color gray_50 = Color(0xFFF9FAFB);
  static const Color gray_100 = Color(0xFFF3F4F6);
  static const Color gray_200 = Color(0xFFE5E7EB);
  static const Color gray_300 = Color(0xFFD1D5DB);
  static const Color gray_400 = Color(0xFF9CA3AF);
  static const Color gray_500 = Color(0xFF6B7280);
  static const Color gray_600 = Color(0xFF4B5563);
  static const Color gray_700 = Color(0xFF374151);
  static const Color gray_800 = Color(0xFF1F2937);
  static const Color gray_900 = Color(0xFF111827);

  static const Color red_50 = Color(0xFFFEF2F2);
  static const Color red_500 = Color(0xFFEF4444);
}
