import 'package:flutter/material.dart';
import 'package:pillgood_client/models/pharmacist_model.dart';

class PharmacistProvider with ChangeNotifier {
  PharmacistModel? pharmacistModel;

  PharmacistProvider({
    this.pharmacistModel,
  });

  setPharmacist(PharmacistModel pharmacistModel) {
    this.pharmacistModel = pharmacistModel;
    notifyListeners();
  }
}
