import 'package:flutter/material.dart';
import 'package:pillgood_client/models/profile_model.dart';

class ProfileProvider with ChangeNotifier {
  ProfileModel? profileModel;
  ProfileProvider({this.profileModel});

  void setProfile(ProfileModel profileModel) {
    this.profileModel = profileModel;
    notifyListeners();
  }
}
