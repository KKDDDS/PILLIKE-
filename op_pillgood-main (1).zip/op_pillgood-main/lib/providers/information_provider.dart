import 'package:flutter/material.dart';
import 'package:pillgood_client/screens/login/login_screen.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class InformationProvider with ChangeNotifier {
  String name = '';
  int birthYear = 2000;
  String profileImageUrl = '';
  String sex = 'male';
  String drinking = '거의 하지 않음';
  String smoking = '비흡연';
  String pregnant = '없음';
  String disease = '';
  String cautions = '';
  bool termsAgree = false;
  bool privacyAgree = false;
  String type = 'NORMAL';
  final supabase = Supabase.instance.client;

  InformationProvider(Map<String, dynamic>? userMatadata) {
    if (userMatadata?['name'] != null) {
      name = userMatadata?['name'];
    }

    // profileImageUrl
    if (userMatadata?['avatar_url'] != null) {
      profileImageUrl = userMatadata?['avatar_url'];
    }
  }

  void setName(String name) {
    this.name = name;
    notifyListeners();
  }

  void setBirthYear(int birthYear) {
    this.birthYear = birthYear;
    notifyListeners();
  }

  void setProfileImageUrl(String profileImageUrl) {
    this.profileImageUrl = profileImageUrl;
    notifyListeners();
  }

  void setSex(String sex) {
    this.sex = sex;
    notifyListeners();
  }

  void setDrinking(String drinking) {
    this.drinking = drinking;
    notifyListeners();
  }

  void setSmoking(String smoking) {
    this.smoking = smoking;
    notifyListeners();
  }

  void setPregnant(String pregnant) {
    this.pregnant = pregnant;
    notifyListeners();
  }

  void setDisease(String disease) {
    this.disease = disease;
    notifyListeners();
  }

  void setCautions(String cautions) {
    this.cautions = cautions;
    notifyListeners();
  }

  void setTermsAgree(bool termsAgree) {
    this.termsAgree = termsAgree;
    notifyListeners();
  }

  void setPrivacyAgree(bool privacyAgree) {
    this.privacyAgree = privacyAgree;
    notifyListeners();
  }

  void setMetadata(Map<String, dynamic>? userMatadata) {
    if (userMatadata?['name'] != null) {
      name = userMatadata?['name'];
    }

    // profileImageUrl
    if (userMatadata?['avatar_url'] != null) {
      profileImageUrl = userMatadata?['avatar_url'];
    }
  }

  void setKakaoUser(KakaoUser kakaoUser) {
    name = kakaoUser.nickname!;
    profileImageUrl = kakaoUser.profileImageUrl!;
    notifyListeners();
  }

  get isCreating =>
      name.isEmpty ||
      birthYear == 0 ||
      profileImageUrl.isEmpty ||
      drinking.isEmpty ||
      smoking.isEmpty ||
      pregnant.isEmpty ||
      termsAgree == false ||
      privacyAgree == false;

  Future<dynamic> create(String? fcmToken) async {
    final data = await supabase
        .from('profile')
        .insert({
          'name': name,
          'birthyear': birthYear,
          'sex': sex,
          'drink': drinking,
          'smoke': smoking,
          'pregnant': pregnant,
          'disease': disease,
          'cautions': cautions,
          'terms_agree': termsAgree,
          'privacy_agree': privacyAgree,
          'profile_image_url': profileImageUrl,
          'type': type,
          'user_id': supabase.auth.currentUser?.id,
          'fcm_token': fcmToken,
        })
        .select()
        .single();
    return data;
  }
}
