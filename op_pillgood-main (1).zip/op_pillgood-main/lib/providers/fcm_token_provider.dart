import 'package:flutter/material.dart';

class FcmTokenProvider with ChangeNotifier {
  String? _fcmToken;

  FcmTokenProvider({required String? fcmToken}) : _fcmToken = fcmToken;

  String? get fcmToken => _fcmToken ?? '';

  set fcmToken(String? value) {
    _fcmToken = value;
    notifyListeners();
  }
}
