import 'dart:convert';

import 'package:http/http.dart' as http;

class LocationModel {
  final String address;
  final double lat;
  final double lon;
  LocationModel({
    required this.address,
    required this.lat,
    required this.lon,
  });
}

class KakaoApiService {
  final header = {'Authorization': 'KakaoAK 3b09d3215977a32337021c8ff17aa89e'};
  Future<LocationModel?> searchByKeyword(String query) async {
    final response = await http.get(
        Uri.parse(
            'https://dapi.kakao.com/v2/local/search/keyword.json?query=$query'),
        headers: header);
    final data = jsonDecode(response.body);

    final meta = data['meta'];
    if (meta['total_count'] == 0) {
      return null;
    }
    List<LocationModel> results = [];
    final documents = data['documents'] as List<dynamic>;
    for (var document in documents) {
      final address = '${document['place_name']} ${document['address_name']}';
      final lat = double.parse(document['y']);
      final lon = double.parse(document['x']);
      results.add(LocationModel(address: address, lat: lat, lon: lon));
    }

    return results.firstOrNull;
  }
}
