import 'package:pillgood_client/models/chat_info_model.dart';

class ChatModel {
  int id;
  DateTime createdAt;
  DateTime updatedAt;
  List<ChatInfoModel>? chatInfos;

  ChatModel({
    required this.id,
    required this.createdAt,
    required this.updatedAt,
    required this.chatInfos,
  });

  factory ChatModel.fromJson(Map<String, dynamic> json) {
    return ChatModel(
      id: json['id'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      chatInfos: json['chat_infos'] != null
          ? (json['chat_infos'] as List<dynamic>)
              .map((e) => ChatInfoModel.fromJson(e))
              .toList()
          : [],
    );
  }
}
