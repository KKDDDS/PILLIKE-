import 'package:pillgood_client/models/pharmacist_model.dart';

class PharmacyModel {
  int id;
  String name;
  String profileImageUrl;
  DateTime createdAt;
  DateTime updatedAt;
  String worktime;
  String postcode;
  String address;
  String addressDetail;
  String verifyDocumentUrl;
  double latitude;
  double longitude;
  bool isVerified;
  bool termsAgree;
  bool privacyAgree;
  bool isWorking;
  List<PharmacistModel>? pharmacists;

  PharmacyModel({
    required this.id,
    required this.name,
    required this.profileImageUrl,
    required this.createdAt,
    required this.updatedAt,
    required this.worktime,
    required this.postcode,
    required this.address,
    required this.addressDetail,
    required this.verifyDocumentUrl,
    required this.isVerified,
    required this.termsAgree,
    required this.privacyAgree,
    required this.isWorking,
    required this.latitude,
    required this.longitude,
    this.pharmacists,
  });

  factory PharmacyModel.fromJson(Map<String, dynamic> json) {
    return PharmacyModel(
      id: json['id'],
      name: json['name'],
      profileImageUrl: json['profile_image_url'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      worktime: json['worktime'],
      postcode: json['postcode'],
      address: json['address'],
      addressDetail: json['address_detail'],
      verifyDocumentUrl: json['verify_document_url'],
      isVerified: json['is_verified'],
      termsAgree: json['terms_agree'],
      privacyAgree: json['privacy_agree'],
      isWorking: json['is_working'],
      latitude: json['latitude'],
      longitude: json['longitude'],
      pharmacists: json['pharmacist'] != null
          ? (json['pharmacist'] as List<dynamic>)
              .map((e) => PharmacistModel.fromJson(e))
              .toList()
          : null,
    );
  }
}
