import 'package:pillgood_client/models/chat_info_image_model.dart';

class ChatInfoModel {
  int id;
  DateTime createdAt;
  String title;
  String answer;
  List<ChatInfoImageModel> images;

  ChatInfoModel({
    required this.id,
    required this.createdAt,
    required this.title,
    required this.answer,
    required this.images,
  });

  factory ChatInfoModel.fromJson(Map<String, dynamic> json) {
    return ChatInfoModel(
      id: json['id'],
      createdAt: DateTime.parse(json['created_at']),
      title: json['title'],
      answer: json['answer'],
      // with null check
      images: json['chat_info_image'] != null
          ? (json['chat_info_image'] as List<dynamic>)
              .map((e) => ChatInfoImageModel.fromJson(e))
              .toList()
          : [],
    );
  }
}
