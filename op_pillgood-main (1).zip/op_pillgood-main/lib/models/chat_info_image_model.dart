class ChatInfoImageModel {
  int id;
  DateTime createdAt;
  String imageUrl;

  ChatInfoImageModel({
    required this.id,
    required this.createdAt,
    required this.imageUrl,
  });

  factory ChatInfoImageModel.fromJson(Map<String, dynamic> json) {
    return ChatInfoImageModel(
      id: json['id'],
      createdAt: DateTime.parse(json['created_at']),
      imageUrl: json['image_url'],
    );
  }
}
