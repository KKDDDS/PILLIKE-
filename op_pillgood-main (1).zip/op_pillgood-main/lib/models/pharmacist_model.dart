class PharmacistModel {
  int id;
  DateTime createdAt;
  DateTime updatedAt;
  String verifyDocumnetUrl;
  bool isVerified;
  int pharmacyId;
  String userId;
  String name;
  String type;
  String fcmToken;

  PharmacistModel({
    required this.id,
    required this.createdAt,
    required this.updatedAt,
    required this.verifyDocumnetUrl,
    required this.isVerified,
    required this.pharmacyId,
    required this.userId,
    required this.name,
    required this.type,
    required this.fcmToken,
  });

  factory PharmacistModel.fromJson(Map<String, dynamic> json) {
    return PharmacistModel(
      id: json['id'],
      createdAt: DateTime.parse(json['created_at']),
      updatedAt: DateTime.parse(json['updated_at']),
      verifyDocumnetUrl: json['verify_document_url'],
      isVerified: json['is_verified'],
      pharmacyId: json['pharmacy_id'],
      userId: json['user_id'],
      name: json['name'],
      type: json['type'],
      fcmToken: json['fcm_token'],
    );
  }
}
