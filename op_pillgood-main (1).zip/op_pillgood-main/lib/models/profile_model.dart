class ProfileModel {
  final String id;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String name;
  final String sex;
  final int birthyear;
  final String drink;
  final String smoke;
  final String pregnant;
  final String disease;
  final String cautions;
  final String profileImageUrl;
  final bool termsAgree;
  final bool privacyAgree;
  final String type;
  final String fcmToken;

  const ProfileModel({
    required this.id,
    required this.createdAt,
    required this.updatedAt,
    required this.name,
    required this.sex,
    required this.birthyear,
    required this.drink,
    required this.smoke,
    required this.pregnant,
    required this.disease,
    required this.cautions,
    required this.profileImageUrl,
    required this.termsAgree,
    required this.privacyAgree,
    required this.type,
    required this.fcmToken,
  });

  factory ProfileModel.fromJson(Map<String, dynamic> json) {
    return ProfileModel(
        id: json['user_id'],
        createdAt: DateTime.parse(json['created_at']),
        updatedAt: DateTime.parse(json['updated_at']),
        name: json['name'],
        sex: json['sex'],
        birthyear: json['birthyear'],
        drink: json['drink'],
        smoke: json['smoke'],
        pregnant: json['pregnant'],
        disease: json['disease'],
        cautions: json['cautions'],
        profileImageUrl: json['profile_image_url'],
        termsAgree: json['terms_agree'],
        privacyAgree: json['privacy_agree'],
        type: json['type'],
        fcmToken: json['fcm_token']);
  }
}
