# pillgood

## TODOS

- [x] Splash Screen
- [x] Login Screen
- [ ] Sign Up Screen (일반 사용자)
- [ ] Sign Up Screen (약사)
- [ ] Sign Up Screen (약국장)
- [ ] Home Screen (GPS)
- [ ] Chat List Screen
- [ ] New Chat Screen
- [ ] Chat Screen
- [ ] My Page Screen (일반 사용자)
- [ ] Members Screen (약사)
- [ ] Members Screen (약국장)
- [ ] Information Screen (약국장)
